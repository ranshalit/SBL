/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2025, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 

#ifdef __linux__
#include <linux/printk.h> 
#include <linux/module.h> 
#endif

#include "../CgosDrv.h"		//MOD_3.1.2_3
#include "../CGBC.h"		//MOD_3.1.2_3
#include "BCModule.h"
#include "WDModule_cfg.h"

//***************************************************************************

//#define dbg_wd_on

#ifdef dbg_wd_on
	#define dbgwd(x) x
#else
	#define dbgwd(x)
#endif

//***************************************************************************
//Function Prototypes

unsigned int initWDModule(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogGetInfo(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogIsAvailable(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogTrigger(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogGetTriggerCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogSetTriggerCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogGetConfigStruct(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogSetConfigStruct(CGOS_DRV_VARS *cdv);
unsigned int zCgosWDogSetConfig(CGOS_DRV_VARS *cdv); 
unsigned int zCgosWDogDisable(CGOS_DRV_VARS *cdv);
void exitWDModule(CGOS_DRV_VARS *cdv);

//***************************************************************************

/***********************************************************************
 * unsigned int initWDModule(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: This function is called to copy information from		
 * 				WDModule_cfg.h into the cdv struct.						
 * 																		
 * Last Change: 12.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int initWDModule(CGOS_DRV_VARS *cdv)
  {
	unsigned int i = 0;	
	unsigned int retSuccess = CGOS_SUCCESS;
	dbgwd(printk("initWDModule called\n");)
	if(WD_COUNT <= CGOS_DRV_WDOG_MAX)		//CGOS_DRV_WDOG_MAX defined in DrvVars.h
	{
		cdv->brd->wdogCount = WD_COUNT;
	
		for(i = 0; i < WD_COUNT; i++)
		{
			OsaMemCpy(&cdv->wdog[i].config,&WD_CONFIG[i],sizeof(CGOSWDCONFIG));
			OsaMemCpy(&cdv->wdog[i].info,&WD_INFO[i],sizeof(CGOSWDINFO));
		}
	}
	else
	{
		retSuccess = CGOS_ERROR;
	}
	return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosWDogGetInfo(CGOS_DRV_VARS *cdv)			  		
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogGetInfo(HCGOS hCgos, 						    
 * 								  unsigned long dwUnit,				    
 * 								  CGOSWDINFO *pInfo)				    
 * Inputs:															    
 *   dwUnit <->		cdv->cin->type					    			    
 * 																	    
 * Outputs:															    
 *   pInfo 	<-> 	cdv->pout										    
 * 																		
 ***********************************************************************
 * Description: Get the info struct of the watchdog.					
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosWDogGetInfo(CGOS_DRV_VARS *cdv)
  {
	dbgwd(printk("zCgosWDogGetInfo called\n");)
  	if(cdv->cin->type < cdv->brd->wdogCount)
	{
		OsaMemCpy(cdv->pout,&cdv->wdog[cdv->cin->type].info,sizeof(CGOSWDINFO));
	}
	else
	{
		return CGOS_ERROR;
	}
	cdv->retcnt += sizeof(CGOSWDINFO);
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosWDogCount(CGOS_DRV_VARS *cdv)				  		
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogCount(HCGOS hCgos) 						    
 * 																	    
 * Inputs:															    
 *   -												    			    
 * 																	    
 * Outputs:															    
 *   cdv->cout->rets[0]												    
 * 																		
 ***********************************************************************
 * Description: Get the number of available watchdogs.					
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosWDogCount(CGOS_DRV_VARS *cdv)
  {
	cdv->cout->rets[0] = cdv->brd->wdogCount;						
	dbgwd(printk("zCgosWDogCount called\n");)
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosWDogIsAvailable(CGOS_DRV_VARS *cdv)				
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogIsAvailable(HCGOS hCgos, 					    
 * 									  unsigned int dwUnit)			    
 * Inputs:															    
 *   -												    			    
 * 																	    
 * Outputs:															    
 *   cdv->cout->rets[0]												    
 * 																		
 ***********************************************************************
 * Description: Check if watchdog with number dwUnit is available.		
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosWDogIsAvailable(CGOS_DRV_VARS *cdv)
  {
	dbgwd(printk("zCgosWDogIsAvailable called\n");)
   	cdv->cout->rets[0]=cdv->cin->type<cdv->brd->wdogCount;
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosWDogTrigger(CGOS_DRV_VARS *cdv)			  		
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogTrigger(HCGOS hCgos, 						    
 * 								  unsigned long dwUnit)				    
 * Inputs:															    
 *   -												    			    
 * 																	    
 * Outputs:															    
 *   -																    
 * 																		
 ***********************************************************************
 * Description: Triggers the watchdog dwUnit. Only BC watchdog			
 * 				implemented at the moment.								
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosWDogTrigger(CGOS_DRV_VARS *cdv)
  {
   	unsigned char command = CGBC_CMD_WD_TRIGGER;
	unsigned char sts = 0;
	dbgwd(printk("zCgosWDogTrigger called\n");)
	bcCommand(&command, 1, NULL, 0, &sts); 
	return CGOS_SUCCESS;
  }
  
/***********************************************************************
 * unsigned int zCgosWDogGetTriggerCount(CGOS_DRV_VARS *cdv)	  		
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogGetTriggerCount(HCGOS hCgos, 				    
 * 								  		  unsigned long dwUnit)		    
 *																	    
 ***********************************************************************
 * Description: 										
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosWDogGetTriggerCount(CGOS_DRV_VARS *cdv)
  {
	dbgwd(printk("zCgosWDogGetTriggerCount called\n");)
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosWDogSetTriggerCount(CGOS_DRV_VARS *cdv)			
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogSetTriggerCount(HCGOS hCgos, 				    
 * 								  		  unsigned long dwUnit)		    	
 * 										  unsigned int cnt   		    
 * 																		
 ***********************************************************************
 * Description: 											
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosWDogSetTriggerCount(CGOS_DRV_VARS *cdv)
  {
	dbgwd(printk("zCgosWDogSetTriggerCount called\n");)
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosWDogGetConfigStruct(CGOS_DRV_VARS *cdv)	  		
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogGetConfigStruct(HCGOS hCgos, 				    
 * 										  unsigned long dwUnit,		    
 * 										  CGOSWDCONFIG *pConfig)	    
 * Inputs:															    
 *   dwUnit <->		cdv->cin->type					    			    
 * 																	    
 * Outputs:															    
 * pConfig 	<-> 	cdv->pout;						 				    
 * 																		
 ***********************************************************************
 * Description: Get the config struct of watchdog number dwUnit.		
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosWDogGetConfigStruct(CGOS_DRV_VARS *cdv)
  {
  	dbgwd(printk("zCgosWDogGetConfigStruct called\n");)
	if(cdv->cin->type < cdv->brd->wdogCount)
	{
		OsaMemCpy(cdv->pout,&cdv->wdog[cdv->cin->type].config,sizeof(CGOSWDCONFIG));
	}
	else
	{
		return CGOS_ERROR;
	}
	cdv->retcnt += sizeof(CGOSWDCONFIG); 
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosWDogSetConfigStruct(CGOS_DRV_VARS *cdv)	  		
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogSetConfigStruct(HCGOS hCgos, 				    
 * 										  unsigned long dwUnit,		    
 * 										  CGOSWDCONFIG *pConfig)	    
 * Inputs:															    
 * pConfig 	<-> 	(CGOSWDCONFIG*)cdv->pin;						    
 * dwUnit	<->		cdv->cin->type					    			    
 * 																	    
 * Outputs:															    
 *   -																    
 * 																		
 ***********************************************************************
 * Description: Overwrite the config struct of watchdog number dwUnit
 * 				and send the new config struct to the board controller.	
 * 				Only the BC watchdog is implemented at the moment.		
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosWDogSetConfigStruct(CGOS_DRV_VARS *cdv)
  {
	unsigned char wbuf[15];
	unsigned char sts = 0;
	unsigned int unit = cdv->cin->type;
	unsigned int i = 0;
	if(unit < cdv->brd->wdogCount)
	{
		OsaMemCpy(&cdv->wdog[unit].config,(CGOSWDCONFIG*)cdv->pin,sizeof(CGOSWDCONFIG));  
		dbgwd(printk("zCgosWDogSetConfigStruct called\n");)	

		wbuf[0]  = CGBC_CMD_WD_INIT;
		wbuf[1]  = cdv->wdog[unit].config.dwOpMode; 	//wd mode

		wbuf[2]  = cdv->wdog[unit].config.dwStageCount;	//wd control byte
		for(i = 0; i < cdv->wdog[unit].config.dwStageCount; i++)
		{
			wbuf[2] |= (cdv->wdog[unit].config.stStages[i].dwEvent << (2*i+2)); 
		}

		if(cdv->wdog[unit].config.dwMode != CGOS_WDOG_MODE_STAGED)
		{
			wbuf[3]  =  cdv->wdog[unit].config.dwTimeout & 0xFF; 			 //stage 1 timeout low byte
			wbuf[4]  = (cdv->wdog[unit].config.dwTimeout & 0xFF00)	>>  8;   //stage 1 timeout middle byte
			wbuf[5]  = (cdv->wdog[unit].config.dwTimeout & 0xFF0000) >> 16;  //stage 1 timeout high byte
		}
		else if(cdv->wdog[unit].config.dwMode == CGOS_WDOG_MODE_STAGED)
		{
			for(i = 0; i < cdv->wdog[unit].config.dwStageCount; i++)
			{
				wbuf[3+i*3]  =  cdv->wdog[unit].config.stStages[i].dwTimeout & 0xFF;			 //stage i+1 timeout low byte
				wbuf[4+i*3]  = (cdv->wdog[unit].config.stStages[i].dwTimeout & 0xFF00) 	>>  8;   //stage i+1 timeout middle byte
				wbuf[5+i*3]  = (cdv->wdog[unit].config.stStages[i].dwTimeout & 0xFF0000) >> 16;	 //stage i+1 timeout high byte
			}
		}
		wbuf[12] =  cdv->wdog[unit].config.dwDelay & 0xFF; 				//wd delay low byte
		wbuf[13] = (cdv->wdog[unit].config.dwDelay & 0xFF00)   >>  8;	//wd delay middle byte
		wbuf[14] = (cdv->wdog[unit].config.dwDelay & 0xFF0000) >> 16; 	//wd delay high byte

		bcCommand(&wbuf[0],15,NULL,0,&sts);
	}
	else
	{
		return CGOS_ERROR;
	}
	return CGOS_SUCCESS;
  }



/***********************************************************************
 * unsigned int zCgosWDogSetConfig(CGOS_DRV_VARS *cdv)			  		
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogSetConfig(HCGOS hCgos, 					    
 * 									unsigned long dwUnit,			    
 * 									unsigned long timeout,	 		    
 * 									unsigned long delay,			    
 * 									unsigned long mode)				    
 * Inputs:															    
 * timeout 	<-> 	cdv->cin->pars[0];								    
 * delay 	<-> 	cdv->cin->pars[1];								   
 * mode 	<-> 	cdv->cin->pars[2];								    
 * 																	    
 * Outputs:															    
 * 	-																    
 * 																		
 ***********************************************************************
 * Description: Short form of CgosWDogSetConfigStruct, the information	
 * 				isn't stored in the cdv struct and sent to the BC 		
 * 				immediately.											
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosWDogSetConfig(CGOS_DRV_VARS *cdv)
  {
	unsigned char wbuf[15];
	unsigned char sts = 0;
	unsigned int retSuccess = CGOS_SUCCESS;
	
	dbgwd(printk("zCgosWDogSetConfig called\n");)
	
	//Update WD_config						//MOD25
	cdv->wdog[0].config.dwTimeout = cdv->cin->pars[0];
	cdv->wdog[0].config.dwDelay = cdv->cin->pars[1];
	cdv->wdog[0].config.dwMode = cdv->cin->pars[2];
	cdv->wdog[0].config.dwStageCount = 1;
	if(cdv->cin->pars[2] == CGOS_WDOG_MODE_REBOOT_PC)
	{
		cdv->wdog[0].config.stStages[0].dwEvent = CGOS_WDOG_EVENT_RST;
	}
	else if(cdv->cin->pars[2] == CGOS_WDOG_MODE_RESTART_OS)
	{
		cdv->wdog[0].config.stStages[0].dwEvent = CGOS_WDOG_EVENT_BTN;
	}
	/*
	else if (cdv->cin->pars[2] == CGOS_WDOG_MODE_STAGED)
	{
		
	}
	*/
	else
	{
		return CGOS_ERROR;
	}
	
	//Execute Board Controller command
	wbuf[0]  = CGBC_CMD_WD_INIT;
	wbuf[1]  = CGBC_WD_SINGLE_EVENT_MODE;				//MOD25
	if(cdv->cin->pars[2] == CGOS_WDOG_MODE_REBOOT_PC)
	{
		wbuf[2]  = 1 | (CGBC_WD_EVENT_RST << 2);
	}
	else if(cdv->cin->pars[2] == CGOS_WDOG_MODE_RESTART_OS)
	{
		wbuf[2]  = 1 | (CGBC_WD_EVENT_BTN << 2);
	}
	else
	{
		retSuccess = CGOS_ERROR;
	}
	
	wbuf[3]  =  cdv->cin->pars[0] & 0xFF; 				//stage 1 timeout low byte
	wbuf[4]  = (cdv->cin->pars[0] & 0xFF00)	  >>  8;	//stage 1 timeout middle byte
	wbuf[5]  = (cdv->cin->pars[0] & 0xFF0000) >> 16; 	//stage 1 timeout high byte
	
	wbuf[12] =  cdv->cin->pars[1] & 0xFF; 				//wd delay low byte
	wbuf[13] = (cdv->cin->pars[1] & 0xFF00)   >>  8;	//wd delay middle byte
	wbuf[14] = (cdv->cin->pars[1] & 0xFF0000) >> 16; 	//wd delay high byte
	
	bcCommand(&wbuf[0],15,NULL,0,&sts);
	
	return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosWDogDisable(CGOS_DRV_VARS *cdv)			  		
 * 																		
 ***********************************************************************
 * Cgos Function: CgosWDogDisable(HCGOS hCgos, 						    
 * 								  unsigned long dwUnit)				   
 * 																	    
 * Inputs:															    
 * 	 -																    
 * Outputs:															    
 *   -																    
 * 																		
 ***********************************************************************
 * Description: Disables the BC watchdog.								
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosWDogDisable(CGOS_DRV_VARS *cdv)
  { 
	unsigned char wbuf[15];
	unsigned char sts = 0;
	
	dbgwd(printk("zCgosWDogDisable called\n");)
	
	wbuf[0] = CGBC_CMD_WD_INIT;
	wbuf[1] = CGBC_WD_DISABLED;
	
	bcCommand(&wbuf[0],15,NULL,0,&sts);
	
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * void exitWDModule(CGOS_DRV_VARS *cdv) 							    
 * 																	
 ***********************************************************************
 * Description: This function is called during driver close and should	
 * 				free allocated resources.							
 * 																		
 * Last Change: 12.12.2017 HMI											
 * 																	
 * Modifications:														
 ***********************************************************************/
void exitWDModule(CGOS_DRV_VARS *cdv)
{
	dbgwd(printk("exitWDModule called\n");)

}
