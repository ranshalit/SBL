/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2022, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 
 
#ifndef _CUPMOD_H_
#define _CUPMOD_H_

//************************ Driver Internal Functions ************************
extern unsigned int initCUPModule(CGOS_DRV_VARS *cdv);
extern void exitCUPModule(CGOS_DRV_VARS *cdv);

//************************ Cgos Functions ************************
extern unsigned int zCgosUpdateCaps(CGOS_DRV_VARS *cdv);
extern unsigned int zCgosTriggerCapsuleUpdate(CGOS_DRV_VARS *cdv);

extern unsigned int zCgosCapsuleUpdateBiosCaps(CGOS_DRV_VARS *cdv);
extern unsigned int zCgosCapsuleUpdateBiosTrigger(CGOS_DRV_VARS *cdv);

#endif
