/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2022, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 

#ifdef __linux__
#include <linux/printk.h> 
#include <linux/ioport.h> 
#include <linux/dmi.h>
#include <asm/io.h>
#else	
#include <Windows.h>
#define false FALSE
#define true TRUE
#endif

//#include "CGBC.h"
#include "../CgosDrv.h"		//MOD_3.1.2_3
#include "BCModule_cfg.h"
#include "BCSubModules/BCSubModule_BC4_BASE_E.h"
#include "BCSubModules/BCSubModule_BC4_BASE_C.h"
#include "BCSubModules/BCSubModule_GEN5.h"

//***************************************************************************

//#define dbg_bc_on

#ifdef dbg_bc_on
	#define dbgbc(x) x
#else
	#define dbgbc(x)
#endif

//***************************************************************************
// Global Variables

 unsigned char BoardControllerGen;
 
//***************************************************************************
//Function Prototypes

int Comp(char *comp1, char *comp2);
unsigned int GetBoardControllerType(CGOS_DRV_VARS *cdv);
unsigned int initBCModule(CGOS_DRV_VARS *cdv);
unsigned int bcCommand(unsigned char *cmdDataBPtr, unsigned char  cmdByteCount, unsigned char *rcvDataBPtr, unsigned char  rcvByteCount, unsigned char *retValueBPtr );
unsigned int zCgosCgbcGetInfo(CGOS_DRV_VARS *cdv);						
unsigned int zCgosCgbcSetControl(CGOS_DRV_VARS *cdv);				
unsigned int zCgosCgbcReadWrite(CGOS_DRV_VARS *cdv);				
unsigned int zCgosCgbcHandleCommand(CGOS_DRV_VARS *cdv);
void exitBCModule(CGOS_DRV_VARS *cdv);

//***************************************************************************
 
/***********************************************************************
 * int Comp(char *comp1, char *comp2) 					    
 * 																		
 ***********************************************************************
 * Description: 					
 * 																		
 * Last Change:											
 * 																		
 * Modifications: 													
 ***********************************************************************/ 
 int Comp(char *comp1, char *comp2)
 {
 	unsigned int i;
 	
 	for(i = 0; i < 4; i++)
 	{
 		/*if(((comp1 + i) == NULL) || ((comp2 + i) == NULL))
 		{
 			return -1;
 		} */
 		if(*(comp1 + i) != *(comp2 + i))
 		{
 			return 0;
 		}
 	}
 	return 1;
 }
 
 /***********************************************************************
 * unsigned int GetBoardControllerType(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: 					
 * 																		
 * Last Change:										
 * 																		
 * Modifications: 													
 ***********************************************************************/
  unsigned int GetBoardControllerType(CGOS_DRV_VARS *cdv)
 {
	unsigned char Letter;
	const char *value;
	char Board[4] = {0};
	int i;
 
  if (cdv->biosInterfaceAvailable == true) // if the bios interface is available, determine the bc generation from the info struct
  {
      //Determine BC GEN
       if (cdv->binfo.cgdirBCGeneration == BC_TYPE_GEN5)
       {
         // printk("BC Generation BC_TYPE_GEN5 found!\n");
          cdv->brd->BC_Type = BC_TYPE_GEN5;
          return CGOS_SUCCESS; 
       }
       else if (cdv->binfo.cgdirBCGeneration == BC_TYPE_BC4_BASE_C)
       {
          //printk("BC Generation BC_TYPE_BC4_BASE_C found!\n");
          cdv->brd->BC_Type = BC_TYPE_BC4_BASE_C;
          return CGOS_SUCCESS;
       }
       else if (cdv->binfo.cgdirBCGeneration == BC_TYPE_BC4_BASE_E)
       {
         // printk("BC Generation BC_TYPE_BC4_BASE_E found!\n");
          cdv->brd->BC_Type = BC_TYPE_BC4_BASE_E;
          return CGOS_SUCCESS;
       }
	   else if (cdv->binfo.cgdirBCGeneration == BC_TYPE_GEN6)
	   {
		   // printk("BC Generation BC_TYPE_GEN6 found!\n");
		   cdv->brd->BC_Type = BC_TYPE_GEN6;
		   return CGOS_SUCCESS;
	   }
       else
       {
          //exit with error if value for BC Generation is invalid
          //printk("invalid value for BC Generation\n");
          return CGOS_ERROR;
       }
  }
  
#ifdef __linux__
 
  else // when cdv->biosInterfaceAvailable == false, the bios interface is not available, determine bc generation via dmi in linux
  {
    //Get Project Code	
    value = dmi_get_system_info(DMI_BIOS_VERSION);
    
    if (value != NULL)
    {
    	for(i = 0; i < 4; i++)
    	{
          Letter = *(value + i);
          if ((Letter >= 0x30) && (Letter <= 0x39)) //Letter is ASCII Number
          {
            Board[i] = Letter;
            cdv->brd->BoardName[i] = Letter;
          }
          else if ((Letter >= 0) && (Letter <= 9)) //Letter is int Number
          {
            //convert to ASCII
            Board[i] = Letter + 0x30; 
            cdv->brd->BoardName[i] = Letter + 0x30; 
          }
          else //Letter is no number
          {
            Board[i] = *(value + i);
            cdv->brd->BoardName[i] = *(value + i); //CGOSBOARDINFOs Project Code field (information from BC) could be used instead if smbios information
          }
     	}
     }								
     else
     {
        return CGOS_ERROR;
     }
    
    //Check if BC4 Base E
    for(i = 0;i < BC4_BASE_E_COUNT; i++)
    {
      if(Comp(&(BC4_BASE_E_LIST[i].Letters[0]),&Board[0]) == 1)
      {
        cdv->brd->BC_Type = BC_TYPE_BC4_BASE_E;
        return CGOS_SUCCESS;
      }
    }

    //Check if BC4 Base C
    for(i = 0;i < BC4_BASE_C_COUNT; i++)
    {
      if(Comp(&(BC4_BASE_C_LIST[i].Letters[0]),&Board[0]) == 1)
      {
        cdv->brd->BC_Type = BC_TYPE_BC4_BASE_C;
        return CGOS_SUCCESS;
      }
    }

    //Check if BC GEN5
    for(i = 0;i < GEN5_COUNT; i++)
    {
      if(Comp(&(GEN5_LIST[i].Letters[0]),&Board[0]) == 1)
      {
        cdv->brd->BC_Type = BC_TYPE_GEN5;
        return CGOS_SUCCESS;
      }
    } 
    return CGOS_ERROR;	//MOD_3.1.2_3
  }
#else
  //cdv->brd->BC_Type = BC_TYPE_BC4_BASE_C;
  //cdv->brd->BC_Type = BC_TYPE_BC4_BASE_E;
  cdv->brd->BC_Type = BC_TYPE_GEN5;
  return CGOS_SUCCESS; 
#endif  
 }
 
/***********************************************************************
 * unsigned int initBCModule(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: 					
 * 																		
 * Last Change: 23.09.2019 HMI											
 * 																		
 * Modifications: 													
 ***********************************************************************/
unsigned int initBCModule(CGOS_DRV_VARS *cdv)
  {
	unsigned int retSuccess = CGOS_SUCCESS;
	dbgbc(printk("initBCModule called\n");)

	GetBoardControllerType(cdv);

		switch(cdv->brd->BC_Type)
		{
			case BC_TYPE_GEN5:		retSuccess = initSubModule_GEN5(cdv);
							break;
			case BC_TYPE_GEN6:		retSuccess = initSubModule_GEN5(cdv);
							break;
			case BC_TYPE_BC4_BASE_C:	retSuccess = initSubModule_BC4_BASE_C(cdv);
							break;
			case BC_TYPE_BC4_BASE_E:	retSuccess = initSubModule_BC4_BASE_E(cdv);
							break;
			default:			cdv->brd->BC_Type = BC_TYPE_GEN5; //In case no BC Type was found, default to GEN5
							retSuccess = initSubModule_GEN5(cdv);
		}
	BoardControllerGen = cdv->brd->BC_Type;
	return retSuccess;
  }
/***********************************************************************
 * unsigned int bcCommand(unsigned char *cmdDataBPtr,					
 *						  unsigned char  cmdByteCount,					
 *					      unsigned char *rcvDataBPtr,					
 *					      unsigned char  rcvByteCount,					
 *					      unsigned char *retValueBPtr )	  				
 * 																		
 * Inputs:																
 * 	cmdDataBPtr															
 * 	cmdByteCount														
 * 	rcvByteCount														
 * 																		
 * Outputs:																
 * 	rcvDataBPtr															
 * 	retValueBPtr														
 * 																		
 * Return:																
 * 	CGOS_SUCCESS or CGOS_ERROR											
 * 																		
 ***********************************************************************
 * Description: This function is used to communicate with the board		
 * 				controller												
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int bcCommand(unsigned char *cmdDataBPtr, unsigned char  cmdByteCount,
					   unsigned char *rcvDataBPtr, unsigned char  rcvByteCount,
					   unsigned char *retValueBPtr )
{
    unsigned int retSuccess = CGOS_SUCCESS;
    switch(BoardControllerGen)
    {
	case BC_TYPE_GEN5:		retSuccess = bcCommand_GEN5(cmdDataBPtr, cmdByteCount, rcvDataBPtr, rcvByteCount, retValueBPtr);
					break;
	case BC_TYPE_GEN6:		retSuccess = bcCommand_GEN5(cmdDataBPtr, cmdByteCount, rcvDataBPtr, rcvByteCount, retValueBPtr);
					break;
	case BC_TYPE_BC4_BASE_C:	retSuccess = bcCommand_BC4_BASE_C(cmdDataBPtr, cmdByteCount, rcvDataBPtr, rcvByteCount, retValueBPtr);
					break;
	case BC_TYPE_BC4_BASE_E:	retSuccess = bcCommand_BC4_BASE_E(cmdDataBPtr, cmdByteCount, rcvDataBPtr, rcvByteCount, retValueBPtr);
					break;
    }
    return retSuccess;
}

/***********************************************************************
 * unsigned int zCgosCgbcGetInfo(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 28.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosCgbcGetInfo(CGOS_DRV_VARS *cdv)						
  {    
	unsigned int retSuccess = CGOS_SUCCESS;
	dbgbc(printk("zCgosCgbcGetInfo called\n");)	
	
    	switch(BoardControllerGen)
    	{
		case BC_TYPE_GEN5:		retSuccess = CgosCgbcGetInfo_GEN5(cdv);
						break;
		case BC_TYPE_GEN6:		retSuccess = CgosCgbcGetInfo_GEN5(cdv);
						break;
		case BC_TYPE_BC4_BASE_C:	retSuccess = CgosCgbcGetInfo_BC4_BASE_C(cdv);
						break;
		case BC_TYPE_BC4_BASE_E:	retSuccess = CgosCgbcGetInfo_BC4_BASE_E(cdv);
						break;
    	}	
    	return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosCgbcSetControl(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 28.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosCgbcSetControl(CGOS_DRV_VARS *cdv)					
  { 
	unsigned int retSuccess = CGOS_SUCCESS;
	dbgbc(printk("zCgosCgbcSetControl called\n");)		
	
    	switch(BoardControllerGen)
    	{
		case BC_TYPE_GEN5:		retSuccess = CgosCgbcSetControl_GEN5(cdv);
						break;
		case BC_TYPE_GEN6:		retSuccess = CgosCgbcSetControl_GEN5(cdv);
						break;
		case BC_TYPE_BC4_BASE_C:	retSuccess = CgosCgbcSetControl_BC4_BASE_C(cdv);
						break;
		case BC_TYPE_BC4_BASE_E:	retSuccess = CgosCgbcSetControl_BC4_BASE_E(cdv);
						break;
    	}	
    	return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosCgbcReadWrite(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 28.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosCgbcReadWrite(CGOS_DRV_VARS *cdv)					
  { 	
	unsigned int retSuccess = CGOS_SUCCESS;
	dbgbc(printk("zCgosCgbcReadWrite called\n");)		
	
    	switch(BoardControllerGen)
    	{
		case BC_TYPE_GEN5:		retSuccess = CgosCgbcReadWrite_GEN5(cdv);
						break;
		case BC_TYPE_GEN6:		retSuccess = CgosCgbcReadWrite_GEN5(cdv);
						break;
		case BC_TYPE_BC4_BASE_C:	retSuccess = CgosCgbcReadWrite_BC4_BASE_C(cdv);
						break;
		case BC_TYPE_BC4_BASE_E:	retSuccess = CgosCgbcReadWrite_BC4_BASE_E(cdv);
						break;
    	}	
    	return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosCgbcHandleCommand(CGOS_DRV_VARS *cdv)			    
 * 																		
 ***********************************************************************
 * Cgos Function: CgosCgbcHandleCommand(HCGOS hCgos, 				
 * 										unsigned char *pBytesWrite, 	
 * 										unsigned int dwLenWrite, 		
 * 										unsigned char *pBytesRead, 		
 * 										unsigned int dwLenRead, 		
 * 										unsigned int *pdwStatus)		
 *																		
 * Inputs:																
 * 	pBytesWrite		<->		cdv->pin									
 * 	dwLenWrite		<->		cdv->lin									
 * 	dwLenRead		<->		cdv->lout									
 * 																		
 * Outputs:																
 * 	pBytesRead		<->		cdv->pout									
 * 	pdwStatus		<->		cdv->cout->rets[0]							
 * 																		
 * Return:																
 * 	CGOS_SUCCESS														
 * 																		
 ***********************************************************************
 * Description: This function is used to communicate with the board		
 * 				controller.												
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosCgbcHandleCommand(CGOS_DRV_VARS *cdv)	
{
	unsigned char ret = 0;

	unsigned int lin = cdv->lin;
	unsigned int lout = cdv->lout;
	unsigned char pin[256] = {0};
	unsigned char pout[256] ={0};

	dbgbc(printk("zCgosCgbcHandleCommand called\n");)

	if(( lin > 256)||(lout > 256))
	{
		return CGOS_ERROR;
	}
	OsaMemCpy(&pin[0],cdv->pin,lin);	
	
	cdv->cout->status = bcCommand(&pin[0],lin,&pout[0],lout,&ret);
	OsaMemCpy(cdv->pout,&pout[0],lout);

	cdv->cout->rets[0] = ret;
	cdv->retcnt += sizeof(unsigned char)*lout;
	return CGOS_SUCCESS;
}

/***********************************************************************
 * void exitBCModule(CGOS_DRV_VARS *cdv) 							    
 * 																		
 ***********************************************************************
 * Description: This function is called during driver close and should	
 * 				free allocated resources.							
 * 																		
 * Last Change: 28.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
void exitBCModule(CGOS_DRV_VARS *cdv)
{
	dbgbc(printk("exitBCModule called\n");)		
	
    	switch(BoardControllerGen)
    	{
		case BC_TYPE_GEN5:		exitSubModule_GEN5(cdv);
						break;
		case BC_TYPE_GEN6:		exitSubModule_GEN5(cdv);
						break;
		case BC_TYPE_BC4_BASE_C:	//No exit function needed
						break;
		case BC_TYPE_BC4_BASE_E:	//No exit function needed
						break;
    	}	
}

