﻿/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2025, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 

#ifdef __linux__
#include <linux/printk.h> 
#include <asm/msr.h>
#define __readmsr(x) __rdmsr(x)
#endif

#include "../CgosDrv.h"
#include "../CGBC.h"
#include "BCModule.h"
#include "HWMAddon_CPU_Temp_cfg.h"	

//***************************************************************************
//Function prototypes

unsigned int addonCpuTempAddTempSensor(CGOS_DRV_VARS *cdv);
unsigned int addonCpuTempGetTemperature(CGOS_DRV_VARS *cdv);

//***************************************************************************


/***********************************************************************
 * unsigned int addonCpuTempAddTempSensor(CGOS_DRV_VARS *cdv) 				    
 * 																		
 ***********************************************************************
 * Description: This function is called to copy CPU Sensor information 
 * 				from HWMAddon_CPU_Temp_cfg.h into the cdv struct.				
 * 																		
 * Last Change: 											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int addonCpuTempAddTempSensor(CGOS_DRV_VARS *cdv)
  {	
	unsigned int retSuccess = CGOS_SUCCESS;
	unsigned int i;
	unsigned int tempcnt = cdv->brd->hwmCount.tempCount;
	
	if((tempcnt + TEMP_COUNT_CPU) <= CGOS_DRV_TEMP_MAX)  //CGOS_DRV_TEMP_MAX defined in DrvVars.h
	{
		//Add additional CPU Sensors to cdv
		cdv->brd->hwmCount.tempCount += TEMP_COUNT_CPU;
		for(i = 0; i < TEMP_COUNT_CPU; i++)
		{
			OsaMemCpy(&cdv->hwm->tempsensors[tempcnt + i],&TEMP_INFO_CPU[i],sizeof(CGOS_DRV_TEMP_ENTRY));
		}
	}
	else
	{
		retSuccess = CGOS_ERROR;
	}
	return retSuccess;
  }
  
 /***********************************************************************
 * unsigned int addonCpuTempGetTemperature(CGOS_DRV_VARS *cdv)		    
 * 																		
 ***********************************************************************
 * Description: Gets status and value/error code of the	requested		
 * 				temperature sensor.										
 * 																		
 * Last Change: 										
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int addonCpuTempGetTemperature(CGOS_DRV_VARS *cdv)
  {
	volatile unsigned char cpuTemp = 0;
	volatile unsigned char refTemp = 0;

#ifdef __linux__	
	volatile uint64_t msrValue = 0;
#else //Windows
	volatile UINT64 msrValue = 0;
#endif //__linux__

	//Read Digital Thermal Sensor
	msrValue = __readmsr(0x19C);	//Read IA32_​THERM_​STATUS (0x19C) MSR
	if (!(msrValue & 0x80000000))	//Bit [31] set to 1 indicates valid readout
	{	
		//On fail try again
		msrValue = __readmsr(0x19C);	//Read IA32_​THERM_​STATUS (0x19C) MSR
		if (!(msrValue & 0x80000000))	//Bit [31] set to 1 indicates valid readout
		{
			//On fail, try one last time
			msrValue = __readmsr(0x19C);	//Read IA32_​THERM_​STATUS (0x19C) MSR
			if (!(msrValue & 0x80000000))	//Bit [31] set to 1 indicates valid readout
			{
				return CGOS_ERROR;
			}
		}
	}
	cpuTemp = (unsigned char)((msrValue >> 16) & 0x000000000000007F);	//Bits [22:16] contain temperature readout

	msrValue = __readmsr(0x1A2);	//Read TEMPERATURE_​TARGET (0x1A2) MSR
	refTemp = (unsigned char)((msrValue >> 16) & 0x00000000000000FF); //Bits [23:16] contain TCC Activation temperature

	//Sanity Check
	if (cpuTemp > refTemp)
	{
		//Force 0 instead of negative value or error
		cpuTemp = 0;
	}
	else
	{
		// Calculate actual CPU temperature
		cpuTemp = refTemp - cpuTemp;
	}

	//Expand from 8 to 32 bit value and multiply with 1000 because CGOS API expects 0.001 degree centigrade
	cdv->cout->rets[0] = (int)cpuTemp * 1000;	
	cdv->cout->rets[1] = 1;

	return CGOS_SUCCESS;
  }

