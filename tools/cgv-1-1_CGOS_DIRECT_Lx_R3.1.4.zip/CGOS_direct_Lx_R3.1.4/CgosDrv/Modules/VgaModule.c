/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2022, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 

#ifdef __linux__
#include <linux/printk.h> 
#endif

#include "../CgosDrv.h"		//MOD_3.1.2_3
#include "../CGBC.h"		//MOD_3.1.2_3
#include "BCModule.h"
#include "VgaModule_cfg.h"

//***************************************************************************

//#define dbg_vga_on

#ifdef dbg_vga_on
	#define dbgvga(x) x
#else
	#define dbgvga(x)
#endif

//***************************************************************************
//Function prototypes

unsigned int initVgaModule(CGOS_DRV_VARS *cdv); 
unsigned int zCgosVgaCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosVgaGetInfo(CGOS_DRV_VARS *cdv);						
unsigned int zCgosVgaGetContrast(CGOS_DRV_VARS *cdv);
unsigned int zCgosVgaSetContrast(CGOS_DRV_VARS *cdv);
unsigned int zCgosVgaGetContrastEnable(CGOS_DRV_VARS *cdv);
unsigned int zCgosVgaSetContrastEnable(CGOS_DRV_VARS *cdv);  
unsigned int zCgosVgaGetBacklight(CGOS_DRV_VARS *cdv);
unsigned int zCgosVgaSetBacklight(CGOS_DRV_VARS *cdv);
unsigned int zCgosVgaGetBacklightEnable(CGOS_DRV_VARS *cdv); 
unsigned int zCgosVgaSetBacklightEnable(CGOS_DRV_VARS *cdv);
unsigned int zCgosVgaEndDarkBoot(CGOS_DRV_VARS *cdv);
void exitVgaModule(CGOS_DRV_VARS *cdv);

//***************************************************************************

/***********************************************************************
 * unsigned int initVgaModule(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: 					
 * 																		
 * Last Change: 25.06.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int initVgaModule(CGOS_DRV_VARS *cdv)
  {
	unsigned int i = 0;
	unsigned int retSuccess = CGOS_SUCCESS;
	dbgvga(printk("initVgaModule called\n");)
	//Only writes dummy values from VgaSubModule_BC_cfg.h at the moment!!!
	if(VGA_COUNT <= CGOS_DRV_VGA_MAX)		//CGOS_DRV_VGA_MAX defined in DrvVars.h
	{
		cdv->brd->vgaCount = VGA_COUNT;
		for(i = 0; i < VGA_COUNT; i++)
		{
			OsaMemCpy(&cdv->vga[i].info,&VGA_INFO[i],sizeof(CGOSVGAINFO));
		}
	}
	else
	{
		retSuccess = CGOS_ERROR;
	}
	return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosVgaCount(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Returns VGA Count			
 * 																		
 * Last Change: 12-Dec-2024											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaCount(CGOS_DRV_VARS *cdv)
  {
	dbgvga(printk("zCgosVgaCount called\n");)
	
	cdv->cout->rets[0] = cdv->brd->vgaCount;	
	return CGOS_ERROR;
  }

/***********************************************************************
 * unsigned int zCgosVgaGetInfo(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Returns info struct for chosen VGA			
 * 																		
 * Last Change: 12-Dec-2024											
 * 																		
 * Modifications:														
 ***********************************************************************/    
unsigned int zCgosVgaGetInfo(CGOS_DRV_VARS *cdv)						
  {
	dbgvga(printk("zCgosVgaGetInfo called\n");)
	return CGOS_ERROR;
  }

/***********************************************************************
 * unsigned int zCgosVgaGetBacklight(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Returns backlight brightness, value between 0% and 100%			
 * 																		
 * Last Change: 12-Dec-2024										
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaGetBacklight(CGOS_DRV_VARS *cdv)
  {
  	unsigned char writeBuf[4];
  	unsigned char returnBuf[3];
  	unsigned char sts;
  	unsigned int unit = cdv->cin->type;       //Chosen VGA
  	
	dbgvga(printk("zCgosVgaGetBacklight called\n");)
	
	//Check input parameters
	if(unit >= cdv->brd->vgaCount){	 //VGA not available
		return CGOS_ERROR;
	}
	
	// Read current setting to get polarity bit and frequency
	writeBuf[0] = CGBC_CMD_BLT0_PWM;
	writeBuf[1] = 0;   //PWM duty factor. Bit 7 is the polarity inversion bit
	writeBuf[2] = 0;   //PWM frequency low byte. 0 indicates reading current settings
	writeBuf[3] = 0;   //PWM frequency high byte. 0 indicates reading current settings
			
	// Normally, the backlight PWM output signal on the LFP0_BLT_PWM pin is
	// high active. However, the polarity can be inverted by the polarity
	// inversion bit (returnBuf[0] bit 7) set to 1.
	
	if(bcCommand( &writeBuf[0], 4, &returnBuf[0], 3, &sts ) == CGOS_SUCCESS){
		cdv->cout->rets[0] = 0x7F & returnBuf[0]; //Only return PWM duty factor percentage, ignore polarity inversion bit (bit 7)
		return CGOS_SUCCESS;
	}
	else{ //bcCommand failed
		return CGOS_ERROR;
	}
  }

/***********************************************************************
 * unsigned int zCgosVgaSetBacklight(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Sets Backlight brightness, value between 0% and 100%		
 * 																		
 * Last Change: 12-Dec-2024											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaSetBacklight(CGOS_DRV_VARS *cdv)
  {
  	unsigned char writeBuf[4];
  	unsigned char returnBuf[3];
  	unsigned char sts;
  	unsigned int unit = cdv->cin->type;       //Chosen VGA
  	unsigned int setting = cdv->cin->pars[0]; //backlight brightness value
  	
	dbgvga(printk("zCgosVgaSetBacklight called\n");)
	
	//Check input parameters
	if(unit >= cdv->brd->vgaCount){	 //VGA not available
		return CGOS_ERROR;
	}	
	
	if(setting > 100){   //backlight brightness value not in range 0-100%
		return CGOS_ERROR;
	}
	
	// Read current setting to get polarity bit and frequency
	writeBuf[0] = CGBC_CMD_BLT0_PWM;
	writeBuf[1] = 0;   //PWM duty factor. Bit 7 is the polarity inversion bit
	writeBuf[2] = 0;   //PWM frequency low byte. 0 indicates reading current settings
	writeBuf[3] = 0;   //PWM frequency high byte. 0 indicates reading current settings
			
	// Normally, the backlight PWM output signal on the LFP0_BLT_PWM pin is
	// high active. However, the polarity can be inverted by the polarity
	// inversion bit (returnBuf[0] bit 7) set to 1.
	
	if(bcCommand( &writeBuf[0], 4, &returnBuf[0], 3, &sts ) == CGOS_SUCCESS){
	
		// Prepare write buffer
                writeBuf[1] = (returnBuf[0] & BLT_PWM_INVERTED_M) | (0x7F & setting); // Keep polarity bit and add new duty factor percentage
		writeBuf[2] = returnBuf[1];	//Keep PWM frequency low byte
		writeBuf[3] = returnBuf[2];	//Keep PWM frequency high byte

		if(bcCommand( &writeBuf[0], 4, &returnBuf[0], 3, &sts ) == CGOS_SUCCESS){ 
			//Check return Buffer if value was set correctly
			if( returnBuf[0] != writeBuf[1]){
				return CGOS_ERROR;
			}
			else{
				return CGOS_SUCCESS;
			}
		}
		else{	//bcCommand failed
			return CGOS_ERROR;
		}
	}
	else{	//bcCommand failed
		return CGOS_ERROR;
	}
  }

/***********************************************************************
 * unsigned int zCgosVgaGetBacklightEnable(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 25.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaGetBacklightEnable(CGOS_DRV_VARS *cdv)
  {
	dbgvga(printk("zCgosVgaGetBacklightEnable called\n");)	
	return CGOS_ERROR;
  }

/***********************************************************************
 * unsigned int zCgosVgaSetBacklightEnable(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 25.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaSetBacklightEnable(CGOS_DRV_VARS *cdv)
  {
	dbgvga(printk("zCgosVgaSetBacklightEnable called\n");)	
	return CGOS_ERROR;
  }
  
/***********************************************************************
 * unsigned int zCgosVgaGetContrast(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Obsolete, deactivated in CgosDrv.c			
 * 																		
 * Last Change: 25.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaGetContrast(CGOS_DRV_VARS *cdv)
  {
	dbgvga(printk("zCgosVgaGetContrast called\n");)
	return CGOS_ERROR;
  }

/***********************************************************************
 * unsigned int zCgosVgaSetContrast(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Obsolete, deactivated in CgosDrv.c			
 * 																		
 * Last Change: 25.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaSetContrast(CGOS_DRV_VARS *cdv)
  {
	dbgvga(printk("zCgosVgaSetContrast called\n");)
	return CGOS_ERROR;
  }

/***********************************************************************
 * unsigned int zCgosVgaGetContrastEnable(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Obsolete, deactivated in CgosDrv.c			
 * 																		
 * Last Change: 25.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaGetContrastEnable(CGOS_DRV_VARS *cdv)
  {
	dbgvga(printk("zCgosVgaGetContrastEnable called\n");)	
	return CGOS_ERROR;
  }

/***********************************************************************
 * unsigned int zCgosVgaSetContrastEnable(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Obsolete, deactivated in CgosDrv.c			
 * 																		
 * Last Change: 25.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaSetContrastEnable(CGOS_DRV_VARS *cdv)
  {
	dbgvga(printk("zCgosVgaSetContrastEnable called\n");)
	return CGOS_ERROR;
  }

/***********************************************************************
 * unsigned int zCgosVgaEndDarkBoot(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Obsolete, deactivated in CgosDrv.c			
 * 																		
 * Last Change: 25.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVgaEndDarkBoot(CGOS_DRV_VARS *cdv)
  {
	dbgvga(printk("zCgosVgaEndDarkBoot called\n");)	
	return CGOS_ERROR;
  }

/***********************************************************************
 * void exitVgaModule(CGOS_DRV_VARS *cdv) 							    
 * 																		
 ***********************************************************************
 * Description: This function is called during driver close and should	
 * 				free allocated resources.							
 * 																		
 * Last Change: 12.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
void exitVgaModule(CGOS_DRV_VARS *cdv)
{
	dbgvga(printk("exitVgaModule called\n");)
}
