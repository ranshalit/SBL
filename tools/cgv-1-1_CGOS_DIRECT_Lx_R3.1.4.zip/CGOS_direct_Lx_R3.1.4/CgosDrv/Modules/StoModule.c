/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2022, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 

#ifdef __linux__
#include <linux/printk.h> 
#include <linux/delay.h>
#include <linux/ioport.h> 
#include <asm/io.h>
#else
#ifdef _WIN64
#pragma intrinsic(__outbyte, __inbyte)
#include <intrin.h>
#define outb(x,y) __outbyte(y,x)
#define outl(x,y) __outdword(y,x)
#define outw(x,y) __outword(y,x)
#define inb(x) __inbyte(x)
#define inw(x) __inword(x)
#define inl(x) __indword(x)
#else
#include <intrin.h>
#define outb(x,y) __outbyte(y,x)
#define outl(x,y) __outdword(y,x)
#define outw(x,y) __outword(y,x)
#define inb(x) __inbyte(x)
#define inw(x) __inword(x)
#define inl(x) __indword(x)
#endif	//_WIN64
#endif	//__linux__

#include "../CgosDrv.h"		//MOD_3.1.2_3
#include "../CGBC.h"		//MOD_3.1.2_3
#include "BCModule.h"
#include "I2CModule.h"

//***************************************************************************

//#define dbg_sto_on

#ifdef dbg_sto_on
	#define dbgsto(x) x
#else
	#define dbgsto(x)
#endif
//***************************************************************************
//Function prototypes

#ifndef __linux__
void msleep(int ms);
#endif
unsigned int power(unsigned int x, unsigned int y);
unsigned int IsAreaType(unsigned int input);
unsigned int IsAreaPresent(unsigned int input, CGOS_DRV_VARS *cdv);
unsigned int CheckParameters(CGOS_DRV_VARS *cdv, unsigned int *areaIndex, unsigned int *storageArea, unsigned int index, unsigned int length);
void addToStorageList(CGOS_DRV_VARS *cdv, unsigned int size, unsigned int type, unsigned int flags, unsigned int areaSize, 
		      unsigned int blockSize, unsigned char* mpfaStartPtr, unsigned int mpfaSectionSelect);
void addToPrivateStorageList(CGOS_DRV_VARS *cdv, unsigned int size, unsigned int type, unsigned int flags, unsigned int areaSize, 
		             unsigned int blockSize, unsigned char* mpfaStartPtr, unsigned int mpfaSectionSelect);
unsigned int initStoModule(CGOS_DRV_VARS *cdv);
unsigned int zCgosStorageAreaCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosStorageAreaType(CGOS_DRV_VARS *cdv);
unsigned int zCgosStorageAreaSize(CGOS_DRV_VARS *cdv);
unsigned int zCgosStorageAreaBlockSize(CGOS_DRV_VARS *cdv);
unsigned int zCgosStorageAreaRead(CGOS_DRV_VARS *cdv);
unsigned int zCgosStorageAreaWrite(CGOS_DRV_VARS *cdv);
unsigned int zCgosStorageAreaErase(CGOS_DRV_VARS *cdv);
unsigned int zCgosStorageAreaEraseStatus(CGOS_DRV_VARS *cdv);    
unsigned int zCgosStorageAreaLock(CGOS_DRV_VARS *cdv);	  
unsigned int zCgosStorageAreaUnlock(CGOS_DRV_VARS *cdv);				
unsigned int zCgosStorageAreaIsLocked(CGOS_DRV_VARS *cdv);
void exitStoModule(CGOS_DRV_VARS *cdv);

//***************************************************************************
//Helper Functions

#ifndef __linux__
void msleep(int ms)
{
}
#endif

/***********************************************************************
 * unsigned int power(unsigned int x, unsigned int y)					    
 * 																		
 ***********************************************************************
 * Description:			
 * 																		
 * Last Change: 										
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int power(unsigned int x, unsigned int y)
{
	if(y == 0){return 1;}
	else
	{
		return x*power(x,y-1);
	}
}

/***********************************************************************
 * unsigned int IsAreaType(unsigned int input)					    
 * 																		
 ***********************************************************************
 * Description:	Checks if input is one of the storage area types,
 *              and returns 1 for true or 0 for false.			
 * 																		
 * Last Change: 01.04.2020 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/   
 unsigned int IsAreaType(unsigned int input)
 {
 	switch(input)
 	{
 		case CGOS_STORAGE_AREA_SDA:
		case CGOS_STORAGE_AREA_EEPROM_BIOS:
		case CGOS_STORAGE_AREA_RAM_BIOS:
		case CGOS_STORAGE_AREA_FLASH_STATIC:
		case CGOS_STORAGE_AREA_FLASH_DYNAMIC:
		case CGOS_STORAGE_AREA_FLASH_ALL:
		case CGOS_STORAGE_AREA_MPFA:
	 	case CGOS_STORAGE_AREA_EEPROM:
		case CGOS_STORAGE_AREA_FLASH:
		case CGOS_STORAGE_AREA_CMOS:
		case CGOS_STORAGE_AREA_MPFA_SETUP:
		case CGOS_STORAGE_AREA_RAM: return 1;
	 	default: return 0;	
	}
 }
 
/***********************************************************************
 * unsigned int IsAreaPresent(unsigned int input)					    
 * 																		
 ***********************************************************************
 * Description:	Checks if storage area type input is one of the storage 
 *              areas found by the driver. 
 *              The return values only work because the maximum value
 *              for stoCount is set to 16.
 * 																		
 * Last Change: 03.04.2020 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
 unsigned int IsAreaPresent(unsigned int input, CGOS_DRV_VARS *cdv)
 {
	unsigned int i;
	for(i = 0; i < cdv->brd->stoCount; i++)
	{
		if(cdv->brd->sto[i].info.type == input)
		{
			return 0x10 + i;
		}
	} 
	for(i = 0; i < cdv->brd->stoPrivCount; i++)
	{
		if(cdv->brd->stoPriv[i].info.type == input)
		{
			return 0x20 + i;
		}
	}
	return 0;	
 }
 
/***********************************************************************
 * unsigned int CheckParameters(CGOS_DRV_VARS *cdv, 
 *                              unsigned int *areaIndex, 
 *                              unsigned int *storageArea,
 *                              unsigned char index,
 *                              unsigned char length)					    
 * 																		
 ***********************************************************************
 * Description:	Checks if the storage area is addressed by its type
 *              or by its index and checks if all input parameters are
 *              legal.
 * 																		
 * Last Change: 29.05.2020 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/ 
unsigned int CheckParameters(CGOS_DRV_VARS *cdv, 
                             unsigned int *areaIndex, 
                             unsigned int *storageArea,
                             unsigned int index,
                             unsigned int length)
{
	//See if cdv->cin->type is an index or a storage area type
	if(IsAreaType(cdv->cin->type)) // storage area type
	{
		*areaIndex = IsAreaPresent(cdv->cin->type, cdv); 
		if(*areaIndex)
		{
			if(*areaIndex >= 0x20) //private Area
			{
				//Make sure only data within the storage area can be accessed
				if((index + length) > cdv->brd->stoPriv[*areaIndex & 0x0F].info.areaSize)
				{
					 return CGOS_ERROR;
				}
				else
				{
					*storageArea = cdv->cin->type;
				}			
			}
			else if(*areaIndex >= 0x10) //public Area
			{
				//Make sure only data within the storage area can be accessed
				if((index + length) > cdv->brd->sto[*areaIndex & 0x0F].info.areaSize)
				{
					 return CGOS_ERROR;
				}
				else
				{	
					*storageArea = cdv->cin->type;
				}
			}
			else
			{
				return CGOS_ERROR;
			}
		}
		else
		{
			return CGOS_ERROR;
		}
	}
	else 	// index
	{
		*areaIndex = cdv->cin->type;
		if(*areaIndex < cdv->brd->stoCount)
		{
			//Make sure only data within the storage area can be accessed
			if((index + length) > cdv->brd->sto[*areaIndex].info.areaSize)
			{
				 return CGOS_ERROR;
			}
			*storageArea = cdv->brd->sto[*areaIndex].info.type;
		}
		else
		{
			return CGOS_ERROR;
		}
	}
	return CGOS_SUCCESS;
}
/***********************************************************************
 * void addToStorageList(CGOS_DRV_VARS *cdv,
 *                       unsigned int size,
 *                       unsigned int type,
 *                       unsigned int flags,
 *                       unsigned int areaSize,
 *                       unsigned int blockSize,
 *                       unsigned char* mpfaStartPtr, 
 *                       unsigned int mpfaSectionSelect)
 ***********************************************************************
 * Description: 										
 * 																	
 * Last Change: 										
 * 																		
 * Modifications:														
 * 	-		
 ***********************************************************************/
void addToStorageList(CGOS_DRV_VARS *cdv, unsigned int size, unsigned int type, unsigned int flags, unsigned int areaSize, 
		      unsigned int blockSize, unsigned char* mpfaStartPtr, unsigned int mpfaSectionSelect)
  {
  	cdv->brd->sto[cdv->brd->stoCount].info.size = size;
	cdv->brd->sto[cdv->brd->stoCount].info.type = type;
	cdv->brd->sto[cdv->brd->stoCount].info.flags = flags;
	cdv->brd->sto[cdv->brd->stoCount].info.areaSize = areaSize;
	cdv->brd->sto[cdv->brd->stoCount].info.blockSize = blockSize;
	cdv->brd->sto[cdv->brd->stoCount].mpfaStartPtr = mpfaStartPtr;
	cdv->brd->sto[cdv->brd->stoCount].mpfaSectionSelect = mpfaSectionSelect;
	cdv->brd->stoCount++;
  }
  
/***********************************************************************
 * void addToPrivateStorageList(CGOS_DRV_VARS *cdv,
 *				unsigned int size,
 *                  	        unsigned int type,
 *                              unsigned int flags,
 *                              unsigned int areaSize,
 *                              unsigned int blockSize,
 *                              unsigned char* mpfaStartPtr, 
 *                              unsigned int mpfaSectionSelect)
 ***********************************************************************
 * Description: 										
 * 																	
 * Last Change: 										
 * 																		
 * Modifications:														
 * 	-		
 ***********************************************************************/
void addToPrivateStorageList(CGOS_DRV_VARS *cdv, unsigned int size, unsigned int type, unsigned int flags, unsigned int areaSize, 
		             unsigned int blockSize, unsigned char* mpfaStartPtr, unsigned int mpfaSectionSelect)
  {
  	cdv->brd->stoPriv[cdv->brd->stoPrivCount].info.size = size;
	cdv->brd->stoPriv[cdv->brd->stoPrivCount].info.type = type;
	cdv->brd->stoPriv[cdv->brd->stoPrivCount].info.flags = flags;
	cdv->brd->stoPriv[cdv->brd->stoPrivCount].info.areaSize = areaSize;
	cdv->brd->stoPriv[cdv->brd->stoPrivCount].info.blockSize = blockSize;
	cdv->brd->stoPriv[cdv->brd->stoPrivCount].mpfaStartPtr = mpfaStartPtr;
	cdv->brd->stoPriv[cdv->brd->stoPrivCount].mpfaSectionSelect = mpfaSectionSelect;
	cdv->brd->stoPrivCount++;
  }
 
/***********************************************************************
 * unsigned int initStoModule(CGOS_DRV_VARS *cdv) 					    
 * 																	
 ***********************************************************************
 * Description: 										
 * 																	
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 * 	-																	
 ***********************************************************************/
unsigned int initStoModule(CGOS_DRV_VARS *cdv)
  {
	unsigned char writeBuf;
	unsigned char readBuf[14];
	unsigned char stat;
	unsigned int i;
    
	dbgsto(printk("initStoModule called\n");)
	
	cdv->brd->stoCount = 0;
	cdv->brd->stoPrivCount = 0;
	
	writeBuf = CGBC_CMD_INFO_1;
	if(!bcCommand(&writeBuf,sizeof(writeBuf),&readBuf[0],sizeof(readBuf),&stat))
	{
		if(readBuf[6] != 0)	//Secure Data EEPROM supported
		{
			addToStorageList(cdv, sizeof(CGEB_STORAGEAREA_INFO), CGOS_STORAGE_AREA_SDA, 0, power(2,(readBuf[6] & 0x1F)), 0, NULL, 0);
		}
		
		if(readBuf[8] != 0) //User EEPROM supported
		{
			addToStorageList(cdv, sizeof(CGEB_STORAGEAREA_INFO), CGOS_STORAGE_AREA_EEPROM, 0, power(2,(readBuf[8] & 0x1F)), 0, NULL, 0);
		}
		
		if(readBuf[9] != 0) //BIOS parameter EEPROM supported
		{
			addToPrivateStorageList(cdv, sizeof(CGEB_STORAGEAREA_INFO), CGOS_STORAGE_AREA_EEPROM_BIOS, 0, power(2,(readBuf[9] & 0x1F)), 0, NULL, 0);
		}

		if(readBuf[11] != 0) //User RAM supported
		{
			addToStorageList(cdv, sizeof(CGEB_STORAGEAREA_INFO), CGOS_STORAGE_AREA_RAM, 0, power(2,(readBuf[11] & 0x1F)), 0, NULL, 0);
		}
		
		if(readBuf[12] != 0) //BIOS parameter RAM supported
		{
			addToPrivateStorageList(cdv, sizeof(CGEB_STORAGEAREA_INFO), CGOS_STORAGE_AREA_RAM_BIOS, 0, power(2,(readBuf[12] & 0x1F)), 0, NULL, 0);
		}
		
		//MPFA Area init 
		for (i = 0; i < cdv->binfoptr->cgdirMpfaCount; i++)
		{
			switch(cdv->brd->mpfaInfo[i].mpfaStorageType)
			{
			    case CGOS_STORAGE_AREA_FLASH_STATIC:  addToPrivateStorageList(cdv, 
			    								  cdv->brd->mpfaInfo[i].mpfaInfoSize, 
			    								  CGOS_STORAGE_AREA_FLASH_STATIC,
			    								  cdv->brd->mpfaInfo[i].mpfaFlags, 
			    								  cdv->brd->mpfaInfo[i].mpfaAreaSize,
			    								  cdv->brd->mpfaInfo[i].mpfaBlockSize, 
			    								  (unsigned char *)OsaMapAddress(cdv->brd->mpfaInfo[i].mpfaStartAddress, cdv->brd->mpfaInfo[i].mpfaAreaSize),
			    								  cdv->brd->mpfaInfo[i].mpfaSectionSelect);
								  break;
								 
			    case CGOS_STORAGE_AREA_FLASH_DYNAMIC: addToPrivateStorageList(cdv, 
			    								  cdv->brd->mpfaInfo[i].mpfaInfoSize, 
			    								  CGOS_STORAGE_AREA_FLASH_DYNAMIC,
			    								  cdv->brd->mpfaInfo[i].mpfaFlags, 
			    								  cdv->brd->mpfaInfo[i].mpfaAreaSize,
			    								  cdv->brd->mpfaInfo[i].mpfaBlockSize, 
			    								  (unsigned char *)OsaMapAddress(cdv->brd->mpfaInfo[i].mpfaStartAddress, cdv->brd->mpfaInfo[i].mpfaAreaSize),
			    								  cdv->brd->mpfaInfo[i].mpfaSectionSelect);
								  break;
								  
			    case CGOS_STORAGE_AREA_FLASH:         addToStorageList(cdv, 
			    							   cdv->brd->mpfaInfo[i].mpfaInfoSize, 
			    							   CGOS_STORAGE_AREA_FLASH,
			    							   cdv->brd->mpfaInfo[i].mpfaFlags, 
			    							   cdv->brd->mpfaInfo[i].mpfaAreaSize,
			    							   cdv->brd->mpfaInfo[i].mpfaBlockSize, 
			    							   (unsigned char *)OsaMapAddress(cdv->brd->mpfaInfo[i].mpfaStartAddress, cdv->brd->mpfaInfo[i].mpfaAreaSize),
			    							   cdv->brd->mpfaInfo[i].mpfaSectionSelect);
							          break;
							  
			    case CGOS_STORAGE_AREA_FLASH_ALL:     addToPrivateStorageList(cdv, 
			    								  cdv->brd->mpfaInfo[i].mpfaInfoSize, 
			    								  CGOS_STORAGE_AREA_FLASH_ALL,
			    								  cdv->brd->mpfaInfo[i].mpfaFlags, 
			    								  cdv->brd->mpfaInfo[i].mpfaAreaSize,
			    								  cdv->brd->mpfaInfo[i].mpfaBlockSize, 
			    								  (unsigned char *)OsaMapAddress(cdv->brd->mpfaInfo[i].mpfaStartAddress, cdv->brd->mpfaInfo[i].mpfaAreaSize),
			    								  cdv->brd->mpfaInfo[i].mpfaSectionSelect);
								  break;
								  
			    case CGOS_STORAGE_AREA_MPFA_SETUP:	  addToPrivateStorageList(cdv, 
			    								  cdv->brd->mpfaInfo[i].mpfaInfoSize, 
			    								  CGOS_STORAGE_AREA_MPFA_SETUP,
			    								  cdv->brd->mpfaInfo[i].mpfaFlags, 
			    								  cdv->brd->mpfaInfo[i].mpfaAreaSize,
			    								  cdv->brd->mpfaInfo[i].mpfaBlockSize, 
			    								  (unsigned char *)OsaMapAddress(cdv->brd->mpfaInfo[i].mpfaStartAddress, cdv->brd->mpfaInfo[i].mpfaAreaSize),
			    								  cdv->brd->mpfaInfo[i].mpfaSectionSelect);
								  break;
			    default: break; 
			}
		}
	}
	else
	{
		return CGOS_ERROR;
	} 
	
	return CGOS_SUCCESS;
  }  

/***********************************************************************
 * unsigned int zCgosStorageAreaCount(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/    
unsigned int zCgosStorageAreaCount(CGOS_DRV_VARS *cdv)
  {	
	unsigned int ret = 0;
	unsigned int i;

	dbgsto(printk("zCgosStorageAreaCount called\n");)

	if(cdv->cin->type == CGOS_STORAGE_AREA_UNKNOWN)
	{
		cdv->cout->rets[0] = cdv->brd->stoCount;
	}
	else
	{
		for(i = 0; i < cdv->brd->stoCount; i++)
		{
			if( cdv->brd->sto[i].info.type == cdv->cin->type)
			{
				ret++;
			}
		}
		cdv->cout->rets[0] = ret;
	}
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosStorageAreaType(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosStorageAreaType(CGOS_DRV_VARS *cdv)
  {
	dbgsto(printk("zCgosStorageAreaType called\n");)	
	cdv->cout->rets[0]=cdv->sto[cdv->cin->type].info.type;	
	return CGOS_SUCCESS;	
  }

/***********************************************************************
 * unsigned int zCgosStorageAreaSize(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosStorageAreaSize(CGOS_DRV_VARS *cdv)
  {	
	unsigned int areaNumber;
	dbgsto(printk("zCgosStorageAreaSize called\n");)	
	
	//See if cdv->cin->type is an index or a storage area type
	if(IsAreaType(cdv->cin->type)) //cdv->cin->type is storage area type
	{
		areaNumber = IsAreaPresent(cdv->cin->type,cdv);
		if(areaNumber >= 0x20) //private storage area
		{
			if((areaNumber & 0x0F) < cdv->brd->stoPrivCount)
			{
				cdv->cout->rets[0] = cdv->brd->stoPriv[areaNumber & 0x0F].info.areaSize;
				return CGOS_SUCCESS;
			}
			else 
			{
				return CGOS_ERROR;
			}
		}
		else if(areaNumber >= 0x10) //public storage area
		{
			if((areaNumber & 0x0F) < cdv->brd->stoCount)
			{
				cdv->cout->rets[0] = cdv->brd->sto[areaNumber & 0x0F].info.areaSize;
				return CGOS_SUCCESS;
			}
			else
			{
				return CGOS_ERROR;
			}		
		}
		else
		{
			return CGOS_ERROR;
		}
	}
	else //cdv->cin->type is index
	{
		if(cdv->cin->type < cdv->brd->stoCount) //index is valid
		{
			cdv->cout->rets[0] = cdv->sto[cdv->cin->type].info.areaSize;	
		}
		else
		{
			return CGOS_ERROR;
		}
	}		
	return CGOS_SUCCESS;	
  }

/***********************************************************************
 * unsigned int zCgosStorageAreaBlockSize(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosStorageAreaBlockSize(CGOS_DRV_VARS *cdv)
  {
	unsigned int areaNumber;
	dbgsto(printk("zCgosStorageAreaBlockSize called\n");)
	//See if cdv->cin->type is an index or a storage area type
	if(IsAreaType(cdv->cin->type)) //cdv->cin->type is storage area type
	{
		areaNumber = IsAreaPresent(cdv->cin->type, cdv);
		if(areaNumber >= 0x20) //private storage area
		{
			if((areaNumber & 0x0F) < cdv->brd->stoPrivCount)
			{
				cdv->cout->rets[0] = cdv->brd->stoPriv[areaNumber & 0x0F].info.blockSize;
				return CGOS_SUCCESS;
			}
			else
			{
				return CGOS_ERROR;
			}
		}
		else if(areaNumber >= 0x10) //public storage area
		{
			if((areaNumber & 0x0F) < cdv->brd->stoCount)
			{
				cdv->cout->rets[0] = cdv->brd->sto[areaNumber & 0x0F].info.blockSize;
				return CGOS_SUCCESS;
			}
			else
			{
				return CGOS_ERROR;
			}
		}
		else
		{
			return CGOS_ERROR;
		}
	}
	else //cdv->cin->type is index
	{
		cdv->cout->rets[0] = cdv->sto[cdv->cin->type].info.blockSize;
	}				
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosStorageAreaRead(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosStorageAreaRead(CGOS_DRV_VARS *cdv)
  {	
	unsigned int storageArea;
	unsigned int areaIndex;
	unsigned int index = cdv->cin->pars[0];
	unsigned int length = cdv->cin->pars[1];
	unsigned char* readPtr;
	unsigned int i;
	dbgsto(printk("zCgosStorageAreaRead called\n");)

	if(CheckParameters(cdv, &areaIndex, &storageArea, index, length) == CGOS_ERROR)
	{
		return CGOS_ERROR;
	}
	
	switch(storageArea)
	{
		case CGOS_STORAGE_AREA_SDA: 	
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_SDA_EEP_I2C_ADDR,index+i,(unsigned char*)cdv->pout + i);
						}
						cdv->retcnt += cdv->lout;
						break;
		case CGOS_STORAGE_AREA_EEPROM:
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_USER_EEP_I2C_ADDR,index+i,(unsigned char*)cdv->pout + i);
						}
						cdv->retcnt += cdv->lout;
						break;
		case CGOS_STORAGE_AREA_RAM:	
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_USER_RAM_I2C_ADDR,index+i,(unsigned char*)cdv->pout + i);
						}
						cdv->retcnt += cdv->lout;
						break;
		case CGOS_STORAGE_AREA_EEPROM_BIOS:	
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_BIOS_EEP_I2C_ADDR,index+i,(unsigned char*)cdv->pout + i);
						}
						cdv->retcnt += cdv->lout;
						break;
		case CGOS_STORAGE_AREA_RAM_BIOS:	
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_BIOS_RAM_I2C_ADDR,index+i,(unsigned char*)cdv->pout + i);
						}
						cdv->retcnt += cdv->lout;
						break;
		case CGOS_STORAGE_AREA_FLASH_STATIC:
						if(!cdv->biosInterfaceAvailable)
						{
							cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						}
						else
						{
							readPtr = cdv->brd->stoPriv[areaIndex & 0x0F].mpfaStartPtr + index;
							OsaMemCpy(cdv->pout, readPtr, length);
						
							cdv->retcnt += cdv->lout;
						}
						break;
		case CGOS_STORAGE_AREA_FLASH_DYNAMIC:
						if(!cdv->biosInterfaceAvailable)
						{
							cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						}
						else
						{
							readPtr = cdv->brd->stoPriv[areaIndex & 0x0F].mpfaStartPtr + index;
							OsaMemCpy(cdv->pout, readPtr, length);
						
							cdv->retcnt += cdv->lout;
						}
						break;
		case CGOS_STORAGE_AREA_FLASH:
						if (!cdv->biosInterfaceAvailable)
						{
							cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						}
						else
						{
							readPtr = cdv->brd->stoPriv[areaIndex & 0x0F].mpfaStartPtr + index;
							OsaMemCpy(cdv->pout, readPtr, length);
						
							cdv->retcnt += cdv->lout;
						}
						break;
		case CGOS_STORAGE_AREA_FLASH_ALL:
						if (!cdv->biosInterfaceAvailable)
						{
							cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						}
						else
						{
							readPtr = cdv->brd->stoPriv[areaIndex & 0x0F].mpfaStartPtr + index;
							OsaMemCpy(cdv->pout, readPtr, length);
						
							cdv->retcnt += cdv->lout;
						}
						break;
		case CGOS_STORAGE_AREA_MPFA_SETUP:
						if (!cdv->biosInterfaceAvailable)
						{
							cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						}
						else
						{
							readPtr = cdv->brd->stoPriv[areaIndex & 0x0F].mpfaStartPtr + index;
							OsaMemCpy(cdv->pout, readPtr, length);
						
							cdv->retcnt += cdv->lout;
						}
						break;
		default: break;
	}

	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosStorageAreaWrite(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosStorageAreaWrite(CGOS_DRV_VARS *cdv)
  {
	unsigned int storageArea;
	unsigned int areaIndex;
	unsigned int index = cdv->cin->pars[0];
	unsigned int length = cdv->cin->pars[1];
	unsigned int i;
	
	dbgsto(printk("zCgosStorageAreaWrite called\n");)

	if(CheckParameters(cdv, &areaIndex, &storageArea, index, length) == CGOS_ERROR)
	{
		return CGOS_ERROR;
	}

	switch(storageArea)
	{
		case CGOS_STORAGE_AREA_SDA:
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_SDA_EEP_I2C_ADDR,index+i,*((unsigned char*)cdv->pin + i));
								msleep(1);
							}
							break;
		case CGOS_STORAGE_AREA_EEPROM:
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_USER_EEP_I2C_ADDR,index+i,*((unsigned char*)cdv->pin + i));
								msleep(1);  
							}
							break;
		case CGOS_STORAGE_AREA_RAM:	
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_USER_RAM_I2C_ADDR,index+i,*((unsigned char*)cdv->pin + i));
							}
							break;
		case CGOS_STORAGE_AREA_EEPROM_BIOS:	
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_BIOS_EEP_I2C_ADDR,index+i,*((unsigned char*)cdv->pin + i));
								msleep(1);
							}
							break;
		case CGOS_STORAGE_AREA_RAM_BIOS:	
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_BIOS_RAM_I2C_ADDR,index+i,*((unsigned char*)cdv->pin + i));
							}
							break;
		case CGOS_STORAGE_AREA_FLASH_STATIC:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						
						break;
		case CGOS_STORAGE_AREA_FLASH_DYNAMIC:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
					
						break;
		case CGOS_STORAGE_AREA_FLASH:	
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						
						break;
		case CGOS_STORAGE_AREA_FLASH_ALL:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						
						break;
		case CGOS_STORAGE_AREA_MPFA_SETUP:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;

						break;
						
		default: break;
	}

	return CGOS_SUCCESS;
  }
  
/***********************************************************************
 * unsigned int zCgosStorageAreaErase(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosStorageAreaErase(CGOS_DRV_VARS *cdv)
  {
	unsigned int storageArea;
	unsigned int areaIndex;
	unsigned int index = cdv->cin->pars[0];
	unsigned int length = cdv->cin->pars[1];
	unsigned int i;

	dbgsto(printk("zCgosStorageAreaErase called\n");)

	if(CheckParameters(cdv, &areaIndex, &storageArea, index, length) == CGOS_ERROR)
	{
		return CGOS_ERROR;
	}

	switch(storageArea)
	{
		case CGOS_STORAGE_AREA_SDA:
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_SDA_EEP_I2C_ADDR,index+i,0xff);
								msleep(1);
							}
							break;
		case CGOS_STORAGE_AREA_EEPROM:
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_USER_EEP_I2C_ADDR,index+i,0xff);
								msleep(1); 
							}
							break;
		case CGOS_STORAGE_AREA_RAM:	
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_USER_RAM_I2C_ADDR,index+i,0xff);
							}
							break;
		case CGOS_STORAGE_AREA_EEPROM_BIOS:	
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_BIOS_EEP_I2C_ADDR,index+i,0xff);
								msleep(1);
							}
							break;
		case CGOS_STORAGE_AREA_RAM_BIOS:
							for(i = 0; i < length; i++)
							{
								CgosI2CWriteRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_BIOS_RAM_I2C_ADDR,index+i,0xff);
							}
     						break;
		case CGOS_STORAGE_AREA_FLASH_STATIC:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		case CGOS_STORAGE_AREA_FLASH_DYNAMIC:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		case CGOS_STORAGE_AREA_FLASH:	
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		case CGOS_STORAGE_AREA_FLASH_ALL:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		case CGOS_STORAGE_AREA_MPFA_SETUP:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		default: break;
	}


	return CGOS_SUCCESS;	
  }

/***********************************************************************
 * unsigned int zCgosStorageAreaEraseStatus(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:				
 * 																		
 * Last Change: 26.06.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosStorageAreaEraseStatus(CGOS_DRV_VARS *cdv)
  {
	unsigned int storageArea;
	unsigned int areaIndex;
	unsigned int index = cdv->cin->pars[0];
	unsigned int length = cdv->cin->pars[1];
	unsigned char rbuf;
	unsigned int i;
	unsigned char eraseStatus = 0;

	dbgsto(printk("zCgosStorageAreaEraseStatus called\n");)

	if(CheckParameters(cdv, &areaIndex, &storageArea, index, length) == CGOS_ERROR)
	{
		return CGOS_ERROR;
	}


	switch(storageArea)
	{
		case CGOS_STORAGE_AREA_SDA: 	
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_SDA_EEP_I2C_ADDR,index+i,&rbuf);
							if(rbuf != 0xff)
							{	
								eraseStatus = 1;
							}
						}
						if(eraseStatus == 0)
						{
							cdv->cout->rets[0] = 0; //return Area erased
						}
						else
						{
							cdv->cout->rets[0] = 2; //return Area not erased
						}
						break;
		case CGOS_STORAGE_AREA_EEPROM:
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_USER_EEP_I2C_ADDR,index+i,&rbuf);
							if(rbuf != 0xff)
							{	
								eraseStatus = 1;
							}
						}
						if(eraseStatus == 0)
						{
							cdv->cout->rets[0] = 0; //return Area erased
						}
						else
						{
							cdv->cout->rets[0] = 2; //return Area not erased
						}
						break;
		case CGOS_STORAGE_AREA_RAM:	
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_USER_RAM_I2C_ADDR,index+i,&rbuf);
							if(rbuf != 0xff)
							{	
								eraseStatus = 1;
							}
						}
						if(eraseStatus == 0)
						{
							cdv->cout->rets[0] = 0; //return Area erased
						}
						else
						{
							cdv->cout->rets[0] = 2; //return Area not erased
						}
						break;
		case CGOS_STORAGE_AREA_EEPROM_BIOS:	
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_BIOS_EEP_I2C_ADDR,index+i,&rbuf);
							if(rbuf != 0xff)
							{	
								eraseStatus = 1;
							}
						}
						if(eraseStatus == 0)
						{
							cdv->cout->rets[0] = 0; //return Area erased
						}
						else
						{
							cdv->cout->rets[0] = 2; //return Area not erased
						}
						break;
		case CGOS_STORAGE_AREA_RAM_BIOS:	
						for(i = 0; i < length; i++)
						{
							CgosI2CReadRegisterRaw(cdv, CGBC_I2C_BUS_INTERNAL,CG_BIOS_RAM_I2C_ADDR,index+i,&rbuf);
							if(rbuf != 0xff)
							{	
								eraseStatus = 1;
							}
						}
						if(eraseStatus == 0)
						{
							cdv->cout->rets[0] = 0; //return Area erased
						}
						else
						{
							cdv->cout->rets[0] = 2; //return Area not erased
						}
						break;
		case CGOS_STORAGE_AREA_FLASH_STATIC:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		case CGOS_STORAGE_AREA_FLASH_DYNAMIC:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		case CGOS_STORAGE_AREA_FLASH:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		case CGOS_STORAGE_AREA_FLASH_ALL:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		case CGOS_STORAGE_AREA_MPFA_SETUP:
						cdv->cout->status = CGOS_NOT_IMPLEMENTED;
						break;
		default: break;
	}

	return CGOS_SUCCESS;		
  }
 
/***********************************************************************
 * unsigned int zCgosStorageAreaLock(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: Used to read and/or write lock storage areas, so far 
 *              only works for cBC User Data EEPROM.				
 * 																		
 * Last Change: 										
 * 																		
 * Modifications:														
 ***********************************************************************/    
unsigned int zCgosStorageAreaLock(CGOS_DRV_VARS *cdv)					
  {	
	unsigned int storageArea;
	unsigned int index;
	unsigned char writeBuf[8] = {0};
	unsigned char lockConfig;
	unsigned int flags = cdv->cin->pars[0];
	unsigned int length = cdv->cin->pars[1];
	unsigned char stat;

	dbgsto(printk("zCgosStorageAreaLock called\n");)

	//See if cdv->cin->type is an index or a storage area type
	if(IsAreaType(cdv->cin->type))	// area type
	{
		index = IsAreaPresent(cdv->cin->type, cdv);
		if(index >= 0x20) //private storage area
		{
			if((index & 0x0F) < cdv->brd->stoPrivCount)
			{
				storageArea = cdv->brd->stoPriv[index & 0x0F].info.type;
			}
			else
			{
				cdv->cout->status = CGOS_ERROR;
				return CGOS_ERROR;
			}		
		}
		else if(index >= 0x10) //public storage area
		{
			if((index & 0x0F) < cdv->brd->stoCount)
			{
				storageArea = cdv->brd->sto[index & 0x0F].info.type;
			}
			else
			{
				cdv->cout->status = CGOS_ERROR;
				return CGOS_ERROR;
			}	
		}
		else
		{
			cdv->cout->status = CGOS_ERROR;
			return CGOS_ERROR;
		}
		index = index & 0x0F;
	}
	else	// index
	{
		index = cdv->cin->type;
		if(index < cdv->brd->stoCount)
		{
			storageArea = cdv->brd->sto[index].info.type;
	
		}
		else
		{
			cdv->cout->status = CGOS_ERROR;
			return CGOS_ERROR;
		}
	}

	//Check length of key string, max 6 bytes
	if(length > 6)
	{
		cdv->cout->status = CGOS_ERROR;
		return CGOS_ERROR;
	}

	switch(storageArea)
	{
		case CGOS_STORAGE_AREA_EEPROM:
						writeBuf[0] = 0x92; //CGBC_CMD_ADV_USER_LOCK for BC4
								            //CGBC_CMD_ACCESS_LOCK for GEN5
								    
						// Lock Configuration Byte, Bit set to 1 means locked, 0 unlocked.
						// Tampered bit: 0 means status OK, 1 means lock has been tampered with
						//               if tampered bit is set to 1 Access Lock Configuration Register is 
						//               blocked until the cBC firmware is restarted by a G3 power cycle.
						// Bit |  7   6   5   4   3  |      2     |    1    |      0      |
						//     | Reserved, must be 0 |read access |tampered |write access |
					    
					    //Get current access lock configuration
						if(!bcCommand(&writeBuf[0],8,NULL,0,&stat))
						{
							lockConfig = stat & 0x3F;
							
							if(lockConfig & 0x02) //tampered bit set to 1
							{	
								cdv->cout->status = CGOS_ERROR;
								return CGOS_ERROR;
							}
		 				}
						else
						{
							cdv->cout->status = CGOS_ERROR;
							return CGOS_ERROR;
						}
						
						//Set new configuration
						if(flags == CGOS_STORAGE_AREA_LEGACY_LOCK){	//Originally this function only used write lock and didn't use the flags parameter (set to 0)
							lockConfig = CGOS_STORAGE_AREA_WRITE_LOCK; 
						}
						else{ 
							if(flags & CGOS_STORAGE_AREA_WRITE_LOCK){
								lockConfig |= CGOS_STORAGE_AREA_WRITE_LOCK;
							}
							
							if(flags & CGOS_STORAGE_AREA_READ_LOCK){
								lockConfig |= CGOS_STORAGE_AREA_READ_LOCK;
							}
						}
						
						writeBuf[1] = lockConfig;
						OsaMemCpy(&writeBuf[2],(unsigned char*)cdv->pin,length);
						if(!bcCommand(&writeBuf[0],8,NULL,0,&stat))
						{
							if((stat & 0x3F) != lockConfig)	//lockConfig wasn't set correctly
							{
								cdv->cout->status = CGOS_ERROR;
								return CGOS_ERROR;
							}
						}
						else
						{
							cdv->cout->status = CGOS_ERROR;
							return CGOS_ERROR;
						}
						break;	
		default: 	cdv->cout->status = CGOS_ERROR;
				return CGOS_ERROR;
	}
	return CGOS_SUCCESS;
  }
 
/***********************************************************************
 * unsigned int zCgosStorageAreaUnlock(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: Used to unlock read/write access for storage areas, so 
 *              far only works for cBC User Data EEPROM.				
 * 																		
 * Last Change: 											
 * 																		
 * Modifications:														
 ***********************************************************************/    
unsigned int zCgosStorageAreaUnlock(CGOS_DRV_VARS *cdv)					
  {	
	unsigned int storageArea;
	unsigned int index;
	unsigned char writeBuf[8] = {0};
	unsigned int flags = cdv->cin->pars[0];
	unsigned int length = cdv->cin->pars[1];
	unsigned char lockConfig;
	unsigned char stat;

	dbgsto(printk("zCgosStorageAreaUnlock called\n");)

	//See if cdv->cin->type is an index or a storage area type
	if(IsAreaType(cdv->cin->type))
	{
		index = IsAreaPresent(cdv->cin->type, cdv);
		if(index >= 0x20) //private storage area
		{
			if((index & 0x0F) < cdv->brd->stoPrivCount)
			{
				storageArea = cdv->brd->stoPriv[index & 0x0F].info.type;
			}
			else
			{
				cdv->cout->status = CGOS_ERROR;
				return CGOS_ERROR;
			}
		}
		else if(index >= 0x10) //public storage area
		{
			if((index & 0x0F) < cdv->brd->stoCount)
			{
				storageArea = cdv->brd->sto[index & 0x0F].info.type;
			}
			else
			{
				cdv->cout->status = CGOS_ERROR;
				return CGOS_ERROR;
			}
		}
		else
		{
			cdv->cout->status = CGOS_ERROR;
			return CGOS_ERROR;
		}
		index = index & 0x0F;
	}
	else
	{
		if(cdv->cin->type < cdv->brd->stoCount)
		{
			index = cdv->cin->type;
			storageArea = cdv->brd->sto[index].info.type;
		}
		else
		{
			cdv->cout->status = CGOS_ERROR;
			return CGOS_ERROR;
		}	
	}

	//Check length of key string, max 6 bytes
	if(length > 6)
	{
		cdv->cout->status = CGOS_ERROR;
		return CGOS_ERROR;
	}

	switch(storageArea)
	{
		case CGOS_STORAGE_AREA_EEPROM:
						writeBuf[0] = 0x92; //CGBC_CMD_ADV_USER_LOCK for BC4
								    //CGBC_CMD_ACCESS_LOCK for GEN5
						
						// Lock Configuration Byte, Bit set to 1 means locked, 0 unlocked.
						// Bit |  7   6   5   4   3  |      2     |    1    |      0      |
						//     | Reserved, must be 0 |read access |reserved |write access |
						
						//Get current access lock configuration
						if(!bcCommand(&writeBuf[0],8,NULL,0,&stat))
						{
							lockConfig = stat & 0x3F;
							
							if(lockConfig & 0x02) //tampered bit set to 1
							{	
								cdv->cout->status = CGOS_ERROR;
								return CGOS_ERROR;
							}
		 				}
						else
						{
							cdv->cout->status = CGOS_ERROR;
							return CGOS_ERROR;
						}
						
						//Set new configuration
						if(flags == CGOS_STORAGE_AREA_LEGACY_UNLOCK)
						{
							lockConfig = CGOS_STORAGE_AREA_LEGACY_UNLOCK;
						}
 						else
						{
 							if(flags & CGOS_STORAGE_AREA_WRITE_UNLOCK)
							{
 								lockConfig &= ~CGOS_STORAGE_AREA_WRITE_UNLOCK;
							}
							
							if(flags & CGOS_STORAGE_AREA_READ_UNLOCK)
							{
								lockConfig &= ~CGOS_STORAGE_AREA_READ_UNLOCK;
							}	
						}
						
						writeBuf[1] = lockConfig;
						OsaMemCpy(&writeBuf[2],(unsigned char*)cdv->pin,length);
						if(!bcCommand(&writeBuf[0],8,NULL,0,&stat))
						{
							if((stat & 0x3F) != lockConfig)	//lockConfig wasn't set correctly
							{
								cdv->cout->status = CGOS_ERROR;
								return CGOS_ERROR;
							}
		 				}
						else
						{
							cdv->cout->status = CGOS_ERROR;
							return CGOS_ERROR;
						}
						break;	
		default: 	cdv->cout->status = CGOS_ERROR;
				return CGOS_ERROR;
	}	
	return CGOS_SUCCESS;
  }
  
/***********************************************************************
 * unsigned int zCgosStorageAreaIsLocked(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description:	Returns Read/Write lock status, so far only works for
 *              cBC User Data EEPROM.	
 * 																		
 * Last Change: 										
 * 																		
 * Modifications:														
 ***********************************************************************/    
unsigned int zCgosStorageAreaIsLocked(CGOS_DRV_VARS *cdv)					
  {

	unsigned int storageArea;
	unsigned char writeBuf[8] = {0};
	unsigned char lockConfig = 0;
	unsigned char stat;
	
	dbgsto(printk("zCgosStorageAreaIsLocked called\n");)	

	//Check if input is 
	if(IsAreaType(cdv->cin->type)) //input is storage area type
	{
		storageArea = cdv->cin->type;
	}
	else	//input is index
	{
		if (cdv->cin->type < cdv->brd->stoCount)	
		{
			storageArea = cdv->brd->sto[cdv->cin->type].info.type;
		}
		else //index out of bounds
		{
			return CGOS_ERROR;
		}
	}
	
	switch(storageArea)
	{
		case CGOS_STORAGE_AREA_EEPROM:
						writeBuf[0] = 0x92; //CGBC_CMD_ADV_USER_LOCK for BC4
								    //CGBC_CMD_ACCESS_LOCK for GEN5
						
						// Lock Configuration Byte, Bit set to 1 means locked, 0 unlocked.
						// Bit |  7   6   5   4   3  |      2     |    1    |      0      |
						//     | Reserved, must be 0 |read access |reserved |write access |
						
						//Get current access lock configuration
						if(!bcCommand(&writeBuf[0],8,NULL,0,&stat))
						{
							lockConfig = stat & 0x3F;
		 				}
						else
						{
							cdv->cout->status = CGOS_ERROR;
							return CGOS_ERROR;
						}
						
						//return lockConfig
						cdv->cout->rets[0] = lockConfig;
						
						break;	
		default: 	cdv->cout->rets[0] = 0;
	}	
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * void exitStoModule(CGOS_DRV_VARS *cdv) 							    
 * 																		
 ***********************************************************************
 * Description: This function is called during driver close and should	
 * 				free allocated resources.								
 * 																		
 * Last Change: 12.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
void exitStoModule(CGOS_DRV_VARS *cdv)
{
	unsigned int i;
	
	dbgsto(printk("exitStoModule called\n");)
	
	for(i = 0; i < cdv->brd->stoPrivCount; i++)
	{
		if((cdv->brd->stoPriv[i].info.type == CGOS_STORAGE_AREA_FLASH_STATIC)||
		   (cdv->brd->stoPriv[i].info.type == CGOS_STORAGE_AREA_FLASH_DYNAMIC)||
		   (cdv->brd->stoPriv[i].info.type == CGOS_STORAGE_AREA_FLASH_ALL)||
		   (cdv->brd->stoPriv[i].info.type == CGOS_STORAGE_AREA_MPFA_SETUP))
		{
			OsaUnMapAddress(cdv->brd->stoPriv[i].mpfaStartPtr, cdv->brd->stoPriv[i].info.areaSize);
		}
	}
	for(i = 0; i < cdv->brd->stoCount; i++)
	{
		if(cdv->brd->sto[i].info.type == CGOS_STORAGE_AREA_FLASH)
		{
			OsaUnMapAddress(cdv->brd->sto[i].mpfaStartPtr, cdv->brd->sto[i].info.areaSize);
		}
	}
	
}
