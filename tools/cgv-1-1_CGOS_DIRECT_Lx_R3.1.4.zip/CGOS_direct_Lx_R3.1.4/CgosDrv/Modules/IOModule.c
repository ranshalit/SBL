/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2022, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 

#ifdef __linux__
#include <linux/printk.h> 
#include <linux/module.h>
#endif
 
#include "../CgosDrv.h"		//MOD_3.1.2_3
#include "../CGBC.h"		//MOD_3.1.2_3
#include "BCModule.h"
#include "IOModule_cfg.h"

//***************************************************************************

//#define dbg_io_on

#ifdef dbg_io_on
	#define dbgio(x) x
#else
	#define dbgio(x)
#endif

//***************************************************************************
//Function Prototypes

unsigned int initIOModule(CGOS_DRV_VARS *cdv);   
unsigned int zCgosIOCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosIORead(CGOS_DRV_VARS *cdv);
unsigned int zCgosIOWrite(CGOS_DRV_VARS *cdv); 
unsigned int zCgosIOGetDirection(CGOS_DRV_VARS *cdv);						
unsigned int zCgosIOSetDirection(CGOS_DRV_VARS *cdv);
unsigned int zCgosIOIsAvailable(CGOS_DRV_VARS *cdv);
unsigned int zCgosIOGetDirectionCaps(CGOS_DRV_VARS *cdv);
void exitIOModule(CGOS_DRV_VARS *cdv);

//***************************************************************************

/***********************************************************************
 * unsigned int initIOModule(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: Initializes the IO Module	
 * 																		
 * Last Change: 										
 * 																		
 * Modifications:														
 * 	- 																	
 ***********************************************************************/
unsigned int initIOModule(CGOS_DRV_VARS *cdv)
{
	unsigned int retSuccess = CGOS_SUCCESS;
	
	dbgio(printk("initIOModule called\n");)
	
	if (!(cdv->biosInterfaceAvailable && (cdv->binfoptr->cgdirInterfaceRevision >= 2)))	//If Interface and IO information are available IO init is done in CgosDrv.c 
	{
		if (IO_COUNT_BC <= CGOS_DRV_IO_MAX)		//CGOS_DRV_IO_MAX defined in DrvVars.h
		{
			cdv->brd->ioCount = IO_COUNT_BC;
			if ((cdv->brd->info.szBoard[0] == 'S') && (cdv->brd->info.szBoard[1] == 'A') && (cdv->brd->info.szBoard[2] == '7') && (cdv->brd->info.szBoard[3] == '0'))
			{
				OsaMemCpy(&cdv->brd->iocaps[0], &IO_CAPS_BC_SA70[0], IO_COUNT_BC * sizeof(CGOS_DRV_IO_DIR_CAPS));
			}
			else if ((cdv->brd->info.szBoard[0] == 'G') && (cdv->brd->info.szBoard[1] == 'A') && (cdv->brd->info.szBoard[2] == 'L') && ((cdv->brd->info.szBoard[3] == 'S')||(cdv->brd->info.szBoard[3] == 'P')))
			{
				OsaMemCpy(&cdv->brd->iocaps[0], &IO_CAPS_BC_AL[0], IO_COUNT_BC * sizeof(CGOS_DRV_IO_DIR_CAPS));
			}
			else
			{
				OsaMemCpy(&cdv->brd->iocaps[0], &IO_CAPS_BC[0], IO_COUNT_BC * sizeof(CGOS_DRV_IO_DIR_CAPS));
			}
		}
		else
		{
			retSuccess = CGOS_ERROR;
		}
	}

	return retSuccess;
}

/***********************************************************************
 * unsigned int zCgosIOCount(CGOS_DRV_VARS *cdv)		  				
 * 																		
 ***********************************************************************
 * Description: Returns Number of IO Units			
 * 																		
 * Last Change: 										
 * 																		
 * Modifications:														
 ***********************************************************************/    
unsigned int zCgosIOCount(CGOS_DRV_VARS *cdv)
  {
	dbgio(printk("zCgosIOCount called\n");)
        cdv->cout->rets[0] = cdv->brd->ioCount;
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosIORead(CGOS_DRV_VARS *cdv)					  		
 * 																		
 ***********************************************************************
 * Description: Calls CgosIORead from the chosen SubModule.			
 * 																		
 * Last Change: 24.01.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosIORead(CGOS_DRV_VARS *cdv)
{
	unsigned char wbuf[3];
	unsigned char sts;
	unsigned char ret;
	unsigned char rets;
	unsigned int CgosGPIOUnit = cdv->cin->type;
	unsigned int i;
	
	dbgio(printk("zCgosIORead called\n");)

	cdv->cout->rets[0] = 0;	//Clear output Buffer
	if(CgosGPIOUnit < cdv->brd->ioCount)
	{	
		for(i = 0; i < 4; i++)
		{
			wbuf[0] = CGBC_CMD_GPIO_DAT_RD;
			wbuf[1] = i+(4*CgosGPIOUnit);
			wbuf[2] = 0x00;
	       
			ret = bcCommand(&wbuf[0],3,&rets,1,&sts);
			if(ret != CGOS_SUCCESS)
			{
				break;
			}
			else
			{
			 	cdv->cout->rets[0] |= (rets<<8*i);
			}
		}
		return CGOS_SUCCESS; 
	}
	else
	{
		return CGOS_ERROR;
	}
}

/***********************************************************************
 * unsigned int zCgosIOWrite(CGOS_DRV_VARS *cdv)				  		
 * 																		
 ***********************************************************************
 * Description: Calls CgosIOWrite from the chosen SubModule.			
 * 																		
 * Last Change: 24.01.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosIOWrite(CGOS_DRV_VARS *cdv)
  {
	unsigned char wbuf[3];
	unsigned char sts;
	unsigned char ret;
	unsigned char rets;
	unsigned int CgosGPIOUnit = cdv->cin->type;
	unsigned int i;
	
	dbgio(printk("zCgosIOWrite called\n");)

	if(CgosGPIOUnit < cdv->brd->ioCount)
	{	
		for(i = 0; i < 4; i++)
		{
			wbuf[0] = CGBC_CMD_GPIO_DAT_WR;
			wbuf[1] = i+(4*CgosGPIOUnit);
			wbuf[2] = (cdv->cin->pars[0] >> (8 * i)) & 0xFF;

			ret = bcCommand(&wbuf[0],3,&rets,1,&sts); 
			if(ret != CGOS_SUCCESS)
			{
				break;
			}	
		}
		return CGOS_SUCCESS;
	}
	else
	{
		return CGOS_ERROR;
	}
  }

/***********************************************************************
 * unsigned int zCgosIOGetDirection(CGOS_DRV_VARS *cdv)			  		
 * 																		
 ***********************************************************************
 * Description: Calls CgosIOGetDirecton from the chosen SubModule.		
 * 																		
 * Last Change: 24.01.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosIOGetDirection(CGOS_DRV_VARS *cdv)
  {
	unsigned char wbuf[3];
	unsigned char sts;
	unsigned char ret;
	unsigned char rets;
	unsigned int CgosGPIOUnit = cdv->cin->type;
	unsigned int i;
	
	dbgio(printk("zCgosIOGetDirection called\n");)
	
	cdv->cout->rets[0] = 0;	//Clear output Buffer
	if(CgosGPIOUnit < cdv->brd->ioCount)
	{
		for(i = 0; i < 4; i++)
		{
			wbuf[0] = CGBC_CMD_GPIO_CFG_RD;
			wbuf[1] = i+(4*CgosGPIOUnit);
			wbuf[2] = 0x00;
	
			ret = bcCommand(&wbuf[0],3,&rets,1,&sts);
			if(ret != CGOS_SUCCESS)
			{
				break;
			}
			else
			{
				
				cdv->cout->rets[0] |= (((~rets)&0xFF)<<(8*i)); //Toggle Pin state due to different interpretation
			       	                    		               //from Cgos and cBC. //MOD25
			}
	 	}
		return CGOS_SUCCESS; 	//MOD25 changed ret to CGOS_SUCCESS
	}
	else
	{
		return CGOS_ERROR;
	}
  }

/***********************************************************************
 * unsigned int zCgosIOSetDirectionCGOS_DRV_VARS *cdv)			  		
 * 																		
 ***********************************************************************
 * Description: Calls CgosIOSetDirecton from the chosen SubModule.		
 * 																		
 * Last Change: 24.01.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosIOSetDirection(CGOS_DRV_VARS *cdv)
  {
	unsigned char wbuf[3];
	unsigned char sts;
	unsigned char ret;
	unsigned char rets;
	unsigned int CgosGPIOUnit = cdv->cin->type;
	unsigned int i;

	dbgio(printk("zCgosIOSetDirection called\n");)

	if(CgosGPIOUnit < cdv->brd->ioCount)
	{
		for(i = 0; i < 4; i++)
		{
			wbuf[0] = CGBC_CMD_GPIO_CFG_WR;
			wbuf[1] = i+(4*CgosGPIOUnit);
			wbuf[2] = (~cdv->cin->pars[0] >> (8 * i)) & 0xFF; //Toggle due to different interpretation from cgos and cBC.
			
			ret = bcCommand(&wbuf[0],3,&rets,1,&sts);
			if(ret != CGOS_SUCCESS)
			{
				break;
			}
		}	
		return CGOS_SUCCESS; 	//MOD25 changed ret to CGOS_SUCCESS
	}
	else
	{
		return CGOS_ERROR;
	}
  }

/***********************************************************************
 * unsigned int zCgosIOIsAvailable(CGOS_DRV_VARS *cdv)			  		
 * 																		
 ***********************************************************************
 * Description: Calls CgosIOIsAvailable from the chosen SubModule.		
 * 																		
 * Last Change: 24.01.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosIOIsAvailable(CGOS_DRV_VARS *cdv)
  {
	dbgio(printk("zCgosIOIsAvailable called\n");)
	cdv->cout->rets[0] = cdv->cin->type < cdv->brd->ioCount;
	return CGOS_SUCCESS;
  }
  
/***********************************************************************
 * unsigned int zCgosIOGetDirectionCaps(CGOS_DRV_VARS *cdv)		  		
 * 																		
 ***********************************************************************
 * Description: Calls CgosIOGetDirectonCaps from the chosen SubModule.	
 * 																		
 * Last Change: 24.01.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosIOGetDirectionCaps(CGOS_DRV_VARS *cdv)
  {  
	unsigned int retSuccess = CGOS_SUCCESS;

	dbgio(printk("zCgosIOGetDirectionCaps called\n");)

	if(cdv->cin->type < cdv->brd->ioCount)
	{
		cdv->cout->rets[0] = cdv->brd->iocaps[cdv->cin->type].in;
		cdv->cout->rets[1] = cdv->brd->iocaps[cdv->cin->type].out;
	}
	else
	{
		retSuccess = CGOS_ERROR;
	}
	return retSuccess;
  }

/***********************************************************************
 * void exitIOModule(CGOS_DRV_VARS *cdv)		  						
 * 																		
 ***********************************************************************
 * Description: Calls exitIOModule from the chosen SubModule.			
 * 																		
 * Last Change: 24.01.2018 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
void exitIOModule(CGOS_DRV_VARS *cdv)
{
	dbgio(printk("exitIOModule called\n");)

}
