/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2025, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 

#ifdef __linux__
#include <linux/printk.h> 
#include <linux/module.h>
#else
#include <Windows.h>
#include <tchar.h>
#include <stdlib.h>
#define true TRUE
#define false FALSE
#endif
 //MOD_3.1.2_3 v
#include "../CgosDrv.h"
#include "../CGBC.h"
//MOD_3.1.2_3 ^	
#include "BCModule.h"

#ifdef _WIN64
#include <stdio.h>

#undef UINT8
#undef UINT16
#endif
//***************************************************************************

//#define dbg_cup_on

#ifdef dbg_cup_on
	#define dbgcup(x) x
#else
	#define dbgcup(x)
#endif

//***************************************************************************
// 
//Function prototypes

unsigned int CgosGenerateSwSmi(unsigned long Rsi);
unsigned int initCUPModule(CGOS_DRV_VARS *cdv);  
unsigned int zCgosUpdateCaps(CGOS_DRV_VARS *cdv);  
unsigned int zCgosTriggerCapsuleUpdate(CGOS_DRV_VARS *cdv);
unsigned int zCgosCapsuleUpdateBiosCaps(CGOS_DRV_VARS *cdv);
unsigned int zCgosCapsuleUpdateBiosTrigger(CGOS_DRV_VARS *cdv);
void exitCUPModule(CGOS_DRV_VARS *cdv);

//***************************************************************************

unsigned int CgosGenerateSwSmi(unsigned long Rsi)
{
  	unsigned long BiosRetValue = 0;
	unsigned long Rax = 0x73;
	unsigned long Rbx = 0x21;
	unsigned long Rdx = 0x4D504641;
	
#ifdef __linux__			
	asm volatile ("movq %1,%%rax\n\t"
		"movq %2,%%rbx\n\t"
		"movq %3,%%rdx\n\t"
		"movq %4,%%rsi\n\t"
		"outb %%al,$0xB2\n\t"
		"movq %%rax, %0"
		:"=r"(BiosRetValue)
		: "r"(Rax), "r"(Rbx), "r"(Rdx), "r"(Rsi)
		: "%rax", "%rbx", "%rdx", "%rsi", "cc"
		);
	if (!BiosRetValue)
	{
		return CGOS_ERROR;
	}
#else //Windows
	extern unsigned long volatile GenerateSwSmi(unsigned long Rax, unsigned long Rbx, unsigned long Rdx, unsigned long Rsi);
	Rax = GenerateSwSmi(Rax, Rbx, Rdx, Rsi);
#endif //__linux__

	return CGOS_SUCCESS;
}

/***********************************************************************
 * unsigned int initCUPModule(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: 		
 * 																		
 * Last Change:											
 * 																		
 * Modifications:														
 * 	- 																	
 ***********************************************************************/
unsigned int initCUPModule(CGOS_DRV_VARS *cdv)
{
	unsigned int retSuccess = CGOS_SUCCESS;
	dbgcup(printk("initCUPModule called\n");)

	return retSuccess;
}

/***********************************************************************
 * unsigned int zCgosUpdateCaps(CGOS_DRV_VARS *cdv)		  				
 * 																		
 ***********************************************************************
 * Description:		
 * 																		
 * Last Change: 										
 * 																		
 * Modifications:														
 ***********************************************************************/    
unsigned int zCgosUpdateCaps(CGOS_DRV_VARS *cdv)
  {
	dbgcup("CgosUpdateCaps called\n");
	cdv->cout->rets[0] = 0; //Clear Output Buffer
	if(cdv->biosInterfaceAvailable == true)
	{
		if(cdv->binfoptr->cgdirLegacyUpdateEnabled == true)
		{
			cdv->cout->rets[0] |= CGOS_LEGACY_UPDATE_BIOS;
		}
		
		if(cdv->binfoptr->cgdirCapsuleUpdateEnabled == true)
		{
			cdv->cout->rets[0] |= CGOS_CAPSULE_UPDATE_BIOS;
		}
		
		/*if()	//Other Capsule Updates like cBC might be added in the future
		{
			cdv->cout->rets[0] |= ;
		}*/
	}
	else	//Without interface enabled the driver can't tell if updates are supported
	{
		cdv->cout->rets[0] = CGOS_CAPSULE_UPDATE_NOT_SUPPORTED;
	}
		
	return CGOS_SUCCESS;
  }
  
/***********************************************************************
 * unsigned int zCgosTriggerCapsuleUpdate(CGOS_DRV_VARS *cdv)		  				
 * 																		
 ***********************************************************************
 * Description: Calls zCgosTriggerCapsuleUpdate from the chosen SubModule.			
 * 																		
 * Last Change: 										
 * 																		
 * Modifications:														
 ***********************************************************************/    
unsigned int zCgosTriggerCapsuleUpdate(CGOS_DRV_VARS *cdv)
  {
	unsigned long Rsi = 0;
	unsigned int update = cdv->cin->pars[0];
	unsigned int autoRestart = cdv->cin->pars[1];

	dbgcup("CgosTriggerCapsuleUpdate called\n");

	if (update == CGOS_CAPSULE_UPDATE_BIOS)
	{
		if ((autoRestart == 0) || (autoRestart == 1))
		{

			Rsi = autoRestart;
			CgosGenerateSwSmi(Rsi);
		}
		else
		{
			return CGOS_ERROR;
		}
	}
	else if(update == CGOS_CAPSULE_UPDATE_BC)
	{
		//Add BC Capsule Update Mechanism
	}
	else if(update == CGOS_CAPSULE_UPDATE_MPFA)
	{
		//Add MPFA Capsule Update Mechanism
	}
	else
	{
		return CGOS_ERROR;
	}
	return CGOS_SUCCESS;
  }  
  
/***********************************************************************
 * unsigned int zCgosCapsuleUpdateBiosCaps(CGOS_DRV_VARS *cdv)		  				
 * 																		
 ***********************************************************************
 * Description: Returns BIOS capsule update capabilities.			
 * 																		
 * Output: cdv->cout->rets[0] <-> pdwCaps0
 *         cdv->cout->rets[1] <-> pdwCaps1 
 *														
 ***********************************************************************/  
unsigned int zCgosCapsuleUpdateBiosCaps(CGOS_DRV_VARS *cdv)
{
	dbgcup("zCgosCapsuleUpdateBiosCaps called\n");
	
	if (cdv->biosInterfaceAvailable && (cdv->binfoptr->cgdirInterfaceRevision >= 2))
	{
		cdv->cout->rets[0] = cdv->binfoptr->cgdirBiosCapsuleUpdateFlags0;
		cdv->cout->rets[1] = cdv->binfoptr->cgdirBiosCapsuleUpdateFlags1;
		return CGOS_SUCCESS;
	}
	else
	{
		return CGOS_ERROR;
	}
}

/***********************************************************************
 * unsigned int zCgosCapsuleUpdateBiosTrigger(CGOS_DRV_VARS *cdv)		  				
 * 																		
 ***********************************************************************
 * Description: Triggers a BIOS capsule update		
 * 																		
 * Input: dwFlags0 <-> cdv->cin->pars[0]
 *        dwFlags1 <-> cdv->cin->pars[1]				
 *										
 ***********************************************************************/  
unsigned int zCgosCapsuleUpdateBiosTrigger(CGOS_DRV_VARS *cdv)
{
	unsigned int dwFlags0 = cdv->cin->pars[0];
	//unsigned int dwFlags1 = cdv->cin->pars[1];	//For future use 

	dbgcup("zCgosCapsuleUpdateBiosTrigger called\n");

	CgosGenerateSwSmi(dwFlags0);
	
	return CGOS_SUCCESS;
}

/***********************************************************************
 * void exitCUPModule(CGOS_DRV_VARS *cdv)		  						
 * 																		
 ***********************************************************************
 * Description: Calls exitCUPModule from the chosen SubModule.			
 * 																		
 * Last Change: 											
 * 																		
 * Modifications:														
 ***********************************************************************/  
void exitCUPModule(CGOS_DRV_VARS *cdv)
{
	dbgcup(printk("exitCUPModule called\n");)
}
