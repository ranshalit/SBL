/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2025, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 
 
#ifdef __linux__
#include <linux/printk.h> 
#endif

#include "../CgosDrv.h"		//MOD_3.1.2_3
#include "../CGBC.h"		//MOD_3.1.2_3
#include "BCModule.h"
#include "I2CModule_BC_cfg.h"
#include "I2CModule_GEN5_BC_cfg.h"

//***************************************************************************

//#define dbg_i2c_on

#ifdef dbg_i2c_on
    #define dbgi2c(x) x
#else
    #define dbgi2c(x)
#endif

//***************************************************************************
//Function Prototypes

unsigned int initI2CModule(CGOS_DRV_VARS *cdv);
unsigned int zCgosI2CCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosI2CIsAvailable(CGOS_DRV_VARS *cdv);
unsigned int I2CBusGetStatus(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char *pSts);
unsigned int zCgosI2CType(CGOS_DRV_VARS *cdv);

unsigned int CgosI2CReadRaw(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char cnt);
unsigned int CgosI2CReadRaw_BC4(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char cnt);
unsigned int CgosI2CReadRaw_EXT(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char cnt);
unsigned int zCgosI2CRead(CGOS_DRV_VARS *cdv);

unsigned int CgosI2CWriteRaw(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char len);
unsigned int CgosI2CWriteRaw_BC4(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char len);
unsigned int CgosI2CWriteRaw_EXT(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char len);
unsigned int zCgosI2CWrite(CGOS_DRV_VARS *cdv);

unsigned int CgosI2CReadRegisterRaw(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned char wReg, unsigned char *PDataByte);
unsigned int CgosI2CReadRegisterRaw_BC4(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned char wReg, unsigned char* PDataByte);
unsigned int CgosI2CReadRegisterRaw_EXT(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned char wReg, unsigned char* PDataByte);
unsigned int zCgosI2CReadRegister(CGOS_DRV_VARS *cdv);

unsigned int CgosI2CWriteRegisterRaw(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned short wReg, unsigned char bData);
unsigned int CgosI2CWriteRegisterRaw_BC4(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned short wReg, unsigned char bData);
unsigned int CgosI2CWriteRegisterRaw_EXT(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned short wReg, unsigned char bData);
unsigned int zCgosI2CWriteRegister(CGOS_DRV_VARS *cdv); 

unsigned int zCgosI2CWriteReadCombined(CGOS_DRV_VARS *cdv); 
unsigned int CgosI2CWriteReadCombined_BC4(CGOS_DRV_VARS* cdv);
unsigned int CgosI2CWriteReadCombined_EXT(CGOS_DRV_VARS* cdv);

unsigned int zCgosI2CFastCombined(CGOS_DRV_VARS *cdv);
unsigned int CgosI2CFastCombined_BC4(CGOS_DRV_VARS* cdv);
unsigned int CgosI2CFastCombined_EXT(CGOS_DRV_VARS* cdv);

unsigned int zCgosI2CGetMaxFrequency(CGOS_DRV_VARS *cdv);

unsigned int zCgosI2CGetFrequency(CGOS_DRV_VARS *cdv);
unsigned int CgosI2CGetFrequency_BC4(CGOS_DRV_VARS* cdv);
unsigned int CgosI2CGetFrequency_EXT(CGOS_DRV_VARS* cdv);

unsigned int zCgosI2CSetFrequency(CGOS_DRV_VARS *cdv);
unsigned int CgosI2CSetFrequency_BC4(CGOS_DRV_VARS* cdv);
unsigned int CgosI2CSetFrequency_EXT(CGOS_DRV_VARS* cdv);

void exitI2CModule(CGOS_DRV_VARS *cdv);

//***************************************************************************

/***********************************************************************
 * unsigned int initI2CModule(CGOS_DRV_VARS *cdv)                       
 *                                                                      
 ***********************************************************************
 * Description: This function is called to copy information from        
 *              I2CModule_cfg.h into the cdv struct if necessary.                    
 *                                                                      
 * Last Change: 12.12.2017 HMI                                          
 *                                                                      
 * Modifications:                                                       
 ***********************************************************************/
unsigned int initI2CModule(CGOS_DRV_VARS *cdv)
  {
    	unsigned int retSuccess = CGOS_SUCCESS;
    	dbgi2c("initI2CModule called\n");
    	
    	if(!(cdv->biosInterfaceAvailable && (cdv->binfoptr->cgdirInterfaceRevision >= 2)))   //If Interface and I2C information are available I2C init is done in CgosDrv.c 
	    {
            if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E))
            {
                if (I2C_COUNT <= CGOS_DRV_I2C_TABLE_MAX)     //CGOS_DRV_I2C_TABLE_MAX defined in DrvVars.h
                {
                    cdv->brd->i2cCount = I2C_COUNT;
                    OsaMemCpy(cdv->i2c, &I2C_TABLE, I2C_COUNT * sizeof(CGOS_DRV_I2C_ENTRY));    //May cause alignment problems
                }
                else
                {
                    retSuccess = CGOS_ERROR;
                }
            }
            else if (cdv->brd->BC_Type == BC_TYPE_GEN5)
            {
                if (I2C_GEN5_COUNT <= CGOS_DRV_I2C_TABLE_MAX)     //CGOS_DRV_I2C_TABLE_MAX defined in DrvVars.h
                {
                    cdv->brd->i2cCount = I2C_GEN5_COUNT;
                    OsaMemCpy(cdv->i2c, &I2C_GEN5_TABLE, I2C_GEN5_COUNT * sizeof(CGOS_DRV_I2C_ENTRY));    //May cause alignment problems
                }
                else
                {
                    retSuccess = CGOS_ERROR;
                }
            }
            else
            {
                retSuccess = CGOS_ERROR;
            }
        }
    return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosI2CCount(CGOS_DRV_VARS *cdv)                       
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CCount(HCGOS hCgos)                             
 *                                                                      
 * Inputs:                                                              
 *   -                                                                  
 *                                                                      
 * Output:                                                              
 * cdv->cout->rets[0]                                                   
 *                                                                     
 ***********************************************************************
 * Description: Returns the i2c count.                                     
 *                                                                      
 * Last Change: 06.12.2017 HMI                                          
 *                                                                      
 * Modifications:                                                       
 ***********************************************************************/ 
unsigned int zCgosI2CCount(CGOS_DRV_VARS *cdv)
  {
    dbgi2c(printk("zCgosI2CCount called\n");)   
    cdv->cout->rets[0]=cdv->brd->i2cCount;
    return CGOS_SUCCESS;
  }
 
/***********************************************************************
 * unsigned int zCgosI2CIsAvailable(CGOS_DRV_VARS *cdv)                 
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CIsAvailable(HCGOS hCgos,                       
 *                                   unsigned long dwUnit)              
 *                                                                      
 * Inputs:                                                              
 * dwUnit <->   cdv->cin->type                                          
 *                                                                      
 * Output:                                                              
 * cdv->cout->rets[0]                                                   
 *                                                                      
 ***********************************************************************
 * Description: See if i2c dwUnit is available                          
 *                                                                      
 * Last Change: 06.12.2017 HMI                                          
 *                                                                      
 * Modifications:                                                       
 ***********************************************************************/ 
unsigned int zCgosI2CIsAvailable(CGOS_DRV_VARS *cdv)
  {
    dbgi2c(printk("zCgosI2CIsAvailable called\n");)
    cdv->cout->rets[0]=cdv->cin->type<cdv->brd->i2cCount;
    return CGOS_SUCCESS;
  } 
  
/***********************************************************************
 * I2CBusGetStatus(unsigned char bus, unsigned char *pSts)              
 *                                                                     
 * Inputs:                                                              
 *   bus                                                                
 *   pSts                                                               
 *                                                                      
 * Output:                                                              
 *   Writes status of bus to pSts                                       
 *                                                                      
 ***********************************************************************
 * Description: Returns status of the requested i2c bus.                   
 *                                                                      
 * Last Change: 05-Apr-2022 HMI                                          
 *                                                                      
 * Modifications: -MOD24: Removed one value array                                                       
 ***********************************************************************/ 
unsigned int I2CBusGetStatus(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char *pSts)
  {
    unsigned char wbuf[2];
    dbgi2c("I2CBusGetStatus called\n");

    if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E))
    {
        wbuf[0] = CGBC_CMD_I2C_STAT | bus;
        return bcCommand(&wbuf[0], 1, NULL, 0, pSts);
    }
    else
    {
        wbuf[0] = CGBC_CMD_I2C_STAT_EXT;
        wbuf[1] = bus;
        return bcCommand(&wbuf[0], 2, NULL, 0, pSts);
    }
  }
  
/***********************************************************************
 * unsigned int zCgosI2CType(CGOS_DRV_VARS *cdv)                        
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CType(HCGOS hCgos,                              
 *                            unsigned long dwUnit)                    
 *                                                                      
 * Inputs:                                                              
 *   -                                                                  
 *                                                                      
 * Output:                                                              
 * cdv->cout->rets[0]                                                  
 *                                                                      
 ***********************************************************************
 * Description: Returns the cgos type of dwUnit                            
 *                                                                      
 * Last Change: 06.12.2017 HMI                                          
 *                                                                      
 * Modifications:                                                       
 ***********************************************************************/ 
unsigned int zCgosI2CType(CGOS_DRV_VARS *cdv)
  { 
    unsigned int retSuccess = CGOS_SUCCESS;
    dbgi2c(printk("zCgosI2CType called\n");)
    if(cdv->cin->type >= cdv->brd->i2cCount)
    {
        retSuccess = CGOS_ERROR;
    }
    else
    {
        cdv->cout->rets[0] = cdv->i2c[cdv->cin->type].cgostype;
    }
    return retSuccess;
  }

/***********************************************************************
 * unsigned int CgosI2CReadRaw(unsigned char bus, unsigned char addr,
 *                             unsigned char* pBytes, unsigned char cnt)
 *
 ***********************************************************************
 * Description: Driver internal I2C Read function entry, dispatches call
 *              to BC4 or EXT read function.
 *
 ***********************************************************************/

unsigned int CgosI2CReadRaw(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char cnt)
{
    dbgi2c(printk("CgosI2CReadRaw called\n");)

    if ((cdv->brd->BC_Type == BC_TYPE_GEN5) || (cdv->brd->BC_Type == BC_TYPE_GEN6))
    {
        return CgosI2CReadRaw_EXT(cdv, bus, addr, pBytes, cnt);
    }
    else if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C))
    {
        return CgosI2CReadRaw_BC4(cdv, bus, addr, pBytes, cnt);
    }
    else
    {
        return CGOS_ERROR;
    }

}
/***********************************************************************
 * unsigned int CgosI2CReadRaw_BC4(CGOS_DRV_VARS* cdv, unsigned char bus, 
 *                                 unsigned char addr, unsigned char* pBytes,
 *                                 unsigned char cnt)                        
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CRead(HCGOS hCgos,                              
 *                            unsigned long dwUnit,                     
 *                            unsigned char bAddr,                      
 *                            unsigned char *pBytes,                    
 *                            unsigned long dwLen                       
 * Inputs:                                                              
 * dwUnit       <->     cdv->cin->type                                 
 * bAddr        <->     cdv->cin->pars[0]                               
 * dwLen        <->     cdv->lout                                      
 *                                                                      
 * Output:                                                              
 * pBytes       <->     (unsigned char*)cdv->pout                       
 *                                                                      
 ***********************************************************************
 * Description: Read dwLen bytes from bAddr at bus dwUnit using old
 *              CGBC_CMD_I2C_START cBC command.              
 *                                                                                                                            
 ***********************************************************************/ 
 
unsigned int CgosI2CReadRaw_BC4(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char cnt)
  {
    unsigned char wbuf[4];
    unsigned char sts;
    unsigned char retSuccess = CGOS_SUCCESS;
    unsigned char splitBlockSize;
    unsigned int i;

    dbgi2c(printk("CgosI2CReadRaw_BC4 called\n");)

        wbuf[0] = CGBC_CMD_I2C_START | bus;
        wbuf[1] = CGBC_I2C_SEND_START | 1;
        wbuf[2] = 0;
        wbuf[3] = addr & 0xFE; 
        retSuccess = bcCommand(&wbuf[0], 4, NULL, 0, &sts);

        if(retSuccess == CGOS_SUCCESS)
        {
            do
            {   
                retSuccess = I2CBusGetStatus(cdv, bus, &sts );
            }while((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
                    
            if(sts  == CGBC_I2C_STAT_IDL)
            {
                splitBlockSize = 31;
                // Limitation due to CGBC Command Status Byte, 31 is the maximum read value the 
                // Board Controller can return in RC[4:0].
                //    ___________________________________
                //   | 7   6  |  5  |  4   3   2   1   0 |
                //   |________|_____|____________________|
                //   |ST[1:0] | RES |      RC[4:0]       |
                //   |________|_____|____________________|
                // 
                // ST[1:0]	command state: 00 = DATA
                //                             01 = READY
                //                             10 = BUSY
                //                             11 = ERROR
                // RES		reserved/normally return 0/maybe used as RC[5] with GEN5 cBC
                // RC[4:0]	command return code command state is READY
                //              data count when command state is DATA
                //              error code when command state is ERROR
                
                for(i = cnt; (retSuccess == CGOS_SUCCESS) && i; pBytes += splitBlockSize)

                {
                     wbuf[0] = CGBC_CMD_I2C_START | bus;
                     if (i == cnt)
                     {
                            wbuf[1] = CGBC_I2C_SEND_START | 1;
                            wbuf[3] = addr | 0x01;
                     }
                     else
                     {
                            wbuf[1] = 0;
                     }

                     if (i <= splitBlockSize)
                     {
                            wbuf[1] |= CGBC_I2C_SEND_STOP;
                            wbuf[2] = i;
                     }
                     else
                     {
                            wbuf[2] = CGBC_I2C_SEND_LAST_ACK | splitBlockSize;
                     }
                     retSuccess = bcCommand(&wbuf[0], (unsigned char)((cnt == i) ? 4 : 3), NULL, 0, &sts);
                   
                    if(retSuccess == CGOS_SUCCESS)
                    {
                        do
                        {
                            retSuccess = I2CBusGetStatus(cdv, bus, &sts );
                        } while( (retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY) );
                        if( sts == CGBC_I2C_STAT_DAT )
                        {
                                wbuf[0] = CGBC_CMD_I2C_DATA | bus;
                                retSuccess = bcCommand(&wbuf[0], 1, pBytes, (unsigned char)(wbuf[2] & 0x3F), &sts);
                                if (retSuccess == CGOS_SUCCESS)
                                {
                                    if (sts == (wbuf[2] & 0x3F))
                                    {
                                        i -= wbuf[2] & 0x3F;
                                    }
                                    else
                                    {
                                        retSuccess = CGOS_ERROR;
                                    }
                                }                            
                        }
                    }
                }
            }       
        }
    return retSuccess;
  }

/***********************************************************************
 * unsigned int CgosI2CReadRaw_EXT(CGOS_DRV_VARS* cdv, unsigned char bus, 
 *                                 unsigned char addr, unsigned char* pBytes, 
 *                                 unsigned char cnt)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CRead(HCGOS hCgos,
 *                            unsigned long dwUnit,
 *                            unsigned char bAddr,
 *                            unsigned char *pBytes,
 *                            unsigned long dwLen
 * Inputs:
 * dwUnit       <->     cdv->cin->type
 * bAddr        <->     cdv->cin->pars[0]
 * dwLen        <->     cdv->lout
 *
 * Output:
 * pBytes       <->     (unsigned char*)cdv->pout
 *
 ***********************************************************************
 * Description: Read dwLen bytes from bAddr at bus dwUnit using new
 *              CGBC_CMD_I2C_START_EXT cBC command. 
 *
 ***********************************************************************/

unsigned int CgosI2CReadRaw_EXT(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char cnt)
{

    unsigned char wbuf[5];
    unsigned char sts;
    unsigned char retSuccess = CGOS_SUCCESS;
    unsigned char splitBlockSize;
    unsigned int i;

    dbgi2c(printk("CgosI2CReadRaw_EXT called\n");)

    wbuf[0] = CGBC_CMD_I2C_START_EXT;
    wbuf[1] = bus;
    wbuf[2] = CGBC_I2C_SEND_START | 1;
    wbuf[3] = 0;
    wbuf[4] = addr & 0xFE;
    retSuccess = bcCommand(&wbuf[0], 5, NULL, 0, &sts);

    if (retSuccess == CGOS_SUCCESS)
    {
        do
        {
            retSuccess = I2CBusGetStatus(cdv, bus, &sts);
        } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));

        if (sts == CGBC_I2C_STAT_IDL)
        {
            splitBlockSize = 31;
            // Limitation due to CGBC Command Status Byte, 31 is the maximum read value the 
            // Board Controller can return in RC[4:0].
            //    ___________________________________
            //   | 7   6  |  5  |  4   3   2   1   0 |
            //   |________|_____|____________________|
            //   |ST[1:0] | RES |      RC[4:0]       |
            //   |________|_____|____________________|
            // 
            // ST[1:0]	command state: 00 = DATA
            //                             01 = READY
            //                             10 = BUSY
            //                             11 = ERROR
            // RES		reserved/normally return 0/maybe used as RC[5] with GEN5 cBC
            // RC[4:0]	command return code command state is READY
            //              data count when command state is DATA
            //              error code when command state is ERROR

            for (i = cnt; (retSuccess == CGOS_SUCCESS) && i; pBytes += splitBlockSize)

            {
                wbuf[0] = CGBC_CMD_I2C_START_EXT;
                wbuf[1] = bus;
                if (i == cnt)
                {
                    wbuf[2] = CGBC_I2C_SEND_START | 1;
                    wbuf[4] = addr | 0x01;
                }
                else
                {
                    wbuf[2] = 0;
                }

                if (i <= splitBlockSize)
                {
                    wbuf[2] |= CGBC_I2C_SEND_STOP;
                    wbuf[3] = i;
                }
                else
                {
                    wbuf[4] = CGBC_I2C_SEND_LAST_ACK | splitBlockSize;
                }
                retSuccess = bcCommand(&wbuf[0], (unsigned char)((cnt == i) ? 5 : 4), NULL, 0, &sts);

                if (retSuccess == CGOS_SUCCESS)
                {
                    do
                    {
                        retSuccess = I2CBusGetStatus(cdv, bus, &sts);
                    } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
                    if (sts == CGBC_I2C_STAT_DAT)
                    {
                        wbuf[0] = CGBC_CMD_I2C_DATA_EXT;
                        wbuf[1] = bus;
                        retSuccess = bcCommand(&wbuf[0], 2, pBytes, (unsigned char)(wbuf[3] & 0x3F), &sts);
                        if (retSuccess == CGOS_SUCCESS)
                        {
                            if (sts == (wbuf[3] & 0x3F))
                            {
                                i -= wbuf[3] & 0x3F;
                            }
                            else
                            {
                                retSuccess = CGOS_ERROR;
                            }
                        }
                    }
                }
            }
        }
    }
    return retSuccess;
}

/***********************************************************************
 * unsigned int zCgosI2CRead(CGOS_DRV_VARS *cdv)                        
 *                                                                                                                                         
 ***********************************************************************
 * Description: API call entry, dispatches call to driver internal function.              
 *                                                 
 ***********************************************************************/ 
 
unsigned int zCgosI2CRead(CGOS_DRV_VARS *cdv)
  {
    unsigned char retSuccess = CGOS_SUCCESS;
    dbgi2c(printk("zCgosI2CRead called\n");)
            
    if(cdv->cin->type >= cdv->brd->i2cCount)
    {
        retSuccess = CGOS_ERROR;
    }
    else
    { 
    	retSuccess = CgosI2CReadRaw(cdv, cdv->i2c[cdv->cin->type].cgbctype, cdv->cin->pars[0], (unsigned char*)(cdv->pout), cdv->lout);
    }
        
    cdv->retcnt += cdv->lout;
    return retSuccess;
  }
  
/***********************************************************************
 * unsigned int CgosI2CWriteRaw(unsigned char bus, unsigned char addr,
 *                              unsigned char* pBytes, unsigned char cnt)
 *
 ***********************************************************************
 * Description: Driver internal I2C write function entry, dispatches call
 *              to BC4 or EXT write function.
 ***********************************************************************/
unsigned int CgosI2CWriteRaw(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char len)
{
    dbgi2c(printk("CgosI2CWriteRaw called\n");)

    if ((cdv->brd->BC_Type == BC_TYPE_GEN5) || (cdv->brd->BC_Type == BC_TYPE_GEN6))
    {
        return CgosI2CWriteRaw_EXT(cdv, bus, addr, pBytes, len);
    }
    else if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C))
    {
        return CgosI2CWriteRaw_BC4(cdv, bus, addr, pBytes, len);
    }
    else
    {
        return CGOS_ERROR;
    }
}

/***********************************************************************
 * unsigned int CgosI2CWriteRaw_BC4(unsigned char bus, unsigned char addr, 
 *                              unsigned char* pBytes, unsigned char cnt)                       
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CWrite(HCGOS hCgos,                             
 *                             unsigned long dwUnit,                    
 *                             unsigned char bAddr,                     
 *                             unsigned char *pBytes,                   
 *                             unsigned long dwLen                      
 * Inputs:                                                              
 * dwUnit       <->     cdv->cin->type                                  
 * bAddr        <->     cdv->cin->pars[0]                               
 * pBytes       <->     cdv->pin                                        
 * dwLen        <->     cdv->nInBufferSize - sizeof(CGOSIOCTLIN)        
 *                                                                      
 * Outputs:                                                             
 *   -                                                                  
 *                                                                      
 ***********************************************************************
 * Description: Write dwLen bytes to bAddr at dwUnit using the old
 *              CGBC_CMD_I2C_START cBC command.
 * 
 ***********************************************************************/ 
unsigned int CgosI2CWriteRaw_BC4(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char len)
  {
    unsigned char wbuf[4+32];
    unsigned char inputBuf[900] = {0};
    unsigned int  index=0;
    unsigned char sts;
    unsigned char retSuccess = CGOS_SUCCESS;
    unsigned int splitBlockSize;
    unsigned int thisCnt;
    unsigned int i,j;

    dbgi2c(printk("CgosI2CWriteRaw_BC4 called\n");)

    	splitBlockSize = 32;	
        if( len <= splitBlockSize )
        {
            thisCnt = len;
        }
        else
        {
            thisCnt = splitBlockSize;
        }

        wbuf[0] = CGBC_CMD_I2C_START | bus;
        wbuf[1] = CGBC_I2C_SEND_START | (1 + thisCnt);
        if (thisCnt == len)
        {
            wbuf[1] |= CGBC_I2C_SEND_STOP;
        }
        wbuf[2] = 0;
        wbuf[3] = addr;


        if (len > 900)
        {
            return CGOS_ERROR;
        }
        OsaMemCpy(&inputBuf[0], pBytes, len);
        for (i = 0; i < thisCnt; i++)
        {
            wbuf[4 + i] = inputBuf[i];
        }
            
        retSuccess = bcCommand(&wbuf[0], (unsigned char)(4 + thisCnt), NULL, 0, &sts);
     
        if( retSuccess==CGOS_SUCCESS )
        {
            do
            {
                retSuccess = I2CBusGetStatus(cdv, bus, &sts );
            } while( (retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY) );

            if( sts == CGBC_I2C_STAT_IDL )
            {
                index += thisCnt; //MOD24
		for (i = len - thisCnt; (retSuccess == CGOS_SUCCESS) && i; index += splitBlockSize) //MOD24
                {
                    if( i > splitBlockSize )
                    {
                        thisCnt = splitBlockSize;
                        wbuf[1] = splitBlockSize;
                    }
                    else
                    {
                        thisCnt = i;
                        wbuf[1] = i | CGBC_I2C_SEND_STOP;
                    }
                    for(j = 0 ; j < thisCnt; j++)
                    {
                    	wbuf[3+j]=inputBuf[index+j];
                    }

                    retSuccess = bcCommand( &wbuf[0], (unsigned char)(3+thisCnt), NULL, 0, &sts ); 
                    if( retSuccess==CGOS_SUCCESS )
                    {
                        do
                        {
                            retSuccess = I2CBusGetStatus(cdv, bus, &sts );
                        } while( (retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY) );
                        if( sts == CGBC_I2C_STAT_IDL )
                        {
                            i = i - thisCnt;
                            retSuccess = CGOS_SUCCESS;
                        }
                        else
                        {
                            retSuccess = CGOS_ERROR;
                        }
                    }
                }
            }
            else
            {
                retSuccess =  CGOS_ERROR;
            }
        } 
    
    return retSuccess;
  }

  /***********************************************************************
 * unsigned int CgosI2CWriteRaw_EXT(unsigned char bus, unsigned char addr,
 *                              unsigned char* pBytes, unsigned char len)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CWrite(HCGOS hCgos,
 *                             unsigned long dwUnit,
 *                             unsigned char bAddr,
 *                             unsigned char *pBytes,
 *                             unsigned long dwLen
 * Inputs:
 * dwUnit       <->     cdv->cin->type
 * bAddr        <->     cdv->cin->pars[0]
 * pBytes       <->     cdv->pin
 * dwLen        <->     cdv->nInBufferSize - sizeof(CGOSIOCTLIN)
 *
 * Outputs:
 *   -
 *
 ***********************************************************************
 * Description: Write dwLen bytes to bAddr at dwUnit using the new
 *              CGBC_CMD_I2C_START_EXT cBC command.
 * 
 ***********************************************************************/
  unsigned int CgosI2CWriteRaw_EXT(CGOS_DRV_VARS* cdv, unsigned char bus, unsigned char addr, unsigned char* pBytes, unsigned char len)
  {
      unsigned char wbuf[5 + 32];
      unsigned char inputBuf[900] = { 0 };
      unsigned int  index = 0;
      unsigned char sts;
      unsigned char retSuccess = CGOS_SUCCESS;
      unsigned int splitBlockSize;
      unsigned int thisCnt;
      unsigned int i, j;

      dbgi2c(printk("CgosI2CWriteRaw_EXT called\n");)

      splitBlockSize = 32;
      if (len <= splitBlockSize)
      {
          thisCnt = len;
      }
      else
      {
          thisCnt = splitBlockSize;
      }
      wbuf[0] = CGBC_CMD_I2C_START_EXT;
      wbuf[1] = bus;
      wbuf[2] = CGBC_I2C_SEND_START | (1 + thisCnt);
      if (thisCnt == len)
      {
          wbuf[2] |= CGBC_I2C_SEND_STOP;
      }
      wbuf[3] = 0;
      wbuf[4] = addr;


      if (len > 900)
      {
          return CGOS_ERROR;
      }
      OsaMemCpy(&inputBuf[0], pBytes, len);
      for (i = 0; i < thisCnt; i++)
      {
          wbuf[5 + i] = inputBuf[i];
      }

      retSuccess = bcCommand(&wbuf[0], (unsigned char)(5 + thisCnt), NULL, 0, &sts);

      if (retSuccess == CGOS_SUCCESS)
      {
          do
          {
              retSuccess = I2CBusGetStatus(cdv, bus, &sts);
          } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));

          if (sts == CGBC_I2C_STAT_IDL)
          {
              index += thisCnt;
              for (i = len - thisCnt; (retSuccess == CGOS_SUCCESS) && i; index += splitBlockSize) 
              {
                  if (i > splitBlockSize)
                  {
                      thisCnt = splitBlockSize;
                      wbuf[2] = splitBlockSize;
                  }
                  else
                  {
                      thisCnt = i;
                      wbuf[2] = i | CGBC_I2C_SEND_STOP;
                  }
                  for (j = 0; j < thisCnt; j++)
                  {
                      wbuf[4 + j] = inputBuf[index + j];
                  }

                  retSuccess = bcCommand(&wbuf[0], (unsigned char)(4 + thisCnt), NULL, 0, &sts);
                  if (retSuccess == CGOS_SUCCESS)
                  {
                      do
                      {
                          retSuccess = I2CBusGetStatus(cdv, bus, &sts);
                      } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
                      if (sts == CGBC_I2C_STAT_IDL)
                      {
                          i = i - thisCnt;
                          retSuccess = CGOS_SUCCESS;
                      }
                      else
                      {
                          retSuccess = CGOS_ERROR;
                      }
                  }
              }
          }
          else
          {
              retSuccess = CGOS_ERROR;
          }
      }

      return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosI2CWrite(CGOS_DRV_VARS *cdv)                       
 *                                                                      
 ***********************************************************************
 * Description: API call entry, dispatches call to driver internal function.
 *
 ***********************************************************************/
unsigned int zCgosI2CWrite(CGOS_DRV_VARS *cdv)
  {
    unsigned char retSuccess = CGOS_SUCCESS;
    dbgi2c(printk("zCgosI2CWrite called\n");)
    if(cdv->cin->type >= cdv->brd->i2cCount)
    {
        retSuccess = CGOS_ERROR;
    }
    else
    {
    	retSuccess = CgosI2CWriteRaw(cdv, cdv->i2c[cdv->cin->type].cgbctype, cdv->cin->pars[0], (unsigned char*)(cdv->pin), cdv->lin);
    }
    
    return retSuccess; 
  }

/***********************************************************************
 * unsigned int CgosI2CReadRegisterRaw(unsigned long dwUnit,
 *                                        unsigned char bAddr,
 *                                        unsigned char wReg,
 *                                        unsigned char *PDataByte)
 *
 ***********************************************************************
 * Description: Driver internal I2C read register function entry, dispatches 
 *              call to BC4 or EXT read register function.
 ***********************************************************************/
unsigned int CgosI2CReadRegisterRaw(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned char wReg, unsigned char* PDataByte)
{
    dbgi2c("CgosI2CReadRegisterRaw called\n");
    if ((cdv->brd->BC_Type == BC_TYPE_GEN5) || (cdv->brd->BC_Type == BC_TYPE_GEN6))
    {
        return CgosI2CReadRegisterRaw_EXT(cdv, dwUnit, bAddr, wReg, PDataByte);
    }
    else if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C))
    {
        return CgosI2CReadRegisterRaw_BC4(cdv, dwUnit, bAddr, wReg, PDataByte);
    }
    else
    {
        return CGOS_ERROR;
    }
}

/***********************************************************************
 * unsigned int CgosI2CReadRegisterRaw_BC4(unsigned long dwUnit,
 *                                        unsigned char bAddr,
 *                                        unsigned char wReg,
 *                                        unsigned char *PDataByte)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CReadRegister(HCGOS hCgos,
 *                                    unsigned long dwUnit,
 *                                    unsigned char bAddr,
 *                                    unsigned short wReg,
 *                                    unsigned char *pDataByte
 * Inputs:
 * dwUnit  
 * bAddr       
 * wReg      
 *
 * Output:
 * pData Byte  
 *
 ***********************************************************************
 * Description: Reads one byte from a register using the old
 *              CGBC_CMD_I2C_START cBC command.
 * 
 ***********************************************************************/
  unsigned int CgosI2CReadRegisterRaw_BC4(CGOS_DRV_VARS* cdv,
                                         unsigned long dwUnit,
	                                     unsigned char bAddr,
	                                     unsigned char wReg,
	                                     unsigned char *PDataByte)
  {
	  unsigned char wbuf[5];
	  unsigned char sts;
	  unsigned char retSuccess = CGOS_SUCCESS;
	  unsigned char ret;

	  dbgi2c("CgosI2CReadRegisterRaw_BC4 called\n");

		  wbuf[0] = CGBC_CMD_I2C_START | dwUnit;
		  wbuf[1] = CGBC_I2C_SEND_START | 2;
		  wbuf[2] = 0;
		  wbuf[3] = bAddr & 0xFE;
		  wbuf[4] = wReg;
		  retSuccess = bcCommand(&wbuf[0], 5, NULL, 0, &sts);
		  if (retSuccess == CGOS_SUCCESS)
		  {
			  do
			  {
				  retSuccess = I2CBusGetStatus(cdv, dwUnit, &sts);
			  } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
			  if (sts == CGBC_I2C_STAT_IDL)
			  {
				  wbuf[0] = CGBC_CMD_I2C_START | dwUnit;
				  wbuf[1] = CGBC_I2C_SEND_START | CGBC_I2C_SEND_STOP | 1;
				  wbuf[2] = 1;
				  wbuf[3] = bAddr | 0x01;
				  retSuccess = bcCommand(&wbuf[0], 4, NULL, 0, &sts);
				  if (retSuccess == CGOS_SUCCESS)
				  {
					  do
					  {
						  retSuccess = I2CBusGetStatus(cdv, dwUnit, &sts);
					  } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
					  if (sts == CGBC_I2C_STAT_DAT)
					  {
						  wbuf[0] = CGBC_CMD_I2C_DATA | dwUnit;
						  retSuccess = bcCommand(&wbuf[0], 1, &ret, 1 & 0x3F, &sts);
						  *PDataByte = ret;
					  }
				  }
			  }
		  }
	  return retSuccess;
  }

  /***********************************************************************
 * unsigned int CgosI2CReadRegisterRaw_EXT(unsigned long dwUnit,
 *                                        unsigned char bAddr,
 *                                        unsigned char wReg,
 *                                        unsigned char *PDataByte)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CReadRegister(HCGOS hCgos,
 *                                    unsigned long dwUnit,
 *                                    unsigned char bAddr,
 *                                    unsigned short wReg,
 *                                    unsigned char *pDataByte
 * Inputs:
 * dwUnit
 * bAddr
 * wReg
 *
 * Output:
 * pData Byte
 *
 ***********************************************************************
 * Description: Reads one byte from a register using the new
 *              CGBC_CMD_I2C_START_EXT cBC command.
 * 
 ***********************************************************************/
  unsigned int CgosI2CReadRegisterRaw_EXT(CGOS_DRV_VARS* cdv,
      unsigned long dwUnit,
      unsigned char bAddr,
      unsigned char wReg,
      unsigned char* PDataByte)
  {
      unsigned char wbuf[6];
      unsigned char sts;
      unsigned char retSuccess = CGOS_SUCCESS;
      unsigned char ret;

      dbgi2c("CgosI2CReadRegisterRaw_EXT called\n");

      wbuf[0] = CGBC_CMD_I2C_START_EXT;
      wbuf[1] = dwUnit;
      wbuf[2] = CGBC_I2C_SEND_START | 2;
      wbuf[3] = 0;
      wbuf[4] = bAddr & 0xFE;
      wbuf[5] = wReg;
      retSuccess = bcCommand(&wbuf[0], 6, NULL, 0, &sts);
      if (retSuccess == CGOS_SUCCESS)
      {
          do
          {
              retSuccess = I2CBusGetStatus(cdv, dwUnit, &sts);
          } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
          if (sts == CGBC_I2C_STAT_IDL)
          {
              wbuf[0] = CGBC_CMD_I2C_START_EXT;
              wbuf[1] = dwUnit;
              wbuf[2] = CGBC_I2C_SEND_START | CGBC_I2C_SEND_STOP | 1;
              wbuf[3] = 1;
              wbuf[4] = bAddr | 0x01;
              retSuccess = bcCommand(&wbuf[0], 5, NULL, 0, &sts);
              if (retSuccess == CGOS_SUCCESS)
              {
                  do
                  {
                      retSuccess = I2CBusGetStatus(cdv, dwUnit, &sts);
                  } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
                  if (sts == CGBC_I2C_STAT_DAT)
                  {
                      wbuf[0] = CGBC_CMD_I2C_DATA_EXT;
                      wbuf[1] = dwUnit;
                      retSuccess = bcCommand(&wbuf[0], 2, &ret, 1 & 0x3F, &sts);
                      *PDataByte = ret;
                  }
              }
          }
      }
      return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosI2CReadRegister(CGOS_DRV_VARS *cdv)                
 *                                                                      
 ***********************************************************************
 * Description: API call entry, dispatches call to driver internal function.
 *
 ***********************************************************************/
unsigned int zCgosI2CReadRegister(CGOS_DRV_VARS *cdv)
  { 
    dbgi2c(printk("zCgosI2CReadRegister called\n");)    
    unsigned long dwUnit = cdv->cin->type;                                  
    unsigned char bAddr = cdv->cin->pars[0];                               
    unsigned char wReg = cdv->cin->pars[1];                                                                                            
    return CgosI2CReadRegisterRaw(cdv, dwUnit, bAddr, wReg, (unsigned char*)(&cdv->cout->rets[0]));
  }
  
/***********************************************************************
 * unsigned int CgosI2CWriteRegisterRaw(unsigned long dwUnit,
 *                                        unsigned char bAddr,
 *                                        unsigned char wReg,
 *                                        unsigned char bData)
 *
 ***********************************************************************
 * Description: Driver internal I2C write register function entry, 
 *              dispatches call to BC4 or EXT write register function.
 * 
 ***********************************************************************/
unsigned int CgosI2CWriteRegisterRaw(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned short wReg, unsigned char bData)
{
    dbgi2c("CgosI2CWriteRegisterRaw called\n");

    if ((cdv->brd->BC_Type == BC_TYPE_GEN5) || (cdv->brd->BC_Type == BC_TYPE_GEN6))
    {
        return CgosI2CWriteRegisterRaw_EXT(cdv, dwUnit, bAddr, wReg, bData);
    }
    else if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C))
    {
        return CgosI2CWriteRegisterRaw_BC4(cdv, dwUnit, bAddr, wReg, bData);
    }
    else
    {
        return CGOS_ERROR;
    }

}

/***********************************************************************
 * unsigned int CgosI2CWriteRegisterRaw_BC4(unsigned long dwUnit,
 *                                        unsigned char bAddr,
 *                                        unsigned char wReg,
 *                                        unsigned char bData)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CWriteRegister(HCGOS hCgos,                     
 *                                     unsigned long dwUnit,            
 *                                     unsigned char bAddr,             
 *                                     unsigned short wReg,             
 *                                     unsigned char bData             

 * Inputs:                                                              
 * dwUnit       <->     cdv->cin->type                                  
 * bAddr        <->     cdv->cin->pars[0]                               
 * wReg         <->     cdv->cin->pars[1]                               
 * bData        <->     cdv->cin->pars[2]                               
 *                                                                      
 * Outputs:                                                             
 *   -                                                                  
 *                                                                      
 ***********************************************************************
 * Description: Writes one byte from a register using the old 
 *              CGBC_CMD_I2C_START cBC command.
 * 
 ***********************************************************************/
unsigned int CgosI2CWriteRegisterRaw_BC4(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned short wReg, unsigned char bData)
  { 
    unsigned char wbuf[6];
    unsigned char sts = 0;
    unsigned char retSuccess = CGOS_SUCCESS;

    dbgi2c("CgosI2CWriteRegisterRaw_BC4 called\n");

    wbuf[0] = CGBC_CMD_I2C_START | dwUnit;
    wbuf[1] = CGBC_I2C_SEND_START | CGBC_I2C_SEND_STOP | 3; 
	wbuf[2] = 0;
    wbuf[3] = bAddr;
    wbuf[4] = wReg;
	wbuf[5] = bData;
        retSuccess = bcCommand( &wbuf[0], 6, NULL, 0, &sts );
        
        if( retSuccess==CGOS_SUCCESS ) 
        {
        	do
        	{
        	    retSuccess = I2CBusGetStatus(cdv, dwUnit, &sts );
        	} while( (retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY) );
        	if( sts == CGBC_I2C_STAT_IDL )
        	{
        	    retSuccess = CGOS_SUCCESS;
        	}
        	else	
        	{
    	        retSuccess = CGOS_ERROR;
 	       }
        }
    return retSuccess;
  }

/***********************************************************************
 * unsigned int CgosI2CWriteRegisterRaw_EXT(unsigned long dwUnit,
 *                                        unsigned char bAddr,
 *                                        unsigned char wReg,
 *                                        unsigned char bData)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CWriteRegister(HCGOS hCgos,
 *                                     unsigned long dwUnit,
 *                                     unsigned char bAddr,
 *                                     unsigned short wReg,
 *                                     unsigned char bData

 * Inputs:
 * dwUnit       <->     cdv->cin->type
 * bAddr        <->     cdv->cin->pars[0]
 * wReg         <->     cdv->cin->pars[1]
 * bData        <->     cdv->cin->pars[2]
 *
 * Outputs:
 *   -
 *
 ***********************************************************************
 * Description: Writes one byte from a register using the new
 *              CGBC_CMD_I2C_START_EXT cBC command.
 * 
 ***********************************************************************/
unsigned int CgosI2CWriteRegisterRaw_EXT(CGOS_DRV_VARS* cdv, unsigned long dwUnit, unsigned char bAddr, unsigned short wReg, unsigned char bData)
{
    unsigned char wbuf[7];
    unsigned char sts = 0;
    unsigned char retSuccess = CGOS_SUCCESS;

    dbgi2c("CgosI2CWriteRegisterRaw_EXT called\n");

    wbuf[0] = CGBC_CMD_I2C_START_EXT;
    wbuf[1] = dwUnit;
    wbuf[2] = CGBC_I2C_SEND_START | CGBC_I2C_SEND_STOP | 3;
    wbuf[3] = 0;
    wbuf[4] = bAddr;
    wbuf[5] = wReg;
    wbuf[6] = bData;
    retSuccess = bcCommand(&wbuf[0], 7, NULL, 0, &sts);

    if (retSuccess == CGOS_SUCCESS)
    {
        do
        {
            retSuccess = I2CBusGetStatus(cdv, dwUnit, &sts);
        } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
        if (sts == CGBC_I2C_STAT_IDL)
        {
            retSuccess = CGOS_SUCCESS;
        }
        else
        {
            retSuccess = CGOS_ERROR;
        }
    }
    return retSuccess;
}

/***********************************************************************
 * unsigned int zCgosI2CWriteRegister(CGOS_DRV_VARS *cdv)               
 *                                                                      
 ***********************************************************************
 * Description: API call entry, dispatches call to driver internal function.
 *
 ***********************************************************************/
unsigned int zCgosI2CWriteRegister(CGOS_DRV_VARS *cdv)
  { 
    dbgi2c(printk("zCgosI2CWriteRegister called\n");)
    unsigned long dwUnit = cdv->cin->type;                                  
    unsigned char bAddr = cdv->cin->pars[0];                               
    unsigned char wReg = cdv->cin->pars[1];  
    unsigned char bData = cdv->cin->pars[2];                                                                                          
    return CgosI2CWriteRegisterRaw(cdv, dwUnit, bAddr, wReg, bData);
  }

/***********************************************************************
 * unsigned int zCgosI2CWriteReadCombined(CGOS_DRV_VARS *cdv)
 *
 ***********************************************************************
 * Description: I2C write read combined function entry, dispatches call
 *              to BC4 or EXT function.
 ***********************************************************************/
unsigned int zCgosI2CWriteReadCombined(CGOS_DRV_VARS* cdv)
{
    dbgi2c(printk("zCgosI2CWriteReadCombined called\n");)

    if ((cdv->brd->BC_Type == BC_TYPE_GEN5) || (cdv->brd->BC_Type == BC_TYPE_GEN6))
    {
        return CgosI2CWriteReadCombined_EXT(cdv);
    }
    else if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C))
    {
        return CgosI2CWriteReadCombined_BC4(cdv);
    }
    else
    {
        return CGOS_ERROR;
    }
}

/***********************************************************************
 * unsigned int CgosI2CWriteReadCombined_BC4(CGOS_DRV_VARS *cdv)           
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CWriteReadCombined(HCGOS hCgos,                 
 *                                         unsigned long dwUnit,        
 *                                         unsigned char bAddr,         
 *                                         unsigned char *pBytesWrite,  
 *                                         unsigned long dwLenWrite,    
 *                                         unsigned char *pBytesRead,   
 *                                         unsigned long dwLenRead)     
 * Inputs:                                                             
 * dwUnit       <->     cdv->cin->type                                  
 * bAddr        <->     cdv->cin->pars[0]                               
 * pBytesWrite  <->     cdv->pin                                        
 * dwLenWrite   <->     cdv->lin                                        
 * dwLenRead    <->     cdv->lout                                      
 *                                                                      
 * Output:                                                              
 * pBytesRead   <->     (unsigned char*)cdv->pout                       
 *                                                                      
 ***********************************************************************
 * Description: Execute a combined write and read action using the old
 *              cBC I2C commands.
 * 
 ***********************************************************************/  
unsigned int CgosI2CWriteReadCombined_BC4(CGOS_DRV_VARS *cdv)
  { 
    unsigned char wbuf[4+32];
    unsigned char inputBuf[900] = {0};
    unsigned int  index=0;
    unsigned char sts;
    unsigned char retSuccess = CGOS_SUCCESS;
    unsigned int splitBlockSize;
    unsigned int thisCnt;
    unsigned int i,j;
    unsigned int len = cdv->lin;
    unsigned char rbuf[4];
    unsigned int cnt = cdv->lout;
    unsigned char addr = cdv->cin->pars[0];
    unsigned char bus = 0;

    dbgi2c(printk("CgosI2CWriteReadCombined_BC4 called\n");)

    //Write Part
    if(len != 0) //In case 0 Bytes are written, go directly to read part
    {	   
   	    if(cdv->cin->type >= cdv->brd->i2cCount)
    	{
        	retSuccess = CGOS_ERROR;
    	}
    	else
    	{
        	bus = cdv->i2c[cdv->cin->type].cgbctype;
    		splitBlockSize = 32;	
        	if( len <= splitBlockSize )
        	{
        	    thisCnt = len;
        	}
        	else
        	{
        	    thisCnt = splitBlockSize;
        	}
        	wbuf[0] = CGBC_CMD_I2C_START | bus;
        	wbuf[1] = CGBC_I2C_SEND_START | (1 + thisCnt);
        	if( (thisCnt == len) && (cnt == 0)) //In case 0 Bytes are going to be read a stop condition has to be added here
        	{
        		wbuf[1] |= CGBC_I2C_SEND_STOP;
        	}
        	wbuf[2] = 0;
        	wbuf[3] = addr & 0xFE;
    	
    		if(len > 900)
    		{
    			return CGOS_ERROR;
    		}
    		OsaMemCpy(&inputBuf[0],cdv->pin,len);
        	for (i=0;i<thisCnt;i++)
        	{
        		wbuf[4+i]=inputBuf[i];
        	}
        	
        	retSuccess = bcCommand( &wbuf[0], (unsigned char)(4+thisCnt), NULL, 0, &sts );
        	if( retSuccess==CGOS_SUCCESS )
        	{
        	    do
        	    {
        	        retSuccess = I2CBusGetStatus(cdv, cdv->i2c[cdv->cin->type].cgbctype, &sts );
        	    } while( (retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY) );
        	    if( sts == CGBC_I2C_STAT_IDL )
        	    {
        	        index += thisCnt;
			for (i = (cdv->lin) - thisCnt; (retSuccess == CGOS_SUCCESS) && i; index += splitBlockSize) 
        	        {
        	            if( i > splitBlockSize )
        	            {
        	                thisCnt = splitBlockSize;
        	                wbuf[1] = splitBlockSize;
        	            }
        	            else
        	            {
        	                thisCnt = i;
        	                if( cnt == 0) //In case 0 Bytes are going to be read a stop condition has to be added here
        	                {
        	                	wbuf[1] = i | CGBC_I2C_SEND_STOP;
        	                }
        	                else
        	                {
        	                	wbuf[1] = i;
        	            	}
        	            }
        	            for(j = 0 ; j < thisCnt; j++)
        	            {
        	            	wbuf[3+j]=inputBuf[index+j];
        	            }
	
        	            retSuccess = bcCommand( &wbuf[0], (unsigned char)(3+thisCnt), NULL, 0, &sts ); 
        	            if( retSuccess==CGOS_SUCCESS )
        	            {
        	                do
        	                {
        	                    retSuccess = I2CBusGetStatus(cdv, cdv->i2c[cdv->cin->type].cgbctype, &sts );
        	                } while( (retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY) );
        	                if( sts == CGBC_I2C_STAT_IDL )
        	                {
        	                    i = i - thisCnt;
        	                    retSuccess = CGOS_SUCCESS;
        	                }
        	                else
        	                {
        	                    retSuccess = CGOS_ERROR;
        	                }
        	            }
        	        }
        	    }
        	    else
        	    {
        	        retSuccess =  CGOS_ERROR;
        	    }
        	} 
        }
    }	
//Read Part

    if(cdv->cin->type >= cdv->brd->i2cCount)
    {
        retSuccess = CGOS_ERROR;
    }
    else
    {
    	if(len == 0) //In case 0 Bytes are written, this has to be called first
    	{
    		wbuf[0] = CGBC_CMD_I2C_START | bus;
        	wbuf[1] = CGBC_I2C_SEND_START | 1;
        	wbuf[2] = 0;
        	wbuf[3] = addr & 0xFE; //MOD23
        	retSuccess = bcCommand( &wbuf[0], 4, NULL, 0, &sts );
    	} 
    	  
        if(retSuccess == CGOS_SUCCESS)
        {
            do
            {   
                retSuccess = I2CBusGetStatus(cdv, bus, &sts );
            }while((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
                    
            if(sts  == CGBC_I2C_STAT_IDL)
            {
                splitBlockSize = 31;
                // Limitation due to CGBC Command Status Byte, 31 is the maximum read value the 
                // Board Controller can return in RC[4:0].
                //    ___________________________________
                //   | 7   6  |  5  |  4   3   2   1   0 |
                //   |________|_____|____________________|
                //   |ST[1:0] | RES |      RC[4:0]       |
                //   |________|_____|____________________|
                // 
                // ST[1:0]	command state: 00 = DATA
                //                             01 = READY
                //                             10 = BUSY
                //                             11 = ERROR
                // RES		reserved/normally return 0/maybe used as RC[5] with GEN5 cBC
                // RC[4:0]	command return code command state is READY
                //              data count when command state is DATA
                //              error code when command state is ERROR
                
#ifdef __linux__
                for(i = cnt; (retSuccess == CGOS_SUCCESS) && i; /*(unsigned char*)*/cdv->pout += splitBlockSize)
#else
		for (i = cnt; (retSuccess == CGOS_SUCCESS) && i; (unsigned char*)cdv->pout += splitBlockSize)
#endif
                {
                    rbuf[0] = CGBC_CMD_I2C_START | bus;
                    if(i == cnt)
                    {
                        rbuf[1] = CGBC_I2C_SEND_START | 1;
                        rbuf[3] = addr | 0x01;
                    }
                    else
                    {
                        rbuf[1] = 0;
                    }
                            
                    if(i <= splitBlockSize) 
                    {
                        rbuf[1] |= CGBC_I2C_SEND_STOP;
                        rbuf[2] = i;
                    }
                    else
                    {
                        rbuf[2] = CGBC_I2C_SEND_LAST_ACK | splitBlockSize;
                    }
                    retSuccess = bcCommand(&rbuf[0], (unsigned char)((cnt == i)?4:3), NULL, 0, &sts);
                    
                    if(retSuccess == CGOS_SUCCESS)
                    {
                        do
                        {
                            retSuccess = I2CBusGetStatus(cdv, bus, &sts );
                        } while( (retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY) );
                        if( sts == CGBC_I2C_STAT_DAT )
                        {
                            rbuf[0] = CGBC_CMD_I2C_DATA | bus;
                            retSuccess = bcCommand(&rbuf[0], 1, cdv->pout, (unsigned char)(rbuf[2] & 0x3F), &sts);
                            if(retSuccess == CGOS_SUCCESS)
                            {
                                if(sts == (rbuf[2] & 0x3F))
                                {
                                    i -= rbuf[2] & 0x3F;
                                }
                                else
                                {
                                    retSuccess = CGOS_ERROR;
                                }
                            }
                        }
                    }
                }
            }       
        }
    cdv->retcnt += cdv->lout;
    }
    return retSuccess;
  }
  
  /***********************************************************************
 * unsigned int CgosI2CWriteReadCombined_EXT(CGOS_DRV_VARS *cdv)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CWriteReadCombined(HCGOS hCgos,
 *                                         unsigned long dwUnit,
 *                                         unsigned char bAddr,
 *                                         unsigned char *pBytesWrite,
 *                                         unsigned long dwLenWrite,
 *                                         unsigned char *pBytesRead,
 *                                         unsigned long dwLenRead)
 * Inputs:
 * dwUnit       <->     cdv->cin->type
 * bAddr        <->     cdv->cin->pars[0]
 * pBytesWrite  <->     cdv->pin
 * dwLenWrite   <->     cdv->lin
 * dwLenRead    <->     cdv->lout
 *
 * Output:
 * pBytesRead   <->     (unsigned char*)cdv->pout
 *
 ***********************************************************************
 * Description: Execute a combined write and read action using the new
 *              *_EXT I2C cBC commands.
 * 
 ***********************************************************************/
  unsigned int CgosI2CWriteReadCombined_EXT(CGOS_DRV_VARS* cdv)
  {
      unsigned char wbuf[5 + 32];
      unsigned char inputBuf[900] = { 0 };
      unsigned int  index = 0;
      unsigned char sts;
      unsigned char retSuccess = CGOS_SUCCESS;
      unsigned int splitBlockSize;
      unsigned int thisCnt;
      unsigned int i, j;
      unsigned int len = cdv->lin;
      unsigned char rbuf[5];
      unsigned int cnt = cdv->lout;
      unsigned char addr = cdv->cin->pars[0];
      unsigned char bus = 0;

      dbgi2c(printk("CgosI2CWriteReadCombined_EXT called\n");)
          //Write Part
          if (len != 0) //In case 0 Bytes are written, go directly to read part
          {
              if (cdv->cin->type >= cdv->brd->i2cCount)
              {
                  retSuccess = CGOS_ERROR;
              }
              else
              {
                  bus = cdv->i2c[cdv->cin->type].cgbctype;
                  splitBlockSize = 32;
                  if (len <= splitBlockSize)
                  {
                      thisCnt = len;
                  }
                  else
                  {
                      thisCnt = splitBlockSize;
                  }
                  wbuf[0] = CGBC_CMD_I2C_START_EXT;
                  wbuf[1] = bus;
                  wbuf[2] = CGBC_I2C_SEND_START | (1 + thisCnt);
                  if ((thisCnt == len) && (cnt == 0)) //In case 0 Bytes are going to be read a stop condition has to be added here
                  {
                      wbuf[2] |= CGBC_I2C_SEND_STOP;
                  }
                  wbuf[3] = 0;
                  wbuf[4] = addr & 0xFE;

                  if (len > 900)
                  {
                      return CGOS_ERROR;
                  }
                  OsaMemCpy(&inputBuf[0], cdv->pin, len);
                  for (i = 0; i < thisCnt; i++)
                  {
                      wbuf[5 + i] = inputBuf[i];
                  }

                  retSuccess = bcCommand(&wbuf[0], (unsigned char)(5 + thisCnt), NULL, 0, &sts);
                  if (retSuccess == CGOS_SUCCESS)
                  {
                      do
                      {
                          retSuccess = I2CBusGetStatus(cdv, cdv->i2c[cdv->cin->type].cgbctype, &sts);
                      } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
                      if (sts == CGBC_I2C_STAT_IDL)
                      {
                          index += thisCnt;
                          for (i = (cdv->lin) - thisCnt; (retSuccess == CGOS_SUCCESS) && i; index += splitBlockSize)
                          {
                              if (i > splitBlockSize)
                              {
                                  thisCnt = splitBlockSize;
                                  wbuf[2] = splitBlockSize;
                              }
                              else
                              {
                                  thisCnt = i;
                                  if (cnt == 0) //In case 0 Bytes are going to be read a stop condition has to be added here
                                  {
                                      wbuf[2] = i | CGBC_I2C_SEND_STOP;
                                  }
                                  else
                                  {
                                      wbuf[2] = i;
                                  }
                              }
                              for (j = 0; j < thisCnt; j++)
                              {
                                  wbuf[4 + j] = inputBuf[index + j];
                              }

                              retSuccess = bcCommand(&wbuf[0], (unsigned char)(4 + thisCnt), NULL, 0, &sts);
                              if (retSuccess == CGOS_SUCCESS)
                              {
                                  do
                                  {
                                      retSuccess = I2CBusGetStatus(cdv, cdv->i2c[cdv->cin->type].cgbctype, &sts);
                                  } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
                                  if (sts == CGBC_I2C_STAT_IDL)
                                  {
                                      i = i - thisCnt;
                                      retSuccess = CGOS_SUCCESS;
                                  }
                                  else
                                  {
                                      retSuccess = CGOS_ERROR;
                                  }
                              }
                          }
                      }
                      else
                      {
                          retSuccess = CGOS_ERROR;
                      }
                  }
              }
          }
      //Read Part

      if (cdv->cin->type >= cdv->brd->i2cCount)
      {
          retSuccess = CGOS_ERROR;
      }
      else
      {
          if (len == 0) //In case 0 Bytes are written, this has to be called first
          {
              wbuf[0] = CGBC_CMD_I2C_START_EXT;
              wbuf[1] = bus;
              wbuf[2] = CGBC_I2C_SEND_START | 1;
              wbuf[3] = 0;
              wbuf[4] = addr & 0xFE;
              retSuccess = bcCommand(&wbuf[0], 5, NULL, 0, &sts);
          }

          if (retSuccess == CGOS_SUCCESS)
          {
              do
              {
                  retSuccess = I2CBusGetStatus(cdv, bus, &sts);
              } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));

              if (sts == CGBC_I2C_STAT_IDL)
              {
                  splitBlockSize = 31;
                  // Limitation due to CGBC Command Status Byte, 31 is the maximum read value the 
                  // Board Controller can return in RC[4:0].
                  //    ___________________________________
                  //   | 7   6  |  5  |  4   3   2   1   0 |
                  //   |________|_____|____________________|
                  //   |ST[1:0] | RES |      RC[4:0]       |
                  //   |________|_____|____________________|
                  // 
                  // ST[1:0]	command state: 00 = DATA
                  //                             01 = READY
                  //                             10 = BUSY
                  //                             11 = ERROR
                  // RES		reserved/normally return 0/maybe used as RC[5] with GEN5 cBC
                  // RC[4:0]	command return code command state is READY
                  //              data count when command state is DATA
                  //              error code when command state is ERROR

#ifdef __linux__
                  for (i = cnt; (retSuccess == CGOS_SUCCESS) && i; /*(unsigned char*)*/cdv->pout += splitBlockSize)
#else
                  for (i = cnt; (retSuccess == CGOS_SUCCESS) && i; (unsigned char*)cdv->pout += splitBlockSize)
#endif
                  {
                      rbuf[0] = CGBC_CMD_I2C_START_EXT;
                      rbuf[1] = bus;
                      if (i == cnt)
                      {
                          rbuf[2] = CGBC_I2C_SEND_START | 1;
                          rbuf[4] = addr | 0x01;
                      }
                      else
                      {
                          rbuf[2] = 0;
                      }

                      if (i <= splitBlockSize)
                      {
                          rbuf[2] |= CGBC_I2C_SEND_STOP;
                          rbuf[3] = i;
                      }
                      else
                      {
                          rbuf[3] = CGBC_I2C_SEND_LAST_ACK | splitBlockSize;
                      }
                      retSuccess = bcCommand(&rbuf[0], (unsigned char)((cnt == i) ? 5 : 4), NULL, 0, &sts);

                      if (retSuccess == CGOS_SUCCESS)
                      {
                          do
                          {
                              retSuccess = I2CBusGetStatus(cdv, bus, &sts);
                          } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));
                          if (sts == CGBC_I2C_STAT_DAT)
                          {
                              rbuf[0] = CGBC_CMD_I2C_DATA_EXT;
                              rbuf[1] = bus;
                              retSuccess = bcCommand(&rbuf[0], 2, cdv->pout, (unsigned char)(rbuf[3] & 0x3F), &sts);
                              if (retSuccess == CGOS_SUCCESS)
                              {
                                  if (sts == (rbuf[3] & 0x3F))
                                  {
                                      i -= rbuf[3] & 0x3F;
                                  }
                                  else
                                  {
                                      retSuccess = CGOS_ERROR;
                                  }
                              }
                          }
                      }
                  }
              }
          }
          cdv->retcnt += cdv->lout;
      }
      return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosI2CFastCombined(CGOS_DRV_VARS *cdv)
 *
 ***********************************************************************
 * Description: I2C fast write read combined function entry, dispatches 
 *              call to BC4 or EXT function.
 * 
 ***********************************************************************/
  unsigned int zCgosI2CFastCombined(CGOS_DRV_VARS* cdv)
  {
      dbgi2c(printk("zCgosI2CFastCombined called\n");)

      if ((cdv->brd->BC_Type == BC_TYPE_GEN5) || (cdv->brd->BC_Type == BC_TYPE_GEN6))
      {
          return CgosI2CFastCombined_EXT(cdv);
      }
      else if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C))
      {
          return CgosI2CFastCombined_BC4(cdv);
      }
      else
      {
          return CGOS_ERROR;
      }
  }

/***********************************************************************
 * unsigned int CgosI2CFastCombined_BC4(CGOS_DRV_VARS *cdv)           
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CFastCombined(HCGOS hCgos,                 
 *                                         unsigned long dwUnit,        
 *                                         unsigned char bAddr,         
 *                                         unsigned char *pBytesWrite,  
 *                                         unsigned long dwLenWrite,    
 *                                         unsigned char *pBytesRead,   
 *                                         unsigned long dwLenRead)     
 * Inputs:                                                             
 * dwUnit       <->     cdv->cin->type                                  
 * bAddr        <->     cdv->cin->pars[0]                               
 * pBytesWrite  <->     cdv->lin                                        
 * dwLenWrite   <->     cdv->lin                                        
 * dwLenRead    <->     cdv->lout                                      
 *                                                                      
 * Output:                                                              
 * pBytesRead   <->     (unsigned char*)cdv->pout                       
 *                                                                      
 ***********************************************************************
 * Description: Execute a combined write and read action using the old
 *              CGBC_CMD_I2C_COMBINED cBC command.
 * 
 ***********************************************************************/  
unsigned int CgosI2CFastCombined_BC4(CGOS_DRV_VARS *cdv)
  { 
    	unsigned char wbuf[4+34];
    	unsigned char wbuf2;
    	unsigned char sts;
    	unsigned char retSuccess = CGOS_SUCCESS;
    	unsigned int lenRead = cdv->lout;	//Has to be min 1, max 32
    	unsigned int lenWrite = cdv->lin;	//Has to be min 1, max 34
    	unsigned char addr = cdv->cin->pars[0]; 
    	unsigned char unit = cdv->cin->type;
    	unsigned char bus = cdv->i2c[cdv->cin->type].cgbctype;;

    	dbgi2c(printk("CgosI2CWriteReadCombined_BC4 called\n");)  
    
	if((unit >= cdv->brd->i2cCount)||(lenRead < 1)||(lenRead > 32)||(lenWrite < 1)||(lenWrite > 34))
	{
        	retSuccess = CGOS_ERROR;
    	}
    	else
    	{
    		wbuf[0] = CGBC_CMD_I2C_COMBINED | bus;
    		wbuf[1] = 1 + lenWrite;
    		wbuf[2] = lenRead;
    		wbuf[3] = addr;
        	OsaMemCpy(&wbuf[4],cdv->pin,lenWrite);
        	
        	retSuccess = bcCommand(&wbuf[0], 4+lenWrite, NULL, 0, &sts);
                    
                if(retSuccess == CGOS_SUCCESS)
                {
                	do
                	{
                		retSuccess = I2CBusGetStatus(cdv, bus, &sts );
                	} while( (retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY) );
                	
                	if( sts == CGBC_I2C_STAT_DAT )
                	{
                		wbuf2 = CGBC_CMD_I2C_DATA | bus;
                	        retSuccess = bcCommand(&wbuf2, 1, cdv->pout, (lenRead & 0x3F), &sts);
                        }
                 }
                 cdv->retcnt += lenRead;
    	}	
    	return retSuccess; 
  }

/***********************************************************************
 * unsigned int CgosI2CFastCombined_EXT(CGOS_DRV_VARS *cdv)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CFastCombined(HCGOS hCgos,
 *                                         unsigned long dwUnit,
 *                                         unsigned char bAddr,
 *                                         unsigned char *pBytesWrite,
 *                                         unsigned long dwLenWrite,
 *                                         unsigned char *pBytesRead,
 *                                         unsigned long dwLenRead)
 * Inputs:
 * dwUnit       <->     cdv->cin->type
 * bAddr        <->     cdv->cin->pars[0]
 * pBytesWrite  <->     cdv->lin
 * dwLenWrite   <->     cdv->lin
 * dwLenRead    <->     cdv->lout
 *
 * Output:
 * pBytesRead   <->     (unsigned char*)cdv->pout
 *
 ***********************************************************************
 * Description: Execute a combined write and read action using the new
 *              CGBC_CMD_I2C_COMBI_EXT cBC command.
 * 
 ***********************************************************************/
unsigned int CgosI2CFastCombined_EXT(CGOS_DRV_VARS* cdv)
{
    unsigned char wbuf[5 + 34];
    unsigned char wbuf2[2];
    unsigned char sts;
    unsigned char retSuccess = CGOS_SUCCESS;
    unsigned int lenRead = cdv->lout;	//Has to be min 1, max 32
    unsigned int lenWrite = cdv->lin;	//Has to be min 1, max 34
    unsigned char addr = cdv->cin->pars[0];
    unsigned char unit = cdv->cin->type;
    unsigned char bus = cdv->i2c[cdv->cin->type].cgbctype;;

    dbgi2c(printk("CgosI2CWriteReadCombined_EXT called\n");)

        if ((unit >= cdv->brd->i2cCount) || (lenRead < 1) || (lenRead > 32) || (lenWrite < 1) || (lenWrite > 34))
        {
            retSuccess = CGOS_ERROR;
        }
        else
        {
            wbuf[0] = CGBC_CMD_I2C_COMBI_EXT;
            wbuf[1] = bus;
            wbuf[2] = 1 + lenWrite;
            wbuf[3] = lenRead;
            wbuf[4] = addr;
            OsaMemCpy(&wbuf[5], cdv->pin, lenWrite);

            retSuccess = bcCommand(&wbuf[0], 5 + lenWrite, NULL, 0, &sts);

            if (retSuccess == CGOS_SUCCESS)
            {
                do
                {
                    retSuccess = I2CBusGetStatus(cdv, bus, &sts);
                } while ((retSuccess == CGOS_SUCCESS) && (sts == CGBC_I2C_STAT_BSY));

                if (sts == CGBC_I2C_STAT_DAT)
                {
                    wbuf2[0] = CGBC_CMD_I2C_DATA_EXT;
                    wbuf2[1] = bus;
                    retSuccess = bcCommand(&wbuf2[0], 2, cdv->pout, (lenRead & 0x3F), &sts);
                }
            }
            cdv->retcnt += lenRead;
        }
    return retSuccess;
}

/***********************************************************************
 * unsigned int zCgosI2CGetMaxFrequency(CGOS_DRV_VARS *cdv)             
 *                                                                     
 ***********************************************************************
 * Cgos Function: CgosI2CGetMaxFrequency(HCGOS hCgos,                   
 *                                       unsigned long dwUnit,          
 *                                       unsigned long *pdwSetting)     
 * Inputs:                                                              
 *   -                                                                  
 *                                                                      
 * Output:                                                             
 * pdwSetting   <->     cdv->cout->rets[0]                              
 *                                                                     
 ***********************************************************************
 * Description: Gets the maximum i2c frequency.                         
 *                                                                                                                            
 ***********************************************************************/  
unsigned int zCgosI2CGetMaxFrequency(CGOS_DRV_VARS *cdv)
  {
    unsigned char stat;
    unsigned char unit;
    unsigned char bus;
    unsigned char value;
    unsigned char writeBuf;
    unsigned char readBuf[14];
    unsigned int retSuccess = CGOS_SUCCESS;
    
    dbgi2c(printk("zCgosI2CGetMaxFrequency called\n");)    
    
    if(cdv->cin->type >= cdv->brd->i2cCount)
    {
        retSuccess = CGOS_ERROR;
    }
    else
    {
    	bus = cdv->i2c[cdv->cin->type].cgbctype; 
    	writeBuf = CGBC_CMD_INFO_1;

    	if(!bcCommand(&writeBuf,sizeof(writeBuf),&readBuf[0],sizeof(readBuf),&stat)) //Get Info from cBC
    	{
    		if(bus == CGBC_I2C_BUS_EXTERNAL)
    		{
       			unit = readBuf[3] & CGBC_I2C_FREQ_UNIT_MASK;
       			value = readBuf[3] & CGBC_I2C_FREQ_VALUE_MSK;
       		}
       		else if((bus == CGBC_I2C_BUS_SMB0) || (bus == CGBC_I2C_BUS_SMB1) || (bus == CGBC_I2C_BUS_SMB2))
       		{
       			unit = readBuf[4] & CGBC_I2C_FREQ_UNIT_MASK;
       			value = readBuf[4] & CGBC_I2C_FREQ_VALUE_MSK;
       		}
       		else if(bus == CGBC_I2C_BUS_EPI)
       		{
       		        unit = readBuf[5] & CGBC_I2C_FREQ_UNIT_MASK;
       			value = readBuf[5] & CGBC_I2C_FREQ_VALUE_MSK;
       		}
       		else
       		{
       			return CGOS_ERROR;
       		}
       		if(unit == CGBC_I2C_FREQ_UNIT_100KHZ)
       		{
       		    cdv->cout->rets[0] = value * 100000;
       		}
       		else if(unit == CGBC_I2C_FREQ_UNIT_10KHZ)
       		{
       		    cdv->cout->rets[0] = value * 10000;
       		}
       		else if(unit == CGBC_I2C_FREQ_UNIT_1KHZ)
       		{
       		    cdv->cout->rets[0] = value * 1000;
       		}
       		else if(unit == CGBC_I2C_FREQ_UNIT_100HZ)
       		{
       		    cdv->cout->rets[0] = value * 100;
       		}
       		else
       		{
       		    cdv->cout->rets[0] = value;
       		}
    	}	
    	else
    	{
        	retSuccess = CGOS_ERROR;
    	}
    }
    return retSuccess;
  }

/***********************************************************************
 * unsigned int zCgosI2CGetFrequency(CGOS_DRV_VARS *cdv)
 *
 ***********************************************************************
 * Description: I2C get frequency function entry, dispatches 
 *              call to BC4 or EXT get frequency function.
 ***********************************************************************/
unsigned int zCgosI2CGetFrequency(CGOS_DRV_VARS* cdv)
{
    dbgi2c(printk("zCgosI2CGetFrequency called\n");)
    
    if ((cdv->brd->BC_Type == BC_TYPE_GEN5) || (cdv->brd->BC_Type == BC_TYPE_GEN6))
    {
        return CgosI2CGetFrequency_EXT(cdv);
    }
    else if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C))
    {
        return CgosI2CGetFrequency_BC4(cdv);
    }
    else
    {
        return CGOS_ERROR;
    }
}

/***********************************************************************
 * unsigned int CgosI2CGetFrequency_BC4(CGOS_DRV_VARS *cdv)                
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CGetFrequency(HCGOS hCgos,                      
 *                                    unsigned long dwUnit,             
 *                                    unsigned long *pdwSetting)        
 * Input:                                                               
 * dwUnit       <->     cdv->cin->type;                                
 *                                                                      
 * Output:                                                              
 * pdwSetting   <->     cdv->cout->rets[0]                              
 *                                                                      
 ***********************************************************************
 * Description: Get the current i2c frequency using the old  
 *              CGBC_CMD_I2C_SPEED cBC command.
 * 
 ***********************************************************************/  
unsigned int CgosI2CGetFrequency_BC4(CGOS_DRV_VARS *cdv)               
  {
    unsigned char stat;
    unsigned char erg;
    unsigned char unit; 
    unsigned char  bus;
    unsigned char value;
    unsigned char writeBuf[2];
    unsigned int retSuccess = CGOS_SUCCESS;
    
    dbgi2c(printk("CgosI2CGetFrequency_BC4 called\n");)
    
    if(cdv->cin->type >= cdv->brd->i2cCount)
    {
        retSuccess = CGOS_ERROR;
    }
    else
    {
    	bus = cdv->i2c[cdv->cin->type].cgbctype;
    	if(cdv->cin->type >= cdv->brd->i2cCount)
    	{
        	retSuccess = CGOS_ERROR;
    	}
    	else
    	{
        	writeBuf[0] = CGBC_CMD_I2C_SPEED | bus;
        	writeBuf[1] = 0x00;
        	if(!bcCommand(&writeBuf[0],2, &erg, 1,&stat))
        	{
        	    unit = erg & CGBC_I2C_FREQ_UNIT_MASK;
        	    value = erg & CGBC_I2C_FREQ_VALUE_MSK;
        	    if(unit == CGBC_I2C_FREQ_UNIT_100KHZ)
        	    {
        	        cdv->cout->rets[0] = value * 100000;
        	    }
        	    else if(unit == CGBC_I2C_FREQ_UNIT_10KHZ)
        	    {
        	        cdv->cout->rets[0] = value * 10000;
        	    }
        	    else if(unit == CGBC_I2C_FREQ_UNIT_1KHZ)
        	    {
        	        cdv->cout->rets[0] = value * 1000;
        	    }
        	    else if(unit == CGBC_I2C_FREQ_UNIT_100HZ)
        	    {
        	        cdv->cout->rets[0] = value * 100;
        	    }
        	    else
        	    {
        	        cdv->cout->rets[0] = value;
        	    }
        	}
        	else 
        	{
        	    retSuccess = CGOS_ERROR;
        	} 
    	}
    }
    return retSuccess;
  }

/***********************************************************************
 * unsigned int CgosI2CGetFrequency_EXT(CGOS_DRV_VARS *cdv)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CGetFrequency(HCGOS hCgos,
 *                                    unsigned long dwUnit,
 *                                    unsigned long *pdwSetting)
 * Input:
 * dwUnit       <->     cdv->cin->type;
 *
 * Output:
 * pdwSetting   <->     cdv->cout->rets[0]
 *
 ***********************************************************************
 * Description: Get the current i2c frequency using the new 
 *              CGBC_CMD_I2C_SPEED_EXT cBC command.
 * 
 ***********************************************************************/
unsigned int CgosI2CGetFrequency_EXT(CGOS_DRV_VARS* cdv)
{
    unsigned char stat;
    unsigned char erg;
    unsigned char unit;
    unsigned char  bus;
    unsigned char value;
    unsigned char writeBuf[3];
    unsigned int retSuccess = CGOS_SUCCESS;

    dbgi2c(printk("CgosI2CGetFrequency_EXT called\n");)

        if (cdv->cin->type >= cdv->brd->i2cCount)
        {
            retSuccess = CGOS_ERROR;
        }
        else
        {
            bus = cdv->i2c[cdv->cin->type].cgbctype;
            if (cdv->cin->type >= cdv->brd->i2cCount)
            {
                retSuccess = CGOS_ERROR;
            }
            else
            {
                writeBuf[0] = CGBC_CMD_I2C_SPEED_EXT;
                writeBuf[1] = bus;
                writeBuf[2] = 0x00;
                if (!bcCommand(&writeBuf[0], 3, &erg, 1, &stat))	//MOD24
                {
                    unit = erg & CGBC_I2C_FREQ_UNIT_MASK;
                    value = erg & CGBC_I2C_FREQ_VALUE_MSK;
                    if (unit == CGBC_I2C_FREQ_UNIT_100KHZ)
                    {
                        cdv->cout->rets[0] = value * 100000;
                    }
                    else if (unit == CGBC_I2C_FREQ_UNIT_10KHZ)
                    {
                        cdv->cout->rets[0] = value * 10000;
                    }
                    else if (unit == CGBC_I2C_FREQ_UNIT_1KHZ)
                    {
                        cdv->cout->rets[0] = value * 1000;
                    }
                    else if (unit == CGBC_I2C_FREQ_UNIT_100HZ)
                    {
                        cdv->cout->rets[0] = value * 100;
                    }
                    else
                    {
                        cdv->cout->rets[0] = value;
                    }
                }
                else
                {
                    retSuccess = CGOS_ERROR;
                }
            }
        }
    return retSuccess;
}

/***********************************************************************
 * unsigned int zCgosI2CSetFrequency(CGOS_DRV_VARS *cdv)
 *
 ***********************************************************************
 * Description: I2C set frequency function entry, dispatches call
 *              to BC4 or EXT set frequency function.
 ***********************************************************************/
unsigned int zCgosI2CSetFrequency(CGOS_DRV_VARS* cdv)
{
    dbgi2c(printk("zCgosI2CSetFrequency called\n");)

        if ((cdv->brd->BC_Type == BC_TYPE_GEN5) || (cdv->brd->BC_Type == BC_TYPE_GEN6))
        {
            return CgosI2CSetFrequency_EXT(cdv);
        }
        else if ((cdv->brd->BC_Type == BC_TYPE_BC4_BASE_E) || (cdv->brd->BC_Type == BC_TYPE_BC4_BASE_C))
        {
            return CgosI2CSetFrequency_BC4(cdv);
        }
        else
        {
            return CGOS_ERROR;
        }
}

/***********************************************************************
 * unsigned int CgosI2CSetFrequency_BC4(CGOS_DRV_VARS *cdv)                
 *                                                                      
 ***********************************************************************
 * Cgos Function: CgosI2CSetFrequency(HCGOS hCgos,                      
 *                                    unsigned long dwUnit,             
 *                                    unsigned long pdwSetting)         
 * Inputs:                                                              
 * dwUnit       <->     cdv->cin->type;                                
 * pdwSetting   <->     cdv->cout->pars[0];                             
 *                                                                      
 * Outputs:                                                             
 *   -                                                                  
 *                                                                      
 ***********************************************************************
 * Description: Set i2c frequency to pdwSetting using the old
 *              CGBC_CMD_I2C_SPEED cBC command.
 * 
 ***********************************************************************/  
unsigned int CgosI2CSetFrequency_BC4(CGOS_DRV_VARS *cdv)                   
  {
    unsigned char stat;
    unsigned char bus;
    unsigned char ret = 0;
    unsigned int value = cdv->cin->pars[0];
    unsigned char dataByte = 0x00;
    unsigned char writeBuf[2];
    unsigned int retSuccess = CGOS_SUCCESS;
    
    dbgi2c(printk("CgosI2CSetFrequency_BC4 called\n");)
    
    if(cdv->cin->type >= cdv->brd->i2cCount)
    {
        retSuccess = CGOS_ERROR;
    }
    else
    {
    	bus = cdv->i2c[cdv->cin->type].cgbctype;
    	if(cdv->cin->type >= cdv->brd->i2cCount)
    	{
        	retSuccess = CGOS_ERROR;
    	}
    	else
    	{
        	writeBuf[0] = CGBC_CMD_I2C_SPEED | bus;        
        	if((value >= 100000)&&(value <= 6100000))	//MOD24
        	{
        		dataByte |= CGBC_I2C_FREQ_UNIT_100KHZ;
        		value /= 100000;
        	}
        	else if((value >= 10000)&&(value < 100000))
        	{
        		dataByte |= CGBC_I2C_FREQ_UNIT_10KHZ;
       			value /= 10000;
        	}
        	else if((value >= 1000)&&(value < 10000))
        	{
        		dataByte |= CGBC_I2C_FREQ_UNIT_1KHZ;
        		value /= 1000;
        	}
        	else if((value >= 100)&&(value < 1000))
        	{
        		dataByte |= CGBC_I2C_FREQ_UNIT_100HZ;
        		value /= 100;
        	}
        	else
        	{
        		retSuccess = CGOS_ERROR;
        	}
        	
        	if(retSuccess == CGOS_SUCCESS)
        	{
        		writeBuf[1] = dataByte | (CGBC_I2C_FREQ_VALUE_MSK & value);
        		if(!bcCommand(&writeBuf[0],2, &ret, 1,&stat))	//MOD24
        		{   
        	    		cdv->cout->rets[0] = ret;
        	    		retSuccess = CGOS_SUCCESS;
        		} 
        		else
        		{
        	    		retSuccess = CGOS_ERROR;
        		}
    		}
    	}
    }
    return retSuccess;
  }

/***********************************************************************
 * unsigned int CgosI2CSetFrequency_EXT(CGOS_DRV_VARS *cdv)
 *
 ***********************************************************************
 * Cgos Function: CgosI2CSetFrequency(HCGOS hCgos,
 *                                    unsigned long dwUnit,
 *                                    unsigned long pdwSetting)
 * Inputs:
 * dwUnit       <->     cdv->cin->type;
 * pdwSetting   <->     cdv->cout->pars[0];
 *
 * Outputs:
 *   -
 *
 ***********************************************************************
 * Description: Set i2c frequency to pdwSetting using the new
 *              CGBC_CMD_I2C_SPEED_EXT cBC command.
 * 
 ***********************************************************************/
unsigned int CgosI2CSetFrequency_EXT(CGOS_DRV_VARS* cdv)
{
    unsigned char stat;
    unsigned char bus;
    unsigned char ret = 0;
    unsigned int value = cdv->cin->pars[0];
    unsigned char dataByte = 0x00;
    unsigned char writeBuf[3];
    unsigned int retSuccess = CGOS_SUCCESS;

    dbgi2c(printk("CgosI2CSetFrequency_EXT called\n");)

        if (cdv->cin->type >= cdv->brd->i2cCount)
        {
            retSuccess = CGOS_ERROR;
        }
        else
        {
            bus = cdv->i2c[cdv->cin->type].cgbctype;
            if (cdv->cin->type >= cdv->brd->i2cCount)
            {
                retSuccess = CGOS_ERROR;
            }
            else
            {
                writeBuf[0] = CGBC_CMD_I2C_SPEED_EXT;
                writeBuf[1] = bus;
                if ((value >= 100000) && (value <= 6100000))	//MOD24
                {
                    dataByte |= CGBC_I2C_FREQ_UNIT_100KHZ;
                    value /= 100000;
                }
                else if ((value >= 10000) && (value < 100000))
                {
                    dataByte |= CGBC_I2C_FREQ_UNIT_10KHZ;
                    value /= 10000;
                }
                else if ((value >= 1000) && (value < 10000))
                {
                    dataByte |= CGBC_I2C_FREQ_UNIT_1KHZ;
                    value /= 1000;
                }
                else if ((value >= 100) && (value < 1000))
                {
                    dataByte |= CGBC_I2C_FREQ_UNIT_100HZ;
                    value /= 100;
                }
                else
                {
                    retSuccess = CGOS_ERROR;
                }

                if (retSuccess == CGOS_SUCCESS)
                {
                    writeBuf[2] = dataByte | (CGBC_I2C_FREQ_VALUE_MSK & value);
                    if (!bcCommand(&writeBuf[0], 3, &ret, 1, &stat))	//MOD24
                    {
                        cdv->cout->rets[0] = ret;
                        retSuccess = CGOS_SUCCESS;
                    }
                    else
                    {
                        retSuccess = CGOS_ERROR;
                    }
                }
            }
        }
    return retSuccess;
}

/***********************************************************************
 * void exitI2CModule(CGOS_DRV_VARS *cdv)                               
 *                                                                      
 ***********************************************************************
 * Description: This function is called during driver close and should  
 *              free allocated resources.                               
 *                                                                                                                           
 ***********************************************************************/
void exitI2CModule(CGOS_DRV_VARS *cdv)
{
	dbgi2c(printk("exitI2CModule called\n");)
}
