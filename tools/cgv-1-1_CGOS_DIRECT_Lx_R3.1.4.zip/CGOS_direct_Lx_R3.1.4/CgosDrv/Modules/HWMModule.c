/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2025, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 

#ifdef __linux__
#include <linux/printk.h> 
#endif

//MOD_3.1.2_3 v
#include "../CgosDrv.h"
#include "../CGBC.h"
//MOD_3.1.2_3 ^
#include "BCModule.h"
#include "HWMAddon_CPU_Temp.h"	////MOD_3.1.2_1


//***************************************************************************

//#define dbg_hwm_on

#ifdef dbg_hwm_on
	#define dbghwm(x) x
#else
	#define dbghwm(x)
#endif

//***************************************************************************
// Global Variables

static unsigned int tempcnt;
static unsigned int fancnt;
static unsigned int voltcnt;
static unsigned int sensorcnt;

static CGOS_DRV_TEMP_ENTRY TempList[CGOS_DRV_TEMP_MAX] = {0};
static CGOS_DRV_FAN_ENTRY FanList[CGOS_DRV_FAN_MAX] = {0};
static CGOS_DRV_VOLT_ENTRY VoltList[CGOS_DRV_VOLT_MAX] = {0};

//***************************************************************************
//Function prototypes

unsigned int GetErrorFlag(unsigned char byte);
unsigned int GetTempSensorType(unsigned char byte);
unsigned int GetVoltSensorType(unsigned char byte);
unsigned int GetFanSensorType(unsigned char byte);
unsigned int initHWMModule(CGOS_DRV_VARS *cdv);

unsigned int initTemperature_BC(CGOS_DRV_VARS *cdv);
unsigned int zCgosTemperatureCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosTemperatureGetInfo(CGOS_DRV_VARS *cdv);
unsigned int zCgosTemperatureGetCurrent(CGOS_DRV_VARS *cdv);
unsigned int zCgosTemperatureSetLimits(CGOS_DRV_VARS *cdv);

unsigned int initFan_BC(CGOS_DRV_VARS *cdv);
unsigned int zCgosFanCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosFanGetInfo(CGOS_DRV_VARS *cdv);
unsigned int zCgosFanGetCurrent(CGOS_DRV_VARS *cdv);
unsigned int zCgosFanSetLimits(CGOS_DRV_VARS *cdv);

unsigned int initVoltage_BC(CGOS_DRV_VARS *cdv);
unsigned int zCgosVoltageCount(CGOS_DRV_VARS *cdv);
unsigned int zCgosVoltageGetInfo(CGOS_DRV_VARS *cdv);
unsigned int zCgosVoltageGetCurrent(CGOS_DRV_VARS *cdv);				
unsigned int zCgosVoltageSetLimits(CGOS_DRV_VARS *cdv);

unsigned int initPerformance_BC(CGOS_DRV_VARS *cdv);
unsigned int zCgosPerformanceGetCurrent(CGOS_DRV_VARS *cdv);
unsigned int zCgosPerformanceSetCurrent(CGOS_DRV_VARS *cdv);
unsigned int zCgosPerformanceGetPolicyCaps(CGOS_DRV_VARS *cdv);
unsigned int zCgosPerformanceGetPolicy(CGOS_DRV_VARS *cdv);
unsigned int zCgosPerformanceSetPolicy(CGOS_DRV_VARS *cdv);

void exitHWMModule(CGOS_DRV_VARS *cdv);

//***************************************************************************
//Helper functions

unsigned int GetErrorFlag(unsigned char byte)
{
	switch (byte)
	{
		case 0x00:	//Sensor not present
					return CGOS_SENSOR_BROKEN;
					
		case 0x01:	//Sensor not supported
					return CGOS_SENSOR_BROKEN;
					
		case 0x02:	//Sensor inactive
					return CGOS_SENSOR_BROKEN;
					
		case 0x03:	//Sensor broken or open
					return CGOS_SENSOR_BROKEN;
					
		case 0x04:	//Sensor shortcut
					return CGOS_SENSOR_SHORTCIRCUIT;
					
		default: 	//reserved values
					return CGOS_SENSOR_BROKEN;
	}
}

unsigned int GetTempSensorType(unsigned char byte)
{
	switch(byte)
	{
		case 0b00001:	//CPU temperature
						return CGOS_TEMP_CPU;
						
		case 0b00010:	//case temperature
						return CGOS_TEMP_BOX;
						
		case 0b00011:	//ambient temperature
						return CGOS_TEMP_ENV;
						
		case 0b00100:	//CPU board temperature
						return CGOS_TEMP_BOARD;
						
		case 0b00101:	//carrier board temperature
						return CGOS_TEMP_BACKPLANE;
						
		case 0b00110:	//chipset temperature
						return CGOS_TEMP_CHIPSETS;
						
		case 0b00111:	//viedeo controller/board temperature
						return CGOS_TEMP_VIDEO;
						
		case 0b01000:	//other temperature sensor type
						return CGOS_TEMP_OTHER;
						
		case 0b01001:	//top DIMM temperature
						return CGOS_TEMP_TOPDIMM_ENV;
						
		case 0b01010:	//bottom DIMM temperature 
						return CGOS_TEMP_BOTDIMM_ENV;
						
		default:		//reserved values
						return CGOS_TEMP_OTHER;
	}
}

unsigned int GetVoltSensorType(unsigned char byte)
{
	switch(byte)
	{
		case 0b00001:	//CPU core voltage
						return CGOS_VOLTAGE_VCOREA;
		
		case 0b00010:	//DC runtime voltage
						return CGOS_VOLTAGE_DC;
						
		case 0b00011:	//DC standby voltage
						return CGOS_VOLTAGE_DC_STANDBY;
						
		case 0b00100:	//CMOS battery voltage
						return CGOS_VOLTAGE_BAT_CMOS;
						
		case 0b00101:	//battery supply voltage
						return CGOS_VOLTAGE_BAT_POWER;
						
		case 0b00110:	//AC voltage
						return CGOS_VOLTAGE_OTHER;
						
		case 0b00111:	//other voltage sensor type
						return CGOS_VOLTAGE_OTHER;
						
		case 0b01000:	//5V runtime voltage
						return CGOS_VOLTAGE_5V_S0;
						
		case 0b01001:	//5V standby voltage
						return CGOS_VOLTAGE_5V_S5;
						
		case 0b01010:	//3.3V runtime voltage
						return CGOS_VOLTAGE_33V_S0;
						
		case 0b01011:	//3.3V standby voltage
						return CGOS_VOLTAGE_33V_S5;
						
		case 0b01100:	//chipset core voltage A
						return CGOS_VOLTAGE_VCOREA;
						
		case 0b01101:	//chipset core voltage B
						return CGOS_VOLTAGE_VCOREB;
						
		case 0b01110:	//12V runtime voltage
						return CGOS_VOLTAGE_12V_S0;
						
		case 0b10010:	//DC runtime current
						return CGOS_VCURRENT_DC;
						
		case 0b11000:	//5V runtime current
						return CGOS_VCURRENT_5V_S0;
						
		case 0b11110:	//12V runtime current
						return CGOS_VCURRENT_12V_S0;
		
		default:		//reserved values
						return CGOS_VOLTAGE_OTHER;
	}
}

unsigned int GetFanSensorType(unsigned char byte)
{
	switch(byte)
	{
		case 0b00001:	//CPU fan
						return CGOS_FAN_CPU;
						
		case 0b00010:	//case fan
						return CGOS_FAN_BOX;
						
		case 0b00011:	//ambient fan
						return CGOS_FAN_OTHER;
						
		case 0b00100:	//chipset fan
						return CGOS_FAN_CHIPSET;
						
		case 0b00101:	//video controller/board fan
						return CGOS_FAN_VIDEO;
						
		case 0b00110:	//other fan speed sensor type
						return CGOS_FAN_OTHER;
		
		default:		//reserved values
						return CGOS_FAN_OTHER;
	}
}

//***************************************************************************


/***********************************************************************
 * unsigned int initHWMModule(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: This function calls all init functions of this module.	
 * 																		
 * Last Change: 05.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int initHWMModule(CGOS_DRV_VARS *cdv)
  {	
	unsigned char wbuf[2];
	unsigned char rbuf[5];
	unsigned char SensorStatus = 0;
	unsigned char sts;
	unsigned int type;
	unsigned int i;
	unsigned int retSuccess = CGOS_SUCCESS;
	dbghwm("initHWMModule_BC called\n");
	
	//init 
	tempcnt = 0;
	voltcnt = 0;
	fancnt = 0;
	sensorcnt = 0;
	
	//Get BC sensor count
	wbuf[0] = CGBC_CMD_HWM_SENSOR;
	wbuf[1] = 0;
	
	bcCommand(&wbuf[0],2,&rbuf[0],5,&sts);
	sensorcnt = rbuf[0];
	
	//Get sensor information
	for(i = 0; i < sensorcnt; i++)
	{
		//Get information of sensor i
		wbuf[1] = i;
		bcCommand(&wbuf[0],2,&rbuf[0],5,&sts);
		
		//evaluate status byte
		SensorStatus = rbuf[1];
		switch((SensorStatus & 0x60) >> 5)
		{
			case 0b01:	//Temperature Sensor
						TempList[tempcnt].BCUnitNumber = i;
						TempList[tempcnt].tempinfo.dwSize = sizeof(CGOSTEMPERATUREINFO);
						type = GetTempSensorType(SensorStatus & 0x1F);
						if(type != CGOS_ERROR)
						{
							TempList[tempcnt].tempinfo.dwType = type;
						}
						if(((SensorStatus & 0x80) >> 7) == 0)	//Sensor Status inactive
						{
							TempList[tempcnt].tempinfo.dwFlags = GetErrorFlag(rbuf[2]);
						}
						else 	//Sensor Status active
						{
							TempList[tempcnt].tempinfo.dwFlags = CGOS_SENSOR_ACTIVE;
						}
						tempcnt++;
						
						break;
			case 0b10:	//Voltage Sensor
						VoltList[voltcnt].BCUnitNumber = i;
						VoltList[voltcnt].voltinfo.dwSize = sizeof(CGOSVOLTAGEINFO);
						type = GetVoltSensorType(SensorStatus & 0x1F);
						if(type != CGOS_ERROR)
						{
							VoltList[voltcnt].voltinfo.dwType = type;
						}
						if(((SensorStatus & 0x80) >> 7) == 0)	//Sensor Status inactive
						{
							VoltList[voltcnt].voltinfo.dwFlags = GetErrorFlag(rbuf[2]);
						}
						else 	//Sensor Status active
						{
							VoltList[voltcnt].voltinfo.dwFlags = CGOS_SENSOR_ACTIVE;
						}
						voltcnt++;
						break;
			case 0b11:	//Fan Sensor
						FanList[fancnt].BCUnitNumber = i;
						FanList[fancnt].faninfo.dwSize = sizeof(CGOSFANINFO);
						type = GetFanSensorType(SensorStatus & 0x1F);
						if(type != CGOS_ERROR)
						{
							FanList[fancnt].faninfo.dwType = type;
						}
						if(((SensorStatus & 0x80) >> 7) == 0)	//Sensor Status inactive
						{
							FanList[fancnt].faninfo.dwFlags = GetErrorFlag(rbuf[2]);
						}
						else 	//Sensor Status active
						{
							FanList[fancnt].faninfo.dwFlags = CGOS_SENSOR_ACTIVE;
						}
						fancnt++;
						break;
			default:
						break;
		}
	}
	
	//Call init functions
	retSuccess |= initTemperature_BC(cdv);
	retSuccess |= initFan_BC(cdv);
	retSuccess |= initVoltage_BC(cdv);
	//retSuccess |= initPerformance_BC(cdv);		//Performance functions not implemented
	return (retSuccess == CGOS_SUCCESS) ? CGOS_SUCCESS : CGOS_ERROR;
  }

/* **********************************************************************
 * 									*
 *			Temperature Functions				*
 * 									*
 ************************************************************************/
/***********************************************************************
 * unsigned int initTemperature_BC(CGOS_DRV_VARS *cdv) 				    
 * 																		
 ***********************************************************************
 * Description: This function is called to copy temperature information 
 * 				from HWMModule_cfg.h into the cdv struct.				
 * 																		
 * Last Change: 12.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int initTemperature_BC(CGOS_DRV_VARS *cdv)
  {	
	unsigned int retSuccess = CGOS_SUCCESS;
	unsigned int i;
	unsigned int cpuTempFound = 0;		////MOD_3.1.2_1

	dbghwm("initTemperature_BC called\n");
	if(tempcnt <= CGOS_DRV_TEMP_MAX)			//CGOS_DRV_TEMP_MAX defined in DrvVars.h
	{
		cdv->brd->hwmCount.tempCount = tempcnt;
		for(i = 0; i < tempcnt; i++)
		{
		//MOD_3.1.2_1 v
			//Check if CPU Temperature Sensor	//
			if (TempList[i].tempinfo.dwType == CGOS_TEMP_CPU)
			{
				cpuTempFound = 1;
			}

			OsaMemCpy(&cdv->hwm->tempsensors[i],&TempList[i],sizeof(CGOS_DRV_TEMP_ENTRY));  
		}

		//If no CPU Temperature Sensor is found use Addon
		if (!cpuTempFound)
		{
			cdv->brd->useCpuTempAddon = 1;
			retSuccess = addonCpuTempAddTempSensor(cdv);
		}
		////MOD_3.1.2_1 ^
	}
	else
	{
		retSuccess = CGOS_ERROR;
	}
	return retSuccess;
  }
/***********************************************************************
 * unsigned int zCgosTemperatureCount(CGOS_DRV_VARS *cdv)			    
 * 																		
 ***********************************************************************
 * Cgos Function: CgosTemperatureCount(HCGOS hCgos) 				    
 * 																	    
 * Inputs:															    
 *   -												    			    
 * 																	    
 * Outputs:															    
 *   cdv->cout->rets[0]												    
 * 																		
 ***********************************************************************
 * Description: Gets temperature sensor	count.							
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosTemperatureCount(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosTemperatureCount called\n");)
	cdv->cout->rets[0] = cdv->brd->hwmCount.tempCount;
	
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosTemperatureGetInfo(CGOS_DRV_VARS *cdv)			    
 * 																		
 ***********************************************************************
 * Cgos Function: CgosTemperatureGetInfo(HCGOS hCgos, 				    
 * 								 		 unsigned long dwUnit,			
 * 								  		 CGOSTEMPERATUREINFO *pInfo)	
 * Inputs:															    
 *   dwUnit <->		cdv->cin->type					    			    
 * 																	    
 * Outputs:															    
 *   pInfo 	<-> 	cdv->pout										    
 * 																	
 ***********************************************************************
 * Description: Gets info struct of the requested temperature sensor
 * 																		
 * Last Change: 06.12.2017 HMI										
 * 																	
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosTemperatureGetInfo(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosTemperatureGetInfo called\n");)
	if(cdv->cin->type < cdv->brd->hwmCount.tempCount)
	{
		OsaMemCpy(cdv->pout,&cdv->hwm->tempsensors[cdv->cin->type].tempinfo,sizeof(CGOSTEMPERATUREINFO));	
		return CGOS_SUCCESS;
	}
	else
	{
		return CGOS_ERROR;
	}
  }
  
/***********************************************************************
 * unsigned int zCgosTemperatureGetCurrent(CGOS_DRV_VARS *cdv)		    
 * 																		
 ***********************************************************************
 * Cgos Function: CgosTemperatureGetCurrent(HCGOS hCgos, 			    
 * 								 	 		unsigned long dwUnit,		
 * 								  	 		unsigned long *pdwSetting,	
 * 											unsigned long *pdwStatus)	
 * Inputs:															    
 *   dwUnit 	<->		cdv->cin->type				    			    
 * 																	    
 * Outputs:															    
 *   pdwSetting 	<-> 	cdv->cout->rets[0]						    
 * 	 pdwStatus		<->		cdv->cout->rets[1]						
 * 																		
 ***********************************************************************
 * Description: Gets status and value/error code of the	requested		
 * 				temperature sensor.										
 * 																		
 * Last Change: 07.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosTemperatureGetCurrent(CGOS_DRV_VARS *cdv)
  {
	unsigned char wbuf[2];
	unsigned char rbuf[5];
	unsigned char ret;
	unsigned char SensorStatus = 0;
	unsigned char sts;
	int temp;

	dbghwm(printk("zCgosTemperatureGetCurrent called\n");)
	
	if(cdv->cin->type >= cdv->brd->hwmCount.tempCount)
	{
		return CGOS_ERROR;
	}
	//MOD_3.1.2_1 v
	else if (cdv->brd->useCpuTempAddon && (cdv->hwm->tempsensors[cdv->cin->type].tempinfo.dwType == CGOS_TEMP_CPU))
	{
		return addonCpuTempGetTemperature(cdv);
	}
	//MOD_3.1.2_1 ^
	else
	{
		wbuf[0] = CGBC_CMD_HWM_SENSOR;
		wbuf[1] = cdv->hwm->tempsensors[cdv->cin->type].BCUnitNumber;

		ret = bcCommand(&wbuf[0], 2, &rbuf[0], 5, &sts);
		if ((ret != CGOS_SUCCESS) || ((sts & 0xC0) == 0xC0))
		{
			//cdv->cout->status = CGOS_ERROR;
			return CGOS_ERROR;
		}

		SensorStatus = rbuf[1];
		if(((SensorStatus & 0x80) >> 7) == 1)	//Sensor Status active
		{
			//rbuf[2] holds the low byte of the sensor value,
			//rbuf[3] the high byte.
			//negative temperatures are stored in two's complement
			
            //Check whether temperature is positive or negative
			if((rbuf[3] & 0x80) == 0x80)  //negative temperature
			{	                  
	          //Expand from 16 to 32 bit value and use two's complement to get the positive temperature value
			  temp = ~(0xffff0000|(rbuf[3]<<8)|rbuf[2]) +1;
			  
			  //Multiply with 100 because board controller returns 0.1 degree centigrade and cgos api expects
			  //0.001 degree centigrade
			  temp = temp * 100;
			  
			  //Invert and add 1 to get the new 32 bit negative temperature value which has to be passed to upper layers
			  temp = ~temp + 1;
			  
			  cdv->cout->rets[0] = temp;
			}
			else  //positive temperature
			{
			  cdv->cout->rets[0] = ((rbuf[3]<<8)|rbuf[2]) * 100;	// *100 because board controller returns 
										// 0.1 degree centigrade and cgos expects 
										// 0.001 degree centigrade.
			}
			cdv->cout->rets[1] = CGOS_SENSOR_ACTIVE;											
		}
		else //Sensor Status inactive
		{
			cdv->cout->rets[0] = 0;
			cdv->cout->rets[1] = GetErrorFlag(rbuf[2]);
		}
	}
	return CGOS_SUCCESS;
  }
  
unsigned int zCgosTemperatureSetLimits(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosTemperatureSetLimits called\n");)	
	return CGOS_SUCCESS;
  }

/* **********************************************************************
 * 									*
 *				Fan Functions				*
 * 									*
 ************************************************************************/
/***********************************************************************
 * unsigned int initFan_BC(CGOS_DRV_VARS *cdv) 						    
 * 																		
 ***********************************************************************
 * Description: 					
 * 																		
 * Last Change: 12.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int initFan_BC(CGOS_DRV_VARS *cdv)
  {	
	unsigned int retSuccess = CGOS_SUCCESS;
	unsigned int i;
	dbghwm("initFan_BC called\n");
	if(fancnt <= CGOS_DRV_FAN_MAX)			//CGOS_DRV_TEMP_MAX defined in DrvVars.h
	{
		cdv->brd->hwmCount.fanCount = fancnt;
		for(i = 0; i < fancnt; i++)
		{
			OsaMemCpy(&cdv->hwm->fansensors[i],&FanList[i],sizeof(CGOS_DRV_FAN_ENTRY));  
		}
	}
	else
	{
		retSuccess = CGOS_ERROR;
	}
	return retSuccess;
  }
/***********************************************************************
 * unsigned int zCgosFanCount(CGOS_DRV_VARS *cdv)					    
 * 																		
 ***********************************************************************
 * Cgos Function: CgosFanCount(HCGOS hCgos) 						    
 * 																	    
 * Inputs:															    
 *   -												    			    
 * 																	    
 * Outputs:															    
 *   cdv->cout->rets[0]												    
 * 																		
 ***********************************************************************
 * Description: Gets fan sensor	count.									
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosFanCount(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosFanCount called\n");)	
	cdv->cout->rets[0] = cdv->brd->hwmCount.fanCount;
	
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosFanGetInfo(CGOS_DRV_VARS *cdv)					    
 * 																		
 ***********************************************************************
 * Cgos Function: CgosFanGetInfo(HCGOS hCgos, 						    
 * 								 unsigned long dwUnit,				    
 * 								 CGOSFANINFO *pInfo)				    
 * Inputs:															    
 *   dwUnit <->		cdv->cin->type					    			    
 * 																	    
 * Outputs:															    
 *   pInfo 	<-> 	cdv->pout										    
 * 																		
 ***********************************************************************
 * Description: Gets info struct of the requested fan sensor			
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosFanGetInfo(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosFanGetInfo called\n");)	
	if(cdv->cin->type < cdv->brd->hwmCount.fanCount)
	{
		OsaMemCpy(cdv->pout,&cdv->hwm->fansensors[cdv->cin->type].faninfo,sizeof(CGOSFANINFO));	
		return CGOS_SUCCESS;
	}
	else
	{
		return CGOS_ERROR;
	}
  }

/***********************************************************************
 * unsigned int zCgosFanGetCurrent(CGOS_DRV_VARS *cdv)				    
 * 																		
 ***********************************************************************
 * Cgos Function: CgosFanGetCurrent(HCGOS hCgos, 			 			
 * 								 	unsigned long dwUnit,				
 * 								  	unsigned long *pdwSetting,			
 * 									unsigned long *pdwStatus)			
 * Inputs:															    
 *   dwUnit 	<->		cdv->cin->type				    			    
 * 																	    
 * Outputs:															    
 *   pdwSetting 	<-> 	cdv->cout->rets[0]						    
 * 	 pdwStatus		<->		cdv->cout->rets[1]							
 * 																		
 ***********************************************************************
 * Description: Gets status and value/error code of the					
 * 				requested fan sensor									
 * 																		
 * Last Change: 07.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosFanGetCurrent(CGOS_DRV_VARS *cdv)
  {
	unsigned char wbuf[2];
	unsigned char rbuf[5];
	unsigned char SensorStatus = 0;
	unsigned char sts;

	dbghwm(printk("zCgosFanGetCurrent called\n");)
	
	
	if(cdv->cin->type >= cdv->brd->hwmCount.fanCount)
	{
		return CGOS_ERROR;
	}
	else
	{
		wbuf[0] = CGBC_CMD_HWM_SENSOR;
		wbuf[1] = cdv->hwm->fansensors[cdv->cin->type].BCUnitNumber;
	
		bcCommand(&wbuf[0],2,&rbuf[0],5,&sts);
		SensorStatus = rbuf[1];

		if(((SensorStatus & 0x80) >> 7) == 1)	//Sensor Status active
		{
			//rbuf[2] holds the low byte of the sensor value,
			//rbuf[3] the high byte.
		        //negative values are stored in two's complement
			
                        //Check whether value is positive or negative
			if((rbuf[3] & 0x80) == 0x80)  //negative value
			{
				cdv->cout->rets[0]= 0xffff0000|(rbuf[3]<<8)|rbuf[2];
			}
			else //positive value
			{
				cdv->cout->rets[0] = ((rbuf[3]<<8)|rbuf[2]);	
			}
			cdv->cout->rets[1] = CGOS_SENSOR_ACTIVE;											
		}
		else //Sensor Status inactive
		{
			cdv->cout->rets[0] = 0;
			cdv->cout->rets[1] = GetErrorFlag(rbuf[2]);
		}
	}
	return CGOS_SUCCESS;
  }


unsigned int zCgosFanSetLimits(CGOS_DRV_VARS *cdv)
  {
	CGOSFANINFO fanInfo = {0};
	unsigned char wbuf[2];
	unsigned char rbuf[2];
	unsigned char sts;

	dbghwm(printk("zCgosFanSetLimits called\n");)

	OsaMemCpy(&fanInfo,(CGOSFANINFO*)cdv->pin,sizeof(CGOSFANINFO));
	if(fanInfo.dwType == CGOS_FAN_CPU)
	{	
		if(fanInfo.dwOutMax <= 100) //check if percentage
		{
			wbuf[0] = CGBC_CMD_CPU_FAN_CONTROL;
			wbuf[1] = CGBC_FAN_SET_PWM + fanInfo.dwOutMax;
			bcCommand(&wbuf[0],2,&rbuf[0],2,&sts);

			cdv->hwm->fansensors[cdv->cin->type].faninfo.dwOutMax = fanInfo.dwOutMax;
		}
		else
		{
			return CGOS_INVALID_PARAMETER;
		}
	}
	else
	{
		return CGOS_ERROR;
	}
	return CGOS_SUCCESS;
  }
  
/* **********************************************************************
 * 									*
 *			Voltage Functions				*
 * 									*
 ************************************************************************/  
/***********************************************************************
 * unsigned int initVoltage_BC(CGOS_DRV_VARS *cdv) 					    
 * 																		
 ***********************************************************************
 * Description: 				
 * 																		
 * Last Change: 05.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int initVoltage_BC(CGOS_DRV_VARS *cdv)
  {
	unsigned int retSuccess = CGOS_SUCCESS;
	unsigned int i;
	dbghwm("initVoltage_BC called\n");
	if(voltcnt <= CGOS_DRV_VOLT_MAX)			//CGOS_DRV_TEMP_MAX defined in DrvVars.h
	{
		cdv->brd->hwmCount.voltCount = voltcnt;
		for(i = 0; i < voltcnt; i++)
		{
			OsaMemCpy(&cdv->hwm->voltsensors[i],&VoltList[i],sizeof(CGOS_DRV_VOLT_ENTRY));  
		}
	} 
	else
	{
		retSuccess = CGOS_ERROR;
	}
	return retSuccess;
  }
/***********************************************************************
 * unsigned int zCgosVoltageCount(CGOS_DRV_VARS *cdv)				    
 * 																	
 ***********************************************************************
 * Cgos Function: CgosVoltageCount(HCGOS hCgos) 					   
 * 																	    
 * Inputs:															    
 *   -												    			    
 * 																	    
 * Outputs:															    
 *   cdv->cout->rets[0]												    
 * 																	
 ***********************************************************************
 * Description: Gets voltage sensor	count.								
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/  
unsigned int zCgosVoltageCount(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosVoltageCount called\n");)		
	cdv->cout->rets[0] = cdv->brd->hwmCount.voltCount;
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosVoltageGetInfo(CGOS_DRV_VARS *cdv)				    
 * 																		
 ***********************************************************************
 * Cgos Function: CgosVoltageGetInfo(HCGOS hCgos, 					    
 * 								 	 unsigned long dwUnit,			    
 * 								  	 CGOSVOLTAGEINFO *pInfo)		    
 * Inputs:															    
 *   dwUnit <->		cdv->cin->type					    			    
 * 																	    
 * Outputs:															    
 *   pInfo 	<-> 	cdv->pout										    
 * 																		
 ***********************************************************************
 * Description: Gets info struct of the requested voltage sensor		
 * 																		
 * Last Change: 06.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosVoltageGetInfo(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosVoltageGetInfo called\n");)	
	if(cdv->cin->type < cdv->brd->hwmCount.voltCount)
	{	
		OsaMemCpy(cdv->pout,&cdv->hwm->voltsensors[cdv->cin->type].voltinfo,sizeof(CGOSVOLTAGEINFO));	
		return CGOS_SUCCESS;
	}
	else
	{
		return CGOS_ERROR;
	}
  }

/***********************************************************************
 * unsigned int zCgosVoltageGetCurrent(CGOS_DRV_VARS *cdv)			    
 * 																	
 ***********************************************************************
 * Cgos Function: CgosVoltageGetCurrent(HCGOS hCgos, 			   		
 * 								 	 	unsigned long dwUnit,			
 * 								  	 	unsigned long *pdwSetting,		
 * 										unsigned long *pdwStatus)		
 * Inputs:															    
 *   dwUnit		 <->		cdv->cin->type			    			    
 * 																	    
 * Outputs:															    
 *   pdwSetting 	<-> 	cdv->cout->rets[0]						   
 * 	 pdwStatus		<->		cdv->cout->rets[1]							
 * 																		
 ***********************************************************************
 * Description: Gets status and value/error code of the					
 * 				requested voltage sensor								
 * 																		
 * Last Change: 07.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosVoltageGetCurrent(CGOS_DRV_VARS *cdv)					
  {	
	unsigned char wbuf[2];
	unsigned char rbuf[5];
	unsigned char SensorStatus = 0;
	unsigned char sts;

	dbghwm(printk("zCgosVoltageGetCurrent called\n");)
	
	if(cdv->cin->type >= cdv->brd->hwmCount.tempCount)
	{
		return CGOS_ERROR;
	}
	else
	{
		wbuf[0] = CGBC_CMD_HWM_SENSOR;
		wbuf[1] = cdv->hwm->voltsensors[cdv->cin->type].BCUnitNumber;
	
		bcCommand(&wbuf[0],2,&rbuf[0],5,&sts);
		SensorStatus = rbuf[1];
		
		if(((SensorStatus & 0x80) >> 7) == 1)	//Sensor Status active
		{
			//rbuf[2] holds the low byte of the sensor value,
			//rbuf[3] the high byte.
			//negative values are stored in two's complement
			
                        //Check whether value is positive or negative
			if((rbuf[3] & 0x80) == 0x80)  //negative value
			{
				cdv->cout->rets[0]= 0xffff0000|(rbuf[3]<<8)|rbuf[2];
			}
			else //positive value
			{
				cdv->cout->rets[0] = ((rbuf[3]<<8)|rbuf[2]);
			}	
			cdv->cout->rets[1] = CGOS_SENSOR_ACTIVE;											
		}
		else //Sensor Status inactive
		{
			cdv->cout->rets[0] = 0;
			cdv->cout->rets[1] = GetErrorFlag(rbuf[2]);
		}
	}
	return CGOS_SUCCESS;
  }

unsigned int zCgosVoltageSetLimits(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosVoltageSetLimits called\n");)	
	return CGOS_SUCCESS;
  }
  
/* **********************************************************************
 * 									*
 *			Performance Functions				*
 * 									*
 ************************************************************************/
 /***********************************************************************
 * unsigned int initPerformance_BC(CGOS_DRV_VARS *cdv) 				    
 * 																		
 ***********************************************************************
 * Description: Not Implemented											
 * 																		
 * Last Change: 05.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int initPerformance_BC(CGOS_DRV_VARS *cdv)
  {
	dbghwm("initPerformance_BC called\n"); 
	return CGOS_SUCCESS;
  }
/***********************************************************************
 * unsigned int zCgosPerformanceGetCurrent(CGOS_DRV_VARS *cdv) 		    
 * 																		
 ***********************************************************************
 * Description: Not Implemented											
 * 																		
 * Last Change: 05.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosPerformanceGetCurrent(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosPerformanceGetCurrent called\n");)
	return CGOS_SUCCESS;
  }
/***********************************************************************
 * unsigned int zCgosPerformanceSetCurrent(CGOS_DRV_VARS *cdv) 		    
 * 																		
 ***********************************************************************
 * Description: Not Implemented											
 * 																		
 * Last Change: 05.12.2017 HMI											
 * 																		
 * Modifications:													
 ***********************************************************************/
unsigned int zCgosPerformanceSetCurrent(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosPerformanceSetCurrent called\n");)
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosPerformanceGetPolicyCaps(CGOS_DRV_VARS *cdv) 	    
 * 																		
 ***********************************************************************
 * Description: Not Implemented											
 * 																		
 * Last Change: 05.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosPerformanceGetPolicyCaps(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosPerformanceGetPolicyCaps called\n");)	
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosPerformanceGetPolicy(CGOS_DRV_VARS *cdv) 		    
 * 																		
 ***********************************************************************
 * Description: Not Implemented											
 * 																		
 * Last Change: 05.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosPerformanceGetPolicy(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosPerformanceGetPolicy called\n");)	
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * unsigned int zCgosPerformanceSetPolicy(CGOS_DRV_VARS *cdv) 		    
 * 																		
 ***********************************************************************
 * Description: Not Implemented											
 * 																	
 * Last Change: 05.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
unsigned int zCgosPerformanceSetPolicy(CGOS_DRV_VARS *cdv)
  {
	dbghwm(printk("zCgosPerformanceSetPolicy called\n");)	
	return CGOS_SUCCESS;
  }

/***********************************************************************
 * void exitHWMModule(CGOS_DRV_VARS *cdv) 							    
 * 																		
 ***********************************************************************
 * Description: This function is called during driver close and should	
 * 				free allocated resources.								
 * 																		
 * Last Change: 12.12.2017 HMI											
 * 																		
 * Modifications:														
 ***********************************************************************/
void exitHWMModule(CGOS_DRV_VARS *cdv)
{
	dbghwm(printk("exitHWMModule called\n");)
}
