/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2022, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */ 
#ifndef _IOSUBMOD_BC_CFG_H_
#define _IOSUBMOD_BC_CFG_H_ 
 
#define IO_COUNT_BC 1

CGOS_DRV_IO_DIR_CAPS IO_CAPS_BC[IO_COUNT_BC] = {{ 	0x000000ff, //in
													0x00000ff 	//out	//MOD25
												}};	//CAPS for COMe Boards
CGOS_DRV_IO_DIR_CAPS IO_CAPS_BC_SA70[IO_COUNT_BC] = {{ 	0x00000fff, //in
													0x0000fff 	//out 	//MOD25
												}};	//CAPS for SA70												
CGOS_DRV_IO_DIR_CAPS IO_CAPS_BC_AL[IO_COUNT_BC] = { { 	0x00000fff, //in
													0x0000fff 	//out
												} };	//CAPS for GALP and GALS												
#endif
