/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2022, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * The full text of the license may also be found at:        
 * http://opensource.org/licenses/GPL-2.0
 *
 *---------------------------------------------------------------------------
 */

//***************************************************************************

#ifndef _CGOSDRV_H_
#define _CGOSDRV_H_

//***************************************************************************

#ifdef __linux__
#include "Lx/DrvOsHdr.h"  // OS specific header files	//MOD_3.1.2_3
#endif
#include "CgosDef.h"   // Standard definitions
#define NOCGOSAPI
//MOD_3.1.2_3 v
#include "../CgosLib/Cgos.h"      // CGOS Library API definitions and functions
#include "../CgosLib/CgosPriv.h"  // CGOS Library API private definitions and functions
#include "../CgosLib/CgosIoct.h"  // CGOS IO Control Driver Interface
//MOD_3.1.2_3 ^
#include "Cgeb.h"      // CGEB definitions			
//#include "CgebSda.h"   // CGEB Secure Data Area		//HMI
#include "DrvVars.h"   // Driver Variables
#include "DrvUla.h"    // Driver Upper Layer
#include "DrvOsa.h"    // CGOS OS Abstraction Layer
//#include "CgebFct.h"   // CGEB functions				//HMI

//***************************************************************************
//HMI v

#define CGOS_SUCCESS 0
#define CGOS_ERROR -1

#define CGOS_INVALID_PARAMETER -2
#define CGOS_NOT_IMPLEMENTED -3

#ifndef CGOS_INVALID_HANDLE
#define CGOS_INVALID_HANDLE ((void *)-1)
#endif

//HMI ^
//***************************************************************************

#endif
