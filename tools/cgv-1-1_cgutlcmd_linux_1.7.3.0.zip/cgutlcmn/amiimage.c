/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2005 congatec AG
 *
 * This file contains proprietary and confidential information.
 * All rights reserved.
 *
 * $Header:   S:/CG/archives/CGTOOLS/CGUTIL/CGUTLCMN/amiimage.c-arc   1.1   May 31 2012 15:44:56   gartner  $
 *
 * Contents: AMIBIOS CORE8 ROM image handler routines
 *
 *---------------------------------------------------------------------------
 *
 *                      R E V I S I O N   H I S T O R Y
 *
 * $Log:   S:/CG/archives/CGTOOLS/CGUTIL/CGUTLCMN/amiimage.c-arc  $
 * 
 *    Rev 1.1   May 31 2012 15:44:56   gartner
 * Updated variable definition to ease 64bit porting.
 * 
 *    Rev 1.0   Oct 30 2006 15:03:14   gartner
 * Initial revision.
 * 
 *
 *---------------------------------------------------------------------------
 */

/*---------------
 * Include files
 *---------------
 */
#include "cgutlcmn.h"
#include "cgbmod.h"
#include "amiimage.h"
#include <limits.h>


/*--------------
 * Externs used
 *--------------
 */



/*--------------------
 * Local definitions
 *--------------------
 */
#define BITBUFSIZ (CHAR_BIT * sizeof(UINT16))
#define DICBIT    13
#define DICSIZ (1U << DICBIT)
#define MAXMATCH 256    /* (not more than UCHAR_MAX + 1) */
#define THRESHOLD  3    /* choose optimal value */


#define NC (UCHAR_MAX + MAXMATCH + 2 - THRESHOLD)   /* alphabet = {0, 1, 2, ..., NC - 1} */
#define CBIT 9         /* $\lfloor \log_2 NC \rfloor + 1$ */
#define CODE_BIT  16   /* codeword length */

#define NP (DICBIT + 1)
#define NT (CODE_BIT + 3)
#define PBIT 4       /* smallest integer such that (1U << PBIT) > NP */
#define TBIT 5       /* smallest integer such that (1U << TBIT) > NT */
#if NT > NP
	#define NPT NT
#else
	#define NPT NP
#endif

#define SUCCESS  1
#define FAILURE  0


UINT32 rom_uncompress(unsigned char *, unsigned char *);
//static void error (char *msg);
static void decode (UINT16 count);
static void fillbuf (INT16 n);
static UINT16 getbits (INT16 n);
static void make_table (INT16 nchar, unsigned char bitlen[], INT16 tablebits, UINT16 table[]);
static void read_pt_len (INT16 nn, INT16 nbit, INT16 i_special);
static void read_c_len (void);
static UINT16 decode_c (void);
static UINT16 decode_p (void);


/*------------------
 * Global variables
 *------------------
 */

INT16   bytes_remain;
UINT16  bitbuf, blocksize, bufoff;
unsigned char buffer[DICSIZ];

UINT16 pt_table[256];
INT16   bytes_remain, bitcount;
UINT16  bitbuf, subbitbuf, bufsiz, blocksize, bufoff;
UINT32 compsize, origsize;
unsigned char *source_ptr, *destination_ptr;
unsigned char buffer[DICSIZ];

UINT16 left[2 * NC - 1], right[2 * NC - 1];
unsigned char *buf, c_len[NC], pt_len[NPT];
UINT16 c_freq[2 * NC - 1], c_table[4096], c_code[NC],
	   p_freq[2 * NP - 1], pt_table[256], pt_code[NPT],
	   t_freq[2 * NT - 1];

INT16 Error_Code = SUCCESS;


/*---------------------------------------------------------------------------
 * Name: CgExtractAMIBiosModule
 * Desc: Find specified AMI BIOS module, decompress it if required and save the
*        the module to the specified output file.       
 * Inp:  pucRomImage      - Pointer to AMI BIOS image
 *       pOutputFilename  - pointer to output file name to hold uncompressed module
 *       ucModuleID       - AMI ID of BIOS module to be extracted
 *       ulRomImageLength - length of AMI BIOS image in bytes
 *
 * Outp: return code:
 *       CG_RET_OK          - Success, module saved
 *       CG_RET_FAILED      - Module could not be extracted
 *---------------------------------------------------------------------------
 */
UINT16 CgExtractAMIBiosModule
(
    unsigned char *pucRomImage, 
    UINT32 ulRomImageLength,
    unsigned char ucModuleID,
    _TCHAR *pOutputFilename
)
{
    unsigned char *pucScanEnd, *pucCurImgPtr, *pucUncompModBuffer;
    UINT32  ulROMModSize, ulUncompModSize, ulStepSize = 1;
    unsigned char ucImgSize, ucHdrFound = FALSE;
    FILE *fpOutDatafile = NULL;

    // Find AMI BIOS header
    pucCurImgPtr = pucRomImage;
    ulStepSize = 1;
    pucScanEnd = pucRomImage + ulRomImageLength - ulStepSize - sizeof(AMI_BIOSHDR_COMP);

    // Scan for AMI BIOS header signature
	for (pucCurImgPtr=pucRomImage; pucCurImgPtr < pucScanEnd; pucCurImgPtr = pucCurImgPtr + ulStepSize)
    {
		// Check if the AMI BIOS header signature is found
		if (memcmp (pucCurImgPtr, AMI_BIOSHDR_SIGNATURE, strlen(AMI_BIOSHDR_SIGNATURE)) == 0)
        {
            ucHdrFound = TRUE;
            break;
        }
    }

    if(ucHdrFound == FALSE)
    {
        // BIOS header not found !
        return CG_RET_FAILED;
    }

    // Get and store BIOS image size
    // At offset -4 relative to the AMIBIOS header signature we find the ROM image
    // attribute byte. If bit 0 of this byte is 0 we have a ROM image of <=1MB else
    // the ROM image size is >1MB. This is important as the ROM image size defines 
    // the interpretation of the next module pointer address as segment:offset (<=1MB) or
    // linear (>1MB).
    if( ((*(pucCurImgPtr - 4)) & 0x01) == 0x00 )
    {
        ucImgSize   = AMI_IMGSIZE_1MBORLESS;
    }
    else
    {
        ucImgSize   = AMI_IMGSIZE_ABOVE1MB;
    }

    // Set up pointer to first module
    if(ucImgSize  == AMI_IMGSIZE_1MBORLESS)
    {
        // Address calculation based on SEG:OFF for images <=1MB
        pucCurImgPtr = pucRomImage + ((((PAMI_BIOSHDR_COMP)pucCurImgPtr)->tuModAddr.tsSegOff.usSeg)<<4) + 
                       (((PAMI_BIOSHDR_COMP)pucCurImgPtr)->tuModAddr.tsSegOff.usOff); 
    }
    else
    {
        // Linear offset address for images >1MB
        pucCurImgPtr = pucRomImage + (((PAMI_BIOSHDR_COMP)pucCurImgPtr)->tuModAddr.ul32BitOff);                       
    }
    // Now scan all the modules to find the one we want
    do
    {
        // Check whether this is our module
        if( ((PAMI_MODHDR_COMP)pucCurImgPtr)->ucModuleID == ucModuleID)   
        {
            break;
        }

        // Check whether we have found the last module
        if( ((PAMI_BIOSHDR_COMP)pucCurImgPtr)->tuModAddr.ul32BitOff == 0xFFFFFFFF)   
        {
            return CG_RET_FAILED;
        }
        else
        {
            // Set up pointer to next module
            if(ucImgSize  == AMI_IMGSIZE_1MBORLESS)
            {
                // Address calculation based on SEG:OFF for images <=1MB
                pucCurImgPtr = pucRomImage + ((((PAMI_MODHDR_COMP)pucCurImgPtr)->tuModAddr.tsSegOff.usSeg)<<4) + 
                            (((PAMI_MODHDR_COMP)pucCurImgPtr)->tuModAddr.tsSegOff.usOff); 
            }
            else
            {
                // Linear offset address for images >1MB
                pucCurImgPtr = pucRomImage + (((PAMI_MODHDR_COMP)pucCurImgPtr)->tuModAddr.ul32BitOff);
                               
            }
        }
    }while(1);

    // Get the size of the module in ROM (i.e. compressed size if mod. is compressed)
    ulROMModSize = ((PAMI_MODHDR_EXT)(pucCurImgPtr - sizeof(AMI_MODHDR_EXT)))->ulSize; 

    // Check whether the module is compressed
    if(((PAMI_MODHDR_COMP)(pucCurImgPtr))->ucAttr & 0x80)
    {
        // Module is not compressed, so save it to destination file now
        // Point to data block of the module
        pucCurImgPtr = pucCurImgPtr + sizeof(AMI_MODHDR_COMP);      
        pucUncompModBuffer = pucCurImgPtr;
        ulUncompModSize = ulROMModSize;
    }
    else
    {
        // Now get the uncompressed size and allocate a temporary buffer large
        // enough to hold the uncompressed module.
        
        // Point to data block of the module
        pucCurImgPtr = pucCurImgPtr + sizeof(AMI_MODHDR_COMP);      
        ulUncompModSize = *((UINT32*)(pucCurImgPtr + 4));
        if((pucUncompModBuffer = (unsigned char*) malloc(ulUncompModSize)) == NULL)
        {
            return CG_RET_FAILED;
        }

        // Uncompress our module
        ulUncompModSize = rom_uncompress(pucUncompModBuffer, pucCurImgPtr);
    }
    // Save the uncompressed module to a file
    if(!(fpOutDatafile = fopen(pOutputFilename, "wb")))
    {
        return CG_RET_FAILED;
    }
    if(fwrite(pucUncompModBuffer, ulUncompModSize, 1, fpOutDatafile) != 1)
    {
        return CG_RET_FAILED;
    }
    fclose(fpOutDatafile);

    // Free temporary module buffer
    if(pucUncompModBuffer != NULL)
    {
        free(pucUncompModBuffer);
    }

    return CG_RET_OK;
}





/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
UINT32 rom_uncompress(unsigned char *Destination, unsigned char *Source)
//void main (int argc, char *argv[])
{
	UINT16 n, i;

	bytes_remain = 0;
	bitcount = 0;
	bitbuf = 0;
	subbitbuf = 0;
	bufsiz = 0;
	blocksize = 0;
	bufoff = 0;
	source_ptr = Source;
	destination_ptr = Destination;
	
	memcpy(&compsize, source_ptr,sizeof(compsize));
	memcpy(&origsize, source_ptr+4,sizeof(origsize));

	compsize -= 8;		
	source_ptr += 8;

	fillbuf (BITBUFSIZ);

	while (origsize != 0)
		{
			n = (UINT16)((origsize > (INT32)DICSIZ) ? (INT32)DICSIZ : origsize);
			decode (n);

			for (i=0; i<n; i++)
				*Destination++ = *(buffer+i);
			origsize -= n;
		}

	return((UINT32)(Destination - destination_ptr));
}

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
static void decode (UINT16 count)
{
	UINT16 r, c;

	r = 0;
	while (--bytes_remain >= 0)
		{
			buffer[r] = buffer[bufoff];
			bufoff = (UINT16)((bufoff + 1) & (DICSIZ - 1));
			if (++r == count)
				return;
		}

	for (;;)
		{
			c = decode_c ();
			if (c <= UCHAR_MAX)
				{
					buffer[r] = (unsigned char)c;
					if (++r == count)
						return;
				}
			else
				{
					bytes_remain = c - (UCHAR_MAX + 1 - THRESHOLD);
					bufoff = (UINT16)((r - decode_p() - 1) & (DICSIZ - 1));
					while (--bytes_remain >= 0)
						{
							buffer[r] = buffer[bufoff];
							bufoff = (UINT16)((bufoff + 1) & (DICSIZ - 1));
							if (++r == count)
								return;
						}
				}
		}
}

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
static void fillbuf (INT16 n)  /* Shift bitbuf n bits left, read n bits */
{
	bitbuf <<= n;
	while (n > bitcount)
		{
			bitbuf |= subbitbuf << (n -= bitcount);
			if (compsize != 0)
				{
					compsize--;
					subbitbuf = (unsigned char)*source_ptr++;
				}
			else subbitbuf = 0;
			bitcount = CHAR_BIT;
		}
	bitbuf |= subbitbuf >> (bitcount -= n);
}

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
static UINT16 getbits (INT16 n)
{
	UINT16 x;

	x = bitbuf >> (BITBUFSIZ - n);
	fillbuf (n);
	return (x);
}

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
static void make_table (INT16 nchar, unsigned char bitlen[], INT16 tablebits, UINT16 table[])
{
	UINT16 count[17], weight[17], start[18], *p;
	UINT16 i, k, len, ch, jutbits, avail, nextcode, mask;

	for (i=1; i<=16; i++)
		count[i] = 0;
	for (i=0; i<(UINT16)nchar; i++)
		count[bitlen[i]]++;

	start[1] = 0;
	for (i = 1; i <= 16; i++)
		start[i + 1] = start[i] + (count[i] << (16 - i));
	if (start[17] != (UINT16)(1U << 16))
		Error_Code = FAILURE;

	jutbits = 16 - tablebits;
	for (i=1; i<=(UINT16)tablebits; i++)
		{
			start[i] >>= jutbits;
			weight[i] = 1U << (tablebits - i);
		}
	while (i <= 16)
		{
			weight[i] = 1U << (16 - i);
			i+=1;
		}
	i = start[tablebits + 1] >> jutbits;
	if (i != (UINT16)(1U << 16))
		{
			k = 1U << tablebits;
			while (i != k)
				table[i++] = 0;
		}

	avail = nchar;
	mask = 1U << (15 - tablebits);
	for (ch=0; ch<(UINT16)nchar; ch++)
		{
			if ((len = bitlen[ch]) == 0)
				continue;
			nextcode = start[len] + weight[len];
			if (len <= (UINT16)tablebits)
				for (i=start[len]; i<nextcode; i++)
					table[i] = ch;
			else
				{
					k = start[len];
					p = &table[k >> jutbits];
					i = len - tablebits;
					while (i != 0)
						{
							if (*p == 0)
								{
									right[avail] = left[avail] = 0;
									*p = avail++;
								}
							if (k & mask)
								p = &right[*p];
							else p = &left[*p];
							k <<= 1;
							i--;
						}
					*p = ch;
				}
			start[len] = nextcode;
		}
}

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
static void read_pt_len (INT16 nn, INT16 nbit, INT16 i_special)
{
	INT16 i, c, n;
	UINT16 mask;

	n = getbits (nbit);
	if (n == 0)
		{
			c = getbits (nbit);
			for (i=0; i<nn; i++)
				pt_len[i] = 0;
			for (i=0; i<256; i++)
				pt_table[i] = c;
		}
	else
		{
			i = 0;
			while (i < n)
				{
					c = bitbuf >> (BITBUFSIZ - 3);
					if (c == 7)
						{
							mask = 1U << (BITBUFSIZ - 1 - 3);
							while (mask & bitbuf)
								{
									mask >>= 1;
									c++;
								}
						}
//					fillbuf ((c < 7) ? 3 : c - 3);
					{
						INT16 t;
						t = (c < 7) ? 3 : c - 3;
						fillbuf (t);
					}
					pt_len[i++] = (unsigned char)c;
					if (i == i_special)
						{
							c = getbits(2);
							while (--c >= 0)
								pt_len[i++] = 0;
						}
				}
			while (i < nn)
				pt_len[i++] = 0;
			make_table (nn, pt_len, 8, pt_table);
		}
}

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
static void read_c_len (void)
{
	INT16 i, c, n;
	UINT16 mask;

	n = getbits (CBIT);
	if (n == 0)
		{
			c = getbits (CBIT);
			for (i = 0; i < NC; i++)
				c_len[i] = 0;
			for (i = 0; i < 4096; i++)
				c_table[i] = c;
		}
	else
		{
			i = 0;
			while (i < n)
				{
					c = pt_table[bitbuf >> (BITBUFSIZ - 8)];
					if (c >= NT)
						{
							mask = 1U << (BITBUFSIZ - 1 - 8);
							do
								{
									if (bitbuf & mask)
										c = right[c];
									else c = left [c];
									mask >>= 1;
								}
							while (c >= NT);
						}
					fillbuf (pt_len[c]);
					if (c <= 2)
						{
							if      (c == 0) c = 1;
							else if (c == 1) c = getbits(4) + 3;
							else             c = getbits(CBIT) + 20;
							while (--c >= 0) c_len[i++] = 0;
						}
					else c_len[i++] = (unsigned char)(c - 2);
				}
			while (i < NC)
				c_len[i++] = 0;
			make_table (NC, c_len, 12, c_table);
		}
}

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
static UINT16 decode_c (void)
{
	UINT16 j, mask;

	if (blocksize == 0)
		{
			blocksize = getbits (16);
			read_pt_len (NT, TBIT, 3);
			read_c_len ();
			read_pt_len (NP, PBIT, -1);
		}
	blocksize--;
	j = c_table[bitbuf >> (BITBUFSIZ - 12)];
	if (j >= NC)
		{
			mask = 1U << (BITBUFSIZ - 1 - 12);
			do
				{
					if (bitbuf & mask)
						j = right[j];
					else j = left [j];
					mask >>= 1;
				}
			while (j >= NC);
		}
	fillbuf (c_len[j]);
	return (j);
}

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:         
 * Outp: 
 *---------------------------------------------------------------------------
 */
static UINT16 decode_p (void)
{
	UINT16 j, mask;

	j = pt_table[bitbuf >> (BITBUFSIZ - 8)];
	if (j >= NP)
		{
			mask = 1U << (BITBUFSIZ - 1 - 8);
			do
				{
					if (bitbuf & mask)
						j = right[j];
					else j = left [j];
					mask >>= 1;
				}
			while (j >= NP);
		}
	fillbuf (pt_len[j]);
//	if (j != 0)
//		j = (1U << (j - 1)) + getbits(j - 1);
	if (j != 0)
	{
		INT16 t;
		t = j - 1;
		j = (1U << (j - 1)) + getbits(t);
	}
	return (j);
}

