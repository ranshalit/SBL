/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2005 congatec AG
 *
 * This file contains proprietary and confidential information.
 * All rights reserved.
 *
 * $Header:   S:/CG/archives/CGTOOLS/CGUTIL/CGUTLCMN/amiimage.h-arc   1.1   May 31 2012 15:45:02   gartner  $
 *
 * Contents: AMI BIOS image definitions
 *
 *---------------------------------------------------------------------------
 *
 *                      R E V I S I O N   H I S T O R Y
 *
 * $Log:   S:/CG/archives/CGTOOLS/CGUTIL/CGUTLCMN/amiimage.h-arc  $
 * 
 *    Rev 1.1   May 31 2012 15:45:02   gartner
 * Updated variable definition to ease 64bit porting.
 * 
 *    Rev 1.0   Oct 30 2006 15:03:14   gartner
 * Initial revision.
 * 
 *
 *---------------------------------------------------------------------------
 */

#ifndef _INC_AMIIMAGE

#pragma pack (1)

//+---------------------------------------------------------------------------
//
// AMI BIOS image definitions
//

// BIOS header signature
#define AMI_BIOSHDR_SIGNATURE   "AMIBIOSC"


// AMI BIOS module IDs
#define AMI_TYPE_MAINBIOS   0x1B
#define AMI_TYPE_LANGUAGE   0x21

// AMI image size definitions
#define AMI_IMGSIZE_1MBORLESS   0x00
#define AMI_IMGSIZE_ABOVE1MB    0x01


//+---------------------------------------------------------------------------
//
// AMI BIOS header (compatible part)
//
typedef struct AMI_BIOSHDR_COMP_STRUCT
{        
    unsigned char   ucSignature[8];	        // AMIBIOS signature 'AMIBIOSC'
	unsigned char	ucCoreBiosVersion[4];   // AMIBIOS core version 	
	UINT16	usLength;               // length of BIOS image in QWORDs 
	UINT32	ulChecksum;	            // BIOS checksum
	union 
    {
		// Applies for ROM images > 1MB
		UINT32	ul32BitOff;         // 32 bit offset of first module
		// Applies for ROM image <= 1MB
        struct
		{			
			UINT16	usOff;	        // Offset of first module
			UINT16	usSeg;	        // Segment of first module
		} tsSegOff;
	} tuModAddr;
} AMI_BIOSHDR_COMP, *PAMI_BIOSHDR_COMP;


//+---------------------------------------------------------------------------
//
// AMI module header (compatible part) 
//
typedef struct AMI_MODHDR_COMP_STRUCT
{
	union 
    {
		// Applies for ROM images > 1MB
		UINT32   ul32BitOff;         // 32 bit offset of next module
		struct
		{			
			UINT16  usOff;          // Offset of next module
			UINT16  usSeg;          // Segment of next module
		} tsSegOff;
	} tuModAddr;
	UINT16  usSize;                 // Module size in bytes (only if module < 64kByte)
	unsigned char	ucModuleID;             // Module ID	
	unsigned char	ucAttr;                 // Module attributes	
	UINT16	ucOffVenID;             // Dest. offset where mod. will be uncompressed/PCI vendor ID	
	UINT16	ucSegDevID;	            // Dest. segment where mod. will be uncompressed/PCI device ID	
} AMI_MODHDR_COMP, *PAMI_MODHDR_COMP;


//+---------------------------------------------------------------------------
//
// AMI module header (extended part) 
//
typedef struct AMI_MODHDR_EXT_STRUCT
{
	UINT32   ulSize;                 // Offset -8: Module size in bytes (also for module > 64kByte)	
	UINT32	ulChecksum;	            // Offset -4: Module checksum
} AMI_MODHDR_EXT, *PAMI_MODHDR_EXT;



//+---------------------------------------------------------------------------
//      Interface functions
//+---------------------------------------------------------------------------
UINT16 CgExtractAMIBiosModule
(
    unsigned char *pucRomImage, 
    UINT32 ulRomImageLength,
    unsigned char ucModuleID,
    _TCHAR *pOutputFilename
);

#pragma pack()

#define _INC_AMIIMAGE
#endif 

