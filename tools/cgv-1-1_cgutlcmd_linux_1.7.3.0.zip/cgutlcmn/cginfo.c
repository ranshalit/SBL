/*---------------------------------------------------------------------------
 *
 * Copyright (c) 2024, congatec GmbH. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the BSD 2-clause license which 
 * accompanies this distribution. 
 *
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the BSD 2-clause license for more details.
 *
 * The full text of the license may be found at:        
 * http://opensource.org/licenses/BSD-2-Clause   
 *
 *---------------------------------------------------------------------------
 */

/*---------------------------------------------------------------------------
 *
 * Contents: Congatec board/BIOS information module.
 *
 *---------------------------------------------------------------------------
 *
 *                      R E V I S I O N   H I S T O R Y
 *
 * MOD005: Use CgosBoardGetInfo() instead of CgosBoardGetBiosInfo()
 *
 * MOD004: Add feature to read OEM BIOS version, without MPFA
 *
 * MOD003: Added support for MEC1723 based cBC. 
 *
 * MOD002: Add feature to read BIOS version, without MPFA
 *
 * MOD001: Added support for MEC1706 based cBC.
 * 
 *    Rev 1.2   Sep 06 2016 15:52:02   congatec
 * Added BSD header.
 * 
 *    Rev 1.1   May 31 2012 15:45:36   gartner
 * Updated variable definition to ease 64bit porting.
 * 
 *    Rev 1.0   Oct 30 2006 15:04:52   gartner
 * Initial revision.
 * 
 * 
 *
 *---------------------------------------------------------------------------
 */

/*---------------
 * Include files
 *---------------
 */
#include "cgutlcmn.h"
#include "cginfo.h"
#include "cgbmod.h"
#include "cgbc.h"

/*--------------
 * Externs used
 *--------------
 */

/*--------------------
 * Local definitions
 *--------------------
 */


/*-------------------------
 * Module global variables
 *-------------------------
 */

/*---------------------------------------------------------------------------
 * Name: 
 * Desc: 
 * Inp:  
 *       
 * Outp: 
 *---------------------------------------------------------------------------
 */
UINT16 CgInfoGetInfo
(
    CG_INFO_STRUCT *pCgInfoStruct,
    UINT32 flags
 )
{
    UINT16 retVal;
    unsigned char CgbcCmdWriteBuf[32] = {0};
    unsigned char CgbcCmdReadBuf[32] = {0};
    UINT32 CgbcCmdStatus = 0;
    unsigned char CgbcType = 0;          // MOD001
    //CGEBDIRECTINFO CgDirectInfo;         // MOD002 //HMI
    unsigned char MpfaAvailable = FALSE; // MOD002
    unsigned int i = 0;                  // MOD002
    OEMBIOSVERSION CgOemBiosVersion;     // MOD004
    //HMI v
    //CGOSBOARDINFO *boardinfo = 0;        // MOD005
	CGOSBOARDINFO boardinfo;			
	//HMI ^
    // MOD002 v

    // Prepare for infomration gathering
    if ((retVal = CgMpfaStart(FALSE)) != CG_MPFARET_OK) // if MPFA is not available
    {
        // return CG_RET_FAILED; //KARIN do not abort when MPFA area is not found
    }
    else // MPFA is available
    {
        MpfaAvailable = TRUE;
    }

    // Gather required information

    // Get system and OEM BIOS versions
    if(flags & CG_FLAG_INFO_BIOS)
    {
        if (MpfaAvailable == TRUE) // if we have MPFA access, get information from there
        {
            CgMpfaGetSysBiosVersion((_TCHAR *)(&(pCgInfoStruct->BaseBiosVersion)), NULL);
            CgMpfaGetOEMBiosVersion((_TCHAR *)(&(pCgInfoStruct->OEMBiosVersion)));
        }
        else // otherwise, try to get BIOS version from info structure.
        {
			
            //CgDirectInfo.cgdirInfoSize = sizeof(CgDirectInfo); // MOD005
            //HMI v
            boardinfo.dwSize = sizeof(CGOSBOARDINFO);
            //if (CgosBoardGetInfo(hCgos, boardinfo))              // MOD005
            if (CgosBoardGetInfo(hCgos, &boardinfo))              
            {
			
            	pCgInfoStruct->BaseBiosVersion[0] = boardinfo.szBoard[0];
            	pCgInfoStruct->BaseBiosVersion[1] = boardinfo.szBoard[1];
            	pCgInfoStruct->BaseBiosVersion[2] = boardinfo.szBoard[2];
            	pCgInfoStruct->BaseBiosVersion[3] = boardinfo.szBoard[3];
            	pCgInfoStruct->BaseBiosVersion[4] = 'R';
            	pCgInfoStruct->BaseBiosVersion[5] = ((boardinfo.wSystemBiosRevision >> 8 ) & 0x0F) + '0';
            	pCgInfoStruct->BaseBiosVersion[6] = ((boardinfo.wSystemBiosRevision >> 4 ) & 0x0F) + '0';
            	pCgInfoStruct->BaseBiosVersion[7] = (boardinfo.wSystemBiosRevision & 0x0F) + '0';
            	pCgInfoStruct->BaseBiosVersion[8] = '\0';
                /*for (i = 0; i < 8; i++)
                {
                    pCgInfoStruct->BaseBiosVersion[i] = CgDirectInfo.cgdirBiosRevision[i];
                }
                pCgInfoStruct->BaseBiosVersion[8] = '\0';*/
            //HMI ^
            }
            else // if getting the BIOS version from the Info struct also fails we have no information -> zero-terminate the strings
            {
                pCgInfoStruct->BaseBiosVersion[0] = '\0';
            }
            
                         //MOD004 v
            CgOemBiosVersion.oemBiosVersionSize = sizeof(CgOemBiosVersion);
            

            if (CgosBoardGetOemBios(hCgos, &CgOemBiosVersion))
            {
                for (i = 0; i < OEM_BIOS_VERSION_MAX_LENGTH; i++)
                {
                    pCgInfoStruct->OEMBiosVersion[i] = CgOemBiosVersion.oemBiosVersion[i];
                }
                pCgInfoStruct->OEMBiosVersion[OEM_BIOS_VERSION_MAX_LENGTH] = '\0';
            }
            else // if getting the OEM BIOS version from the Info struct also fails we have no information -> zero-terminate the strings
            {
                pCgInfoStruct->OEMBiosVersion[0] = '\0';
            }
            //MOD004 ^
        }
    }

    // MOD002 ^

    // More information only available on board level
    if(g_nOperationTarget == OT_BOARD)
    {
        // Get CGOS version information
        if(flags & CG_FLAG_INFO_CGOS)
        {
            pCgInfoStruct->CgosAPIVersion = CgosLibGetVersion();
            pCgInfoStruct->CgosDrvVersion = CgosLibGetDrvVersion();
        }
        if(flags & CG_FLAG_INFO_CGBC)
        {
            CgbcCmdWriteBuf[0] = CGBC_CMD_INFO_1;
                                                                     //MOD001 v 
            if(CgosCgbcHandleCommand(hCgos, &CgbcCmdWriteBuf[0], 1, &CgbcCmdReadBuf[0], 14, &CgbcCmdStatus))
            {
                CgbcType = CgbcCmdReadBuf[0]; // Byte 0 of CGBC_CMD_INFO_1 contains the Board Controller Type
                                              // This is needed for generating the version String. All CGBCs lower
                                              // than Gen5 had a version name starting with CGBCP, the version names for
                                              // the BC Gen5 start with GEN5P and for cBC6 with cBC6P.
                CgbcCmdWriteBuf[0] = CGBC_CMD_GET_FW_REV;
                                                                     //MOD001 ^
                if(CgosCgbcHandleCommand(hCgos, &CgbcCmdWriteBuf[0], 1, &CgbcCmdReadBuf[0], 3, &CgbcCmdStatus))
                {
#ifndef BANDR
                                                                     //MOD001 v 
                    if(CgbcType == CGBC_MEC170x)
                    {
                        sprintf((char*)(&(pCgInfoStruct->FirmwareVersion)),"GEN5P%c%c%c",CgbcCmdReadBuf[0], CgbcCmdReadBuf[1],CgbcCmdReadBuf[2]);
                    }
                                                                     //MOD003 v
                    else if(CgbcType == CGBC_MEC172x)
                    {
                        sprintf((char*)(&(pCgInfoStruct->FirmwareVersion)),"cBC6P%c%c%c",CgbcCmdReadBuf[0], CgbcCmdReadBuf[1],CgbcCmdReadBuf[2]);
                    }
                                                                     //MOD003 ^
                    else
                    {
                        sprintf((char*)(&(pCgInfoStruct->FirmwareVersion)),"CGBCP%c%c%c",CgbcCmdReadBuf[0], CgbcCmdReadBuf[1],CgbcCmdReadBuf[2]);
                    }
                                                                     //MOD001 ^
#else
                    sprintf((char*)(&(pCgInfoStruct->FirmwareVersion)),"v%c%c%c",CgbcCmdReadBuf[0], CgbcCmdReadBuf[1],CgbcCmdReadBuf[2]);
#endif
                }
            }
                                                                     //MOD001 ^
        }
        if(flags & CG_FLAG_INFO_MANU)
        {
            pCgInfoStruct->CgosBoardInfo.dwSize = sizeof(pCgInfoStruct->CgosBoardInfo);
            CgosBoardGetInfo(hCgos, &(pCgInfoStruct->CgosBoardInfo));
        }
        if(flags & CG_FLAG_INFO_BCNT)
        {
            CgosBoardGetBootCounter(hCgos, &(pCgInfoStruct->BootCount));
        }
        if(flags & CG_FLAG_INFO_RTIM)
        {
            CgosBoardGetRunningTimeMeter(hCgos, &(pCgInfoStruct->RunningTime));
        }
        // Also store state of the BIOS update protection
        pCgInfoStruct->BupState = CgMpfaCheckBUPActive();
    }

    // Perform cleanup
    if ((retVal = CgMpfaEnd()) != CG_MPFARET_OK)
    {
        return CG_RET_FAILED;
    }
    return CG_RET_OK;

}

