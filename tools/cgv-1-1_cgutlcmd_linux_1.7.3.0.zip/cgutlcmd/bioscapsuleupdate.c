/*---------------
 * Include files
 *---------------
 */
#include "cgutlcmn.h"
#include "cgbmod.h"
#include "biosflsh.h"
#include "cgos.h"
#include "cginfo.h"
#include <errno.h>

#ifdef LINUX
#include <dirent.h>
#endif
/*--------------
 * Externs used
 *--------------
 */

/*--------------------
 * Local definitions
 *--------------------
 */

/*------------------
 * Global variables
 *------------------
 */

/*---------------------------------------------------------------------------
 * Name:
 * Desc:
 * Inp:
 * Outp:
 *---------------------------------------------------------------------------
 */

static void ShowUsage(void)
{
    PRINTF(_T("\nUsage:\n\n"));
    PRINTF(_T("BIOSCU   [commands]  [options]\n\n"));
    PRINTF(_T("commands:\n"));
    PRINTF(_T("/TO              - Trigger only the secure BIOS capsule update.\n"));
    PRINTF(_T("BIOSUPDT.cap     - Check the BIOS capsule file for validity and trigger secure BIOS capsule update.\n\n"));
    PRINTF(_T("options:\n"));
    PRINTF(_T("/R               - Automatically restart the board after the command is entered.\n"));
    PRINTF(_T("/D               - Defer BIOS update. Allows switching to the external flash part.\n"));
    PRINTF(_T("/P               - Preserve BIOS password.\n"));
    PRINTF(_T("/F               - Force update even if BIOS project IDs do not match.\n"));
    PRINTF(_T("/LAN             - Restore LAN area(s).\n"));
    PRINTF(_T("/Q               - Quiet mode. Do not display any messages during the BIOS update.\n"));
    PRINTF(_T("/CP /dir/        - Copy the BIOSUPDT.cap into the desired directory /dir/.\n"));
    PRINTF(_T("                   Wait until the board is restarted after the BIOS update!\n"));
    PRINTF(_T("\n"));																					

    exit(1);
}

CGEBDIRECTINFO CgDirectInfo;
CG_INFO_STRUCT *pCgInfoStruct;

/*---------------------------------------------------------------------------
 * Name:
 * Desc:
 * Inp:
 * Outp:
 *---------------------------------------------------------------------------
 */

#ifdef WIN32
// WINDOWS v
BOOL DirectoryExists(LPCTSTR szPath)
{
  DWORD dwAttrib = GetFileAttributes(szPath);

  return (dwAttrib != INVALID_FILE_ATTRIBUTES &&
          (dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
}

// WINDOWS ^
#endif
void HandleBiosCapsuleUpdate(INT32 argc, _TCHAR *argv[])
{
  _TCHAR szNewBiosFile[256];
  FILE *fpNewBiosFile = NULL;
  FILE *copiedFile; // GMA
  char cTemp;
  UINT32 BiosCuParamFlags = 0;
  UINT32 nFlags = 0;
  UINT16 i = 0;                         // GMA
  _TCHAR *fcPath;                       // GMA
  unsigned int numbytes;                // GMA
  char *buffer = 0;                     // GMA
  char szFileBiosName[9] = {0x00};      // GMA

#ifdef LINUX
  DIR *fcDir; // GMA //LINUX
#endif

  g_nOperationTarget = OT_BOARD;

  // By default the flag CG_BFFLAG_AUTO_OFFON should be set
  // for DOS(X) and UEFI versions only.
#ifndef DOSX
#ifdef WIN32
  nFlags = nFlags & (~CG_BFFLAG_AUTO_OFFON);
#endif
#endif

#ifdef LINUX
  nFlags = nFlags & (~CG_BFFLAG_AUTO_OFFON);
#endif

  PRINTF(_T("BIOS Secure Capsule Update Module\n"));
  if (argc < 2)
  {
    ShowUsage();
  }

  // Variables for comparing only the last 12 characters of the directory, where the BIOSUPDT.cap is located. 
  //It should only check for "BIOSUPDT.cap"
  const char* compareString = "BIOSUPDT.cap";
  size_t compareLength = 12;
  size_t argLength = strlen(argv[1]);
  const char* argSubstring = argv[1] + (argLength - compareLength);

  if (STRNCMP(argv[1], "/TO", 3) == 0)
  {
      //nFlags = nFlags | CGUTL_BIOSCU_FLAG_TO;
  }
  else  if (STRNCMP(argSubstring, compareString, compareLength) == 0)
  {
        if (SSCANF(argv[1], "%s%c", &szNewBiosFile[0], &cTemp) == 1)
        {
            nFlags = nFlags | CGUTL_BIOSCU_FLAG_FILE;
            // Check ROM file
            fpNewBiosFile = fopen((const char*)&szNewBiosFile, "rb"); // open bios file
            if (!fpNewBiosFile)
            {
                printf("ERROR: Could not open BIOS capsule update file\n");
                exit(1);
            }
            // check if the bios capsule is a valid congatec BIOS
            // Get BIOS info from ROM file
            if ((CgBfGetBiosInfoRomfile(fpNewBiosFile, &szFileBiosName[0])) != CG_BFRET_OK)
            {
                // Don't flash if we cannot get info from ROM file
                PRINTF("ERROR: File is not a valid congatec BIOS capsule update file!\n");
                fclose(fpNewBiosFile);
                exit(1);
            }
            else
            {
                printf("\n%s is a valid BIOS capsule file\n",argv[1]);
            }

        }
  }
  else
  {
      printf("ERROR: You have to enter either /TO or a valid BIOSUPDT.cap file as first parameter\n");
      exit(1);
  }

//scan the parameters
  for (i = 2; i < argc; i++)
  {
      if (STRNCMP(argv[i], "/R", 2) == 0) {
          //Automatic  restart
          BiosCuParamFlags |= CGOS_BIOSCU_AUTO_RESTART_BIT;
      }
      else if (STRNCMP(argv[i], "/D", 2) == 0) {
          //Defer BIOS update. Allows to switch to external flash part.
          BiosCuParamFlags |= CGOS_BIOSCU_DEFER_BIT;
      }
      else if (STRNCMP(argv[i], "/P", 2) == 0) {
          //Preserve BIOS password
          BiosCuParamFlags |= CGOS_BIOSCU_PRES_PW_BIT;
      }
      else if (STRNCMP(argv[i], "/F", 2) == 0) {
          //Force update although BIOS project IDs do not match.
          BiosCuParamFlags |= CGOS_BIOSCU_FORCE_BIOS_ID_BIT;
      }
      else if (STRNCMP(argv[i], "/LAN", 4) == 0) {
          //Restore LAN area(s).
          BiosCuParamFlags |= CGOS_BIOSCU_LAN_AREA_BIT;
      }
      else if (STRNCMP(argv[i], "/BF", 3) == 0) {
          //Force just BIOS part update (hidden command without help text)
          BiosCuParamFlags |= CGOS_BIOSCU_JUST_BIOS_BIT;
      }
      else if (STRNCMP(argv[i], "/Q", 2) == 0) {
          //Quiet mode. Ongoing BIOS update progress not displayed.
          BiosCuParamFlags |= CGOS_BIOSCU_QUIET_BIT;
      }
      else if (nFlags == CGUTL_BIOSCU_FLAG_FILE)
      {
          if (STRNCMP(argv[i], "/CP", 3) == 0)
          {
              if (!argv[i + 1]) // || STRNCMP(argv[i + 1], "/AB", 3) == 0) // check if there is argument after /FC and if /AB is next
              {
                  PRINTF("Please enter a valid directory\n");
                  exit(1);
              }
              else
              {
                  nFlags = nFlags | CGUTL_BIOSCU_FLAG_FILE_COPY;
                  fcPath = argv[i + 1]; // store the path of the next argument after /FC into a char*
#ifdef LINUX
        // LINUX v
        // check if the path ends with a slash. If not, append it to the char array fcPath.
                  if (fcPath[strlen(fcPath) - 1] != '/')
                  {
                      strcat(fcPath, "/");
                  }
                  fcDir = opendir(fcPath); // use the DIR* to open the direcotry
                  if (fcDir)               // check if the directory exists
                  {
                      closedir(fcDir);
                  }
                  else if (ENOENT == errno)
                  {
                      PRINTF("\n%s is not a valid Path\n", fcPath);
                      exit(1);
                  }
                  else
                  {
                      PRINTF("ERROR: Check your rights!\n");
                      exit(1);
              }
                  // LINUX ^
#endif
#ifdef WIN32
        // WINDOWS v
                  if (strchr(fcPath, '/')) //check if no forward slash is used in wndows. If so, exit!
                  {
                      PRINTF("Please use backslash for directories\n");
                      exit(1);
                  }
                  if (fcPath[strlen(fcPath) - 1] != '\\')
                  {
                      strcat(fcPath, "\\");
                  }
                  if (DirectoryExists(fcPath)) // check if the directory exists
                  {
                      // do nothing. Continue
                  }
                  else if (!DirectoryExists(fcPath))
                  {
                      PRINTF("\n%s is not a valid Path\n", fcPath);
                      exit(1);
                  }
                  else
                  {
                      PRINTF("ERROR: Check your rights!\n");
                      exit(1);
                  }
                  // WINDOWS ^
#endif
                  i++; // ignore the directory after /FC as an argument for next argument checks
              }
          }
      }
      else 
      {
          PRINTF(_T("ERROR: Unknown command!\n"));
          //PRINTF("ERROR Index number i: %d\n", i); /debug gma
          exit(1);
      }
      //PRINTF("Index number i: %d\n", i);  //debug gma
  }

  // Flag parsing
 
  if (!CgosOpen())
  {
    PRINTF(_T("ERROR: Failed to access system interface!\n"));
    exit(1);
  }

  if (nFlags & CGUTL_BIOSCU_FLAG_FILE_COPY)
  {
    // File copy Methods
    // Copy bios capsule file to another location

    if (fpNewBiosFile == NULL)
    {
      PRINTF(_T("ERROR: BIOS capsule file is empty!\n"));
      exit(1);
    }

    // load BIOS capsule into buffer
    fseek(fpNewBiosFile, 0L, SEEK_END);
    numbytes = ftell(fpNewBiosFile);
    fseek(fpNewBiosFile, 0L, SEEK_SET);
    buffer = (char *)malloc(numbytes * sizeof(unsigned char)); //"sizeof" only represents the size a pointer, which is 8bytes.
    fread(buffer, sizeof(char), numbytes, fpNewBiosFile);

    // copy the capsule into the provided path
    strcat(fcPath, "BIOSUPDT.cap");   // append the fcPath with BIOSUPDT.cap
    copiedFile = fopen(fcPath, "wb"); // /GMA TODO append fcPath to char

    if (copiedFile == NULL)
    {
      PRINTF("ERROR: Cannot enter directory! Check your rights!\n");
      exit(1);
    }

    fwrite(buffer, sizeof(char), numbytes, copiedFile);
    PRINTF("\nThe capsule has been copied to: %s\n", fcPath);

    // close files and free buffer
    fclose(fpNewBiosFile); // close bios file
    fclose(copiedFile);
    free(buffer);
  }
  else
  {
    PRINTF("\nPlease copy the BIOSUPDT.cap file into a desired directory\n");
    //PRINTF("Trigger capsule update with flag: %s ", (UINT32)BiosCuParamFlags);
    if (nFlags == CGUTL_BIOSCU_FLAG_FILE)
    {
        fclose(fpNewBiosFile);
    }
  }
  if (!((BiosCuParamFlags & CGOS_BIOSCU_AUTO_RESTART_BIT) == CGOS_BIOSCU_AUTO_RESTART_BIT))  
  {
      PRINTF("\nPlease restart the system!\n");
  }
  //CgosTriggerCapsuleUpdate(hCgos, CGOS_CAPSULE_UPDATE_BIOS, BiosCuParamFlags);            
  CgosCapsuleUpdateBiosTrigger(hCgos, BiosCuParamFlags,0 );                    
  //PRINTF("\nTrigger capsule update with flag: %x %x\n", BiosCuParamFlags, nFlags); //debug gma
  CgosClose();   
  exit(0);
}
